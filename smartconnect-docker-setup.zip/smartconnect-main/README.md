# Smart Connect on Docker


## Introduction
SMART stands for Spatial Monitoring and Reporting Tool and is a software to support conservation efforts all over the world.
It's developed and maintained by the SMART Partnership. 
The SMART software stack consists of three different tools working closely together:
1. SMART Desktop
The configuration, management and analyzing software running on a local computer
2. SMART Mobile (Android and iOS)
The data collection App for rangers in the field, that collects patrol and observation data. 
3. SMART Connect is a Webservice to that collects the data from SMART Mobile and distributes it to SMART Desktop


SMART Connect on Docker is a full implementation of SMART Connect based on docker containers. 
The SMART Connect docker environment consists of three different containers that work closely together:
-	PostgreSQL Container
-	Apache Tomcat SMART Connect Container
-	Apache2 Web Application Firewall Container

Stateful data is only stored in the PostgreSQL and the Apache Tomcat container. This data is stored in named docker volumes to make it persistent, even if the hosting container gets restarted, updated or deleted.
The backup system is only backing up these volumes.
 

## Preparations: Install Docker
### Windows 10 & 11: Install Docker Desktop
Please follow the installation instructions for docker desktop on Windows from the docker website: Install Docker Desktop on Windows | Docker Docs
###Windows-Server
Using WSL 2 on Windows Server 2022 to run Linux containers - Microsoft Community Hub
1.	Enable the containers feature in Windows Server by opening PowerShell as Administrator and running the command: Enable-WindowsOptionalFeature -Online -FeatureName containers -All
2.	Install Docker on Windows Server by running the command: Install-Module DockerMsftProvider -Force, followed by Install-Package Docker -ProviderName DockerMsftProvider
3.	Restart the server by running the command: Restart-Computer -Force
4.	Run Docker container by using the docker run command.

### Linux: Install Docker and Docker Compose
	
Install docker using the package manager provided by your Linux distribution (https://docs.docker.com/engine/install/ubuntu/).
These samples are for Ubuntu. Be aware that other Linux distributions are using different package manager. Please check the docker website for information.
```    
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh ./get-docker.sh
```


### Download using git 
<tbd>

## Generate Configuration
When you build and start a SMART Connect container system the configuration is read from an .env file you can specify on the command line of the docker compose command.
In that .env file you can set all important parameters for SMART Connect:

### SMART_CONNECT_PUBLIC_PORT
This parameter sets the public HTTPS port for SMART Connect:
'''SMART_CONNECT_PUBLIC_PORT=443'''

### SMART_CONNECT_PUBLIC_SERVERNAME
Sets the servername of SMART Connect

### SMART_CONNECT_VERSION_GDRIVEID
Sets the Google Drive ID for the server.war file to be used in SMART Connect.
At the moment you can use 7.5.7 or 7.5.8:
    - 7.5.7 (md5sum: 2561f9212d0ba2103388968762ece3cb)
'''
SMART_CONNECT_VERSION_GDRIVEID="124POWmNfQNYyNgkXRjBXloWDmITXjy1Z"
'''

    - 7.5.8 (md5sum:0cace3c7fa9f9171a48cc2fc853cc624 )
'''
SMART_CONNECT_VERSION_GDRIVEID="125BnL_SAlvYO81SKQQhSqA17SxyiJ57T"
'''

- 7.5.9 (md5sum: )
'''
SMART_CONNECT_VERSION_GDRIVEID=""
'''

## Generating Certificate
SMART Connect uses as access method only HTTPS. Therefore all communication between SMART Mobile and SMART Desktop to SMART Connect is encrypted using SSL/TLS. Any communication using HTTPS requires at least on the server side a public key certificate signed by a certificate authority.
Public key certificate - Wikipedia

### SMART Connect accessible from the internet
#### Let’s Encrypt
To create the a public signed certificate for your SMART Connect server you can use a temporary docker container that creates and signs a certificate automatically for you.
This container has to be started on the same machine you are running SMART Connect. The servers has to be reachable by HTTP (TCP Port 80) and by HTTPS (TCP Port 443) from the internet. So it needs either a public IP address or a public DNS.
Quick and Easy Lets Encrypt Certificates using Docker (blockdev.io)
https://eff-certbot.readthedocs.io/en/latest/install.html#running-with-docker

```
sudo docker run -it --rm --name certbot -v "/etc/letsencrypt:/etc/letsencrypt" -v "/var/lib/letsencrypt:/var/lib/letsencrypt" certbot/certbot certonly
```

#### Renewal
Let's Encrypt certificates are only valid for 90 days. To renew please stop your services and issue the following command onb your docker host:
```
sudo docker run -it --rm --name certbot -v "/etc/letsencrypt:/etc/letsencrypt" -v "/var/lib/letsencrypt:/var/lib/letsencrypt" certbot/certbot certonly --force-renewal
```

### SMART Connect accessible only from internal network
https://www.golinuxcloud.com/openssl-subject-alternative-name/
If you use SMART Connect only inside a private network without exposing the server to the public internet you can choose to use only a self-signed certificate. 
Creating a self-signed certificate is a fast and simple process when using openssl.
When you are opening the webside in a browser you will get an warning message and to access it using SMART Desktop you will need to manually add the cerificate to the configuration. 

In general you have to be careful to use the correct server name when creating the certificate otherwise you will not be able to access the server. 
If you want to access the server also by its IP-Address you need to change the file ssl-config.cfg to include this IP address as a Subject Alternate Name (SAN).
This command will create the key file and the certificate:
```
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -subj "/CN=<servername>" -keyout ./apache2/server.key -out ./apache2/server.crt -extensions san -config ./apache2/ssl-config.cfg
```

## Build and start the container
Docker Compose is used to build the docker container system for SMART Connect. It uses a yaml file that describes the setup process in detail.
To start the build process open a Windows command line or Windows terminal and switch to the directory that you unzipped the SMART Connect Docker package into.
Now issue this command on the command line:
docker-compose build

It will build the docker containers by downloading the required files, building the container and the local virtual network.

### Build
Before the container can be executed the underlying images have to be build. This is done by the "docker compose build" command.
It reads the definitions from the Docker-Compose.yml file and all Dockerfiles for the specific container to build the containerized app.

```
docker compose -f .\7.5.9\docker-compose.yml --env-file .\7.5.9\.env.service2 -p service2 build
```

### Start
When the images have been build you start the app by issuing the "docker compose up" command. For testing omit the -d flag to see all output from starting the container.
For production just add -d flag to start the container independently.
```
docker compose -f .\7.5.9\docker-compose.yml --env-file .\7.5.9\.env.service2 -p service2 up [-d]
```

## Maintanance and Troubleshouting
### Restart
```
docker compose -f .\7.5.9\docker-compose.yml --env-file .\7.5.9\.env.service2 -p service2 restart [-d]
```
### Shutdown 
```
docker compose -f .\7.5.9\docker-compose.yml --env-file .\7.5.9\.env.service2 -p service2 down
```
### Remove 
```
docker compose -f .\7.5.9\docker-compose.yml --env-file .\7.5.9\.env.service2 -p service2 rm
```


### Backup and Restore
This docker compose project includes a service to automatically backup all relevant data of the provided SMART Connect system. It is implmenented using a docker image called docker-volume-backup (https://offen.github.io/docker-volume-backup/).
It is configured to backup the SMART Connect filestore volume and the PostgreSQL datbase volume as a full backup. When the backup is triggered, either automatically scheduled or manually, the three conatiners are shutdown and restarted after finishing the backup to avoid any inconsistency in the data. 
The behaviour of the backup system can be configured in the configuration file backup.env. To change any of these settings please check https://offen.github.io/docker-volume-backup/reference/
In the initial configuration the backup data is written to a local directory of the server. 

#### Create a Backup manually
1. Identify the name of the backup container in your service set
2. Manually start the backup
```
docker exec <backup_containner_name> backup
```
3. Check the Backup directory for a new Backup

#### Resore the Data from a Backup
tbd

# Future enhancements   
## Support for volume encryption

