from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Table
from sqlalchemy.orm import relationship

from uuid import UUID
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid
from sqlalchemy import text, select, func
from sqlalchemy.orm import column_property,mapped_column,object_session, MappedColumn, Relationship, MappedSQLExpression, Mapped

from .database import Base, engine #smart_metadata, 
from geoalchemy2 import Geography,Geometry

class Language(Base):
    __tablename__ = "language"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[UUID]                = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID]             = mapped_column(Uuid)
    is_default: MappedColumn[bool]          = mapped_column(Boolean)
    code: MappedColumn[str]                 = mapped_column(String(8))

class I18nLabel(Base):
    __tablename__ = "i18n_label"
    __table_args__ = {"schema": "smart"}
    
    language_uuid: MappedColumn[UUID]       = mapped_column('language_uuid', Uuid, primary_key=True)
    element_uuid: MappedColumn[UUID]        = mapped_column('element_uuid', Uuid, primary_key=True)
    value: MappedColumn[str]                = mapped_column('value', String)
    
class PatrolMandate(Base):
    __tablename__ = "patrol_mandate"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[Uuid]                = mapped_column('uuid', Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[Uuid]             = mapped_column('ca_uuid', Uuid)
    is_active: MappedColumn[bool]           = mapped_column('is_active', Boolean)
    keyid: MappedColumn[str]                = mapped_column('keyid', String)
    #t_keyid             = Column('t_keyid', String)
    #t_keyid             = column_property(select(func.get_translations(uuid)).scalar_subquery())    

    #LEFT OUTER JOIN smart.i18n_label on smart.patrol_mandate.uuid = smart.i18n_label.element_uuid and (smart.i18n_label.language_uuid = current_setting('var.lang_uuid'::text)::uuid or smart.i18n_label.language_uuid = current_setting('var.default_lang_uuid'::text)::uuid)

    #name                = Column('get_translations(smart.patrol_mandate.uuid) as t_name', String )
        
    #    text("reporting.get_translations(uuid,'960509b0-9784-4863-94f4-1d0a270459ca')")) #, bindparams={"lang_uuid": "42"})
    #,'960509b0-9784-4863-94f4-1d0a270459ca'
    #name                = column_property(select(func.get_translations(uuid, '960509b0-9784-4863-94f4-1d0a270459ca')).scalar_subquery())
    #@property
    #def translate(self):
    #    return object_session(self).scalar(select(func.get_translations(self.uuid, '960509b0-9784-4863-94f4-1d0a270459ca').where(patrol_mandate.uuid == self.uuid)))

class Station(Base):
    __tablename__ = "station"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[Uuid]                = mapped_column('uuid', Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[Uuid]             = mapped_column('ca_uuid', Uuid)
    is_active: MappedColumn[bool]           = mapped_column('is_active', Boolean)
    desc_uuid: MappedColumn[Uuid]             = mapped_column('desc_uuid', Uuid)              
    


class Team(Base):
    __tablename__ = "team"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[Uuid]                = mapped_column('uuid', Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[Uuid]             = mapped_column('ca_uuid', Uuid)
    is_active: MappedColumn[bool]           = mapped_column('is_active', Boolean)
    keyid: MappedColumn[str]                = mapped_column('keyid', String)
    desc_uuid: MappedColumn[Uuid]             = mapped_column('desc_uuid', Uuid)              
    patrol_mandate_uuid: MappedColumn[Uuid]             = mapped_column('patrol_mandate_uuid', Uuid)


class PatrolTransporttypes(Base):
    __tablename__ = "patrol_transport"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[Uuid] = mapped_column('uuid', Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[Uuid] = mapped_column('ca_uuid', Uuid, ForeignKey("smart.conservation_area.ca_uuid"))
    is_active           = Column('is_active', Boolean)
    keyid               = Column('keyid', String)
    #patrol_type         = Column('patrol_type', String)
    patrol_type         = Column(String(6), ForeignKey("smart.patrol_transport.patrol_type"))
    
    #t_keyid             = Column('reporting.get_translations(uuid) as t_keyid', String)
    patroltype= relationship("PatrolType", back_populates="transporttypes") 

    def __repr__(self) -> str:
         return f"uuid(id={self.uuid!r}, keyid={self.keyid!r}, patrol_type={self.patrol_type!r})"

class PatrolType(Base):
    __tablename__ = "patrol_type"
    __table_args__ = {"schema": "smart"}
    
    patrol_type         = Column('patrol_type', String(6), primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[Uuid] = mapped_column('ca_uuid', Uuid, ForeignKey("smart.patrol_transport.patrol_type"), primary_key=True, unique=True, index=True)
    is_active           = Column('is_active', Boolean)
    max_speed           = Column('max_speed', Integer)
    transporttypes = relationship("PatrolTransporttypes", back_populates="patroltype")

class _ConservationArea(Base):
    __tablename__   = "conservation_area"
    __table_args__ = {"schema": "smart"}
    uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    
    pass   

class Employee(Base):
    __tablename__ = "employee"
    __table_args__ = {"schema": "smart"}
    
    uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.conservation_area.uuid"))
    id                  = Column(String)
    givenname           = Column(String(64))
    familyname          = Column(String(64))
    startemploymentdate = Column(Date)
    endemploymentdate   = Column(Date)
    datecreated         = Column(Date)
    birthdate           = Column(Date)
    gender              = Column(String(1))
    smartuserid         = Column(String(16))
    agency_uuid: MappedColumn[UUID] = mapped_column(Uuid)
    rank_uuid: MappedColumn[UUID] = mapped_column(Uuid)
    smartuserlevel      = Column(String(5000))
    patrol_legs  = relationship("PatrolLegMembers", back_populates="employee")
    ca: Mapped[_ConservationArea]   = relationship("ConservationArea")
    employee_team_members     = relationship("EmployeeTeamMember", back_populates="employee")
    #@hybrid_property
    #def fullname(self):
    #    return self.givenname + " " + self.familyname

class EmployeeTeam(Base):
    """
    Class for the table smart.employee_team
    """
    __tablename__ = "employee_team"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.conservation_area.uuid"))
    ca: Mapped[_ConservationArea]   = relationship("ConservationArea")

    name      = column_property(func.reporting.get_translations(uuid))
    employee_team_members = relationship("EmployeeTeamMember", back_populates="employee_team")

#class EmployeeTeam(EmployeeTeamBase):    
#    name      = column_property(func.reporting.get_translations(EmployeeTeamBase.uuid))   

class EmployeeTeamMember(Base):
    __tablename__ = "employee_team_member"
    __table_args__ = {"schema": "smart"}

    employee_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.employee.uuid"), primary_key=True)
    team_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.employee_team.uuid"), primary_key=True)
    team_name = column_property(func.reporting.get_translations(team_uuid))
    employee_team: Mapped[EmployeeTeam] = relationship("EmployeeTeam", back_populates="employee_team_members")
    employee: Mapped[Employee] = relationship("Employee", back_populates="employee_team_members")


class PatrolLegMembers(Base):    
    __tablename__ = "patrol_leg_members"
    __table_args__ = {"schema": "smart"}

    patrol_leg_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol_leg.uuid"), primary_key=True)
    employee_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.employee.uuid"), primary_key=True)
    is_leader           = Column(Boolean)
    is_pilot            = Column(Boolean)
    patrol_leg = relationship("PatrolLeg", back_populates="patrollegmembers")
    employee:           Mapped[Employee] = relationship("Employee", back_populates="patrol_legs")
    

class ConservationArea(_ConservationArea):
    #__tablename__   = "conservation_area"
    #__table_args__ = {"schema": "smart"}

    #uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    id                  = Column(String(8))
    name                = Column(String(256))
    designation         = Column(String(1024))
    description         = Column(String(2056))
    organization        = Column(String(256))
    pointofcontact      = Column(String(256))
    country             = Column(String(256))
    owner               = Column(String(256))



class TrackBase(Base):
    __tablename__       = "track"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    patrol_leg_day_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol_leg_day.uuid"))
    patrol_leg_day      = relationship("PatrolLegDay", back_populates="track")
    distance: MappedColumn[float]           = mapped_column(Float)
    geometry   = mapped_column(Geometry)

class Track(TrackBase):
    #geometry          = mapped_column(Geometry) #(geometry_type='MULTILINESTRING', from_text='ST_GeomFromWKB' ))
    geo= column_property(func.public.ST_GeomFromWKB(TrackBase.geometry))
    #geometry2         = Column('geom_json', String)


class PatrolLegDayBase(Base):
    __tablename__       = "patrol_leg_day"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID] = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    patrol_leg_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol_leg.uuid"))
    patrol_leg = relationship("PatrolLeg", back_populates="patrol_leg_days")
    patrol_day          = Column(Date)
    start_time          = Column(Time)
    end_time            = Column(Time)
    rest_minutes        = Column(Integer)
    track_count: MappedSQLExpression[int] = column_property(select(func.count(TrackBase.uuid)).where(TrackBase.patrol_leg_day_uuid == uuid).scalar_subquery())    
    distance: MappedSQLExpression[float] = column_property(select(func.coalesce(func.sum(TrackBase.distance),0)).where(TrackBase.patrol_leg_day_uuid == uuid).scalar_subquery())    

class PatrolLegDay(PatrolLegDayBase):
    track    = relationship("Track", back_populates="patrol_leg_day") 
    patrol_waypoints = relationship("patrol_waypoint", back_populates="patrol_leg_day")



class PatrolLeg(Base):
    __tablename__ = "patrol_leg"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID]        = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    id = Column(String)

    patrol_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol.uuid"))
    mandate_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol_mandate.uuid"))
    transporttype_uuid: MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.patrol_transport.uuid"))

    patrol       = relationship("Patrol", back_populates="patrol_legs")

    patrol_leg_days = relationship("PatrolLegDay", back_populates="patrol_leg") 
    patrollegmembers: Mapped[PatrolLegMembers] = relationship("PatrolLegMembers", back_populates="patrol_leg")

    start_date = Column(Date)
    end_date = Column(Date)
    #transport_uuid:    UUID
    
    #mandate_uuid:      UUID
    #patrol_leg_days:   list[PatrolLegDay]
    employee_count: MappedSQLExpression[int] = column_property(select(func.count(PatrolLegMembers.employee_uuid)).where(PatrolLegMembers.patrol_leg_uuid == uuid).scalar_subquery())
    leg_day_count: MappedSQLExpression[int] = column_property(select(func.count(PatrolLegDay.uuid)).where(PatrolLegDay.patrol_leg_uuid == uuid).scalar_subquery())    
    distance: MappedSQLExpression[float] = column_property(select(func.coalesce(func.sum(PatrolLegDayBase.distance),0)).where(PatrolLegDay.patrol_leg_uuid == uuid).scalar_subquery())    
    #distance = mapped_column(select(func.sum(PatrolLegDayBase.distance)).where(PatrolLegDay.patrol_leg_uuid == uuid).scalar_subquery())    


class PatrolBase(Base):
    __tablename__ = "patrol"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID]        = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID]     = mapped_column(Uuid)
    id =            Column(String, unique=True, index=True)
    start_date =    Column(Date)
    end_date =      Column(Date)
    comment =       Column(String)
    is_armed =      Column(Boolean)
    leg_count: MappedSQLExpression[int]   = column_property(select(func.count(PatrolLeg.uuid)).where(PatrolLeg.patrol_uuid == uuid).scalar_subquery())
    distance: MappedSQLExpression[float]  = column_property(select(func.coalesce(func.sum(PatrolLeg.distance),0)).where(PatrolLeg.patrol_uuid == uuid).scalar_subquery())  
    team_uuid: MappedColumn[UUID]           = mapped_column(Uuid, ForeignKey("smart.team.uuid"))
    station_uuid: MappedColumn[UUID]       = mapped_column(Uuid, ForeignKey("smart.station.uuid"))
    
    #employee_count = 

class Patrol(PatrolBase):
    patrol_legs = relationship("PatrolLeg", back_populates="patrol") 



class wp_observation_base(Base):
    __tablename__ = "wp_observation"
    __table_args__ = {"schema": "smart"}

    uuid: MappedColumn[UUID]                = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    category_uuid: MappedColumn[UUID]       = mapped_column(Uuid, ForeignKey("smart.dm_category.uuid"))
    employee_uuid: MappedColumn[UUID]       = mapped_column(Uuid, ForeignKey("smart.employee.uuid"))
    wp_group_uuid: MappedColumn[UUID]       = mapped_column(Uuid, ForeignKey("smart.wp_observation_group.uuid"))

    wp_group             = relationship("wp_observation_group", back_populates="wp_observations") 
    attributes           = relationship("wp_observation_attributes", back_populates="observation") 
class wp_observation(wp_observation_base):
    category      = column_property(func.reporting.get_translations(wp_observation_base.category_uuid))    

 

    
# association table for  wp_observation and waypoint  (1:1) 
class wp_observation_group(Base):
    __tablename__: str                      = "wp_observation_group"
    __table_args__: dict[str, str]          = {"schema": "smart"}
    uuid: MappedColumn[UUID]                = mapped_column(Uuid, primary_key=True, unique=True, index=True)

    #wp_observation
    wp_uuid: MappedColumn[UUID]             = mapped_column(Uuid, ForeignKey("smart.waypoint.uuid"))
    waypoint             = relationship("Waypoint", back_populates="wp_observation_group") 
    wp_observations      = relationship("wp_observation", back_populates="wp_group") 
    
    
class WaypointBase(Base):
    __tablename__                      = "waypoint"
    __table_args__          = {"schema": "smart"}
    uuid: MappedColumn[UUID]                = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID]             = mapped_column(Uuid, ForeignKey("smart.conservationarea.uuid"))
    source:  MappedColumn[str]              = mapped_column(String(16), nullable=False)
    id:  MappedColumn[str]                  = mapped_column(String(256), nullable=False)
    x:  MappedColumn[float]                 = mapped_column(Float, nullable=False)
    y:  MappedColumn[float]                 = mapped_column(Float, nullable=False)
    
    datetime:  MappedColumn[DateTime]       = mapped_column(DateTime, nullable=False)
    #direction real,
    #distance real,
    wp_comment:  MappedColumn[str]          = mapped_column(String(256), nullable=True)
    #last_modified timestamp without time zone NOT NULL,
    #last_modified_by uuid,
    source_cm_uuid: MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.configurable_model.uuid"))

    wp_observation_group   = relationship("wp_observation_group", back_populates="waypoint") 
    patrol_waypoint        = relationship("patrol_waypoint", back_populates="waypoint")

class Waypoint(WaypointBase):
    #geo                                = Column(Geometry(geometry_type='POINT', from_text='st_point(WaypointBase.x,WaypointBase.y)' ))
    #geo                                     = column_property(func.public.st_point(WaypointBase.y, WaypointBase.x))
    #geo_text                                     = column_property(func.public.st_astext(func.public.st_point(WaypointBase.y, WaypointBase.x)))
    geo        = column_property(func.public.st_point(WaypointBase.y, WaypointBase.x))
    


class patrol_waypoint(Base):
    __tablename__                      = "patrol_waypoint"
    __table_args__          = {"schema": "smart"}
    
    wp_uuid:           MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.waypoint.uuid"), primary_key=True) 
    leg_day_uuid:      MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.patrol_leg_day.uuid"), primary_key=True) 
    waypoint:          Mapped[Waypoint]        = relationship("Waypoint", back_populates="patrol_waypoint", uselist=False)
    patrol_leg_day:    Mapped[PatrolLegDay]    = relationship("PatrolLegDay", back_populates="patrol_waypoints", uselist=False) 
   




class DM_Category_Base(Base):
    __tablename__                      = "dm_category"
    __table_args__          = {"schema": "smart"}
    uuid: MappedColumn[UUID]                = mapped_column(Uuid, primary_key=True, unique=True, index=True)
    ca_uuid: MappedColumn[UUID]             = mapped_column(Uuid, ForeignKey("smart.conservationarea.uuid"))
    keyid:MappedColumn[str]                 = mapped_column(String(128), nullable=False)
    parent_category_uuid: MappedColumn[UUID]= mapped_column(Uuid, ForeignKey("smart.dm_category.uuid"), nullable=True)
    is_multiple: MappedColumn[bool]         = mapped_column(Boolean, nullable=True)
    cat_order: MappedColumn[int]            = mapped_column(Integer, nullable=True)
    is_active: MappedColumn[bool]           = mapped_column(Boolean, nullable=False)
    hkey: MappedColumn[str]                 = mapped_column(String, nullable=False)
    icon_uuid: MappedColumn[UUID]           = mapped_column(Uuid, ForeignKey("smart.icon.uuid"), nullable=True)
    
class DM_Category(DM_Category_Base):
    name          = column_property(func.reporting.get_translations(DM_Category_Base.uuid))

class DM_Attribute_Base(Base):
    __tablename__                      = "dm_attribute"
    __table_args__          = {"schema": "smart"}
    uuid:           MappedColumn[UUID]      = mapped_column(Uuid, primary_key=True, unique=True, index=True)    
    ca_uuid:        MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.conservationarea.uuid"))
    keyid:          MappedColumn[str]       = mapped_column(String(128), nullable=False)
    is_required:    MappedColumn[bool]      = mapped_column(Boolean, nullable=False)
    att_type:       MappedColumn[str]       = mapped_column(String(7), nullable=False)
    
    min_value:      MappedColumn[float]     = mapped_column(Float, nullable=True)
    max_value:      MappedColumn[float]     = mapped_column(Float, nullable=True)
    regex:          MappedColumn[str]       = mapped_column(String(1024), nullable=True)
    icon_uuid:      MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.icon.uuid"), nullable=True)

class DM_Attribute(DM_Attribute_Base):
    name          = column_property(func.reporting.get_translations(DM_Attribute_Base.uuid))

class DM_Attribute_List_Base(Base):
    __tablename__                      = "dm_attribute_list"
    __table_args__          = {"schema": "smart"}
    uuid:           MappedColumn[UUID]      = mapped_column(Uuid, primary_key=True, unique=True, index=True)    
    attribute_uuid: MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.dm_attribute.uuid"))
    keyid:          MappedColumn[str]       = mapped_column(String(128), nullable=False)
    list_order:     MappedColumn[int]       = mapped_column(Integer, nullable=False)
    is_active:      MappedColumn[bool]      = mapped_column(Boolean, nullable=False)
    icon_uuid:      MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.icon.uuid"), nullable=True)
class DM_Attribute_List(DM_Attribute_List_Base):
    name          = column_property(func.reporting.get_translations(DM_Attribute_List_Base.uuid))


class DM_Attribute_Tree_Base(Base):
    __tablename__                      = "dm_attribute_tree"
    __table_args__          = {"schema": "smart"}
    uuid:           MappedColumn[UUID]      = mapped_column(Uuid, primary_key=True, unique=True, index=True)    
    parent_uuid:    MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.dm_attribute_tree.uuid"))
    attribute_uuid: MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.dm_attribute.uuid"))
    keyid:          MappedColumn[str]       = mapped_column(String(128), nullable=False)
    node_order:     MappedColumn[int]       = mapped_column(Integer, nullable=False)
    is_active:      MappedColumn[bool]      = mapped_column(Boolean, nullable=False)
    icon_uuid:      MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.icon.uuid"), nullable=True)
    hkey:           MappedColumn[str]       = mapped_column(String, nullable=False)
class DM_Attribute_Tree(DM_Attribute_Tree_Base):
    name          = column_property(func.reporting.get_translations(DM_Attribute_Tree_Base.uuid))


class wp_observation_attributes_base(Base):
    __tablename__                      = "wp_observation_attributes"
    __table_args__          = {"schema": "smart"}
    
    uuid:           MappedColumn[UUID]      = mapped_column(Uuid, primary_key=True, unique=True, index=True) 
    observation_uuid:    MappedColumn[UUID] = mapped_column(Uuid, ForeignKey("smart.wp_observation.uuid"))
    attribute_uuid: MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.dm_attribute.uuid"))
    list_element_uuid: MappedColumn[UUID]   = mapped_column(Uuid, ForeignKey("smart.dm_attribute_list.uuid"), nullable=True)
    tree_node_uuid: MappedColumn[UUID]      = mapped_column(Uuid, ForeignKey("smart.dm_attribute_tree.uuid"), nullable=True)
    number_value:   MappedColumn[float]     = mapped_column(Float, nullable=True)
    string_value:   MappedColumn[String]    = mapped_column(String(8200), nullable=True)
    observation          = relationship("wp_observation" , back_populates="attributes")                              
class wp_observation_attributes(wp_observation_attributes_base):
    attribute          = column_property(func.reporting.get_translations(wp_observation_attributes_base.attribute_uuid))      
    list_element  = column_property(func.reporting.get_translations(wp_observation_attributes_base.list_element_uuid))
    tree_node     = column_property(func.reporting.get_translations(wp_observation_attributes_base.tree_node_uuid))
    

