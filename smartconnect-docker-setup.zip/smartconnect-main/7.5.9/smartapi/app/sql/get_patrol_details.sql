select * from smart.waypoint as w
join smart.patrol_waypoint as pw on w.uuid = pw.wp_uuid
join smart.patrol_leg_day as pld on pw.leg_day_uuid = pld.uuid
--join smart.track as t on t.patrol_leg_day_uuid = pld.uuid
join smart.patrol_leg as pl on pld.patrol_leg_uuid = pl.uuid
join smart.patrol as p on p.uuid = pl.patrol_uuid

--join smart.wp_observation_group as wog on wog.wp_uuid = w.uuid
--join smart.wp_observation as wo on wo.wp_group_uuid = wog.uuid


where pl.patrol_uuid = '1a61a228-453c-4488-bdf2-66ead97273b3'
--where	pl.id <> '1'
order by w.datetime asc


select 
	--ST_DumpPoints(t.geometry::geometry),
	--ST_AsGeoJSON(t.geometry::geometry), 
	ST_AsGeoJSON(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1)) as start_point, 
	--ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1),
	ST_AsText(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), -1)) as end_point, 
	--ST_AsText(ST_Points(t.geometry::geometry)), 
	to_timestamp(st_z(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1)) / 1000::double precision) as start_time,
	to_timestamp(st_z(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), -1)) / 1000::double precision) as end_time,
	*
from smart.track as t
join smart.patrol_leg_day as pld on t.patrol_leg_day_uuid = pld.uuid
join smart.patrol_leg as pl on pld.patrol_leg_uuid = pl.uuid
--join smart.patrol_leg_members as plm on plm.patrol_leg_uuid = pl.uuid
--join smart.employee as e on plm.employee_uuid = e.uuid
join smart.patrol as p on p.uuid = pl.patrol_uuid
where pl.patrol_uuid = '1a61a228-453c-4488-bdf2-66ead97273b3'
order by pl.id
