from .smartdbsession import smartDbSession
from typing import Annotated,List
from uuid import UUID
from geoalchemy2 import functions as geofunc
from sqlalchemy import select,func,join


async def query_agencies( 
                    db:             smartDbSession,
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    language_uuid:  Annotated[UUID, "Language ID"],
                    agency_uuids:   list[UUID] = [],            
                ):
    
    db.set_default_language(language_uuid=language_uuid)
    
    
    q = select(
                             db.agency.c.uuid,
                            db.agency.c.ca_uuid,
                            db.agency.c.keyid,
                            func.reporting.get_translations(db.agency.c.uuid).label("name")
                         ).where(db.agency.c.ca_uuid == ca_uuid)
    
    if len(agency_uuids) > 0:
    #    return db.getSession().query(db.agency.c.uuid,db.agency.c.ca_uuid,db.agency.c.keyid,func.reporting.get_translations(db.agency.c.uuid).label("name")).where(db.agency.c.ca_uuid == ca_uuid).where(db.agency.c.uuid.in_(agency_uuids)).all()
        q = q.where(db.agency.c.uuid.in_(agency_uuids))
    #else:
    #    return db.getSession().query(db.agency.c.uuid,db.agency.c.ca_uuid,db.agency.c.keyid,func.reporting.get_translations(db.agency.c.uuid).label("name")).where(db.agency.c.ca_uuid == ca_uuid).all()
    
    return db._dbSession.execute(q).fetchall()
