from sqlalchemy import create_engine, event, MetaData,Table
from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.session import Session
from sqlalchemy.sql import text
from config import get_settings
import logging
from uuid import UUID
from sql.smartdbsession import smartDbSession

logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
logging.getLogger("sqlalchemy.pool").setLevel(logging.INFO)

logging.info(f"SMART_DATABASE_SERVER: {get_settings().SMART_DATABASE_SERVER}")

engine = create_engine(f'postgresql+psycopg2://{get_settings().SMART_DATABASE_USER}:{get_settings().SMART_DATABASE_PASSWORD}@{get_settings().SMART_DATABASE_SERVER}:{get_settings().SMART_DATABASE_PORT}/{get_settings().SMART_DATABASE_DATABASE}', 
                       echo=False, connect_args={'options': '-c statement_timeout=15000'})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
smart_metadata = MetaData()
print("Start read metadata")
patrol =                        Table("patrol", smart_metadata, schema="smart", autoload_with=engine)
patrol_leg =                    Table("patrol_leg", smart_metadata, schema="smart", autoload_with=engine)
patrol_leg_day =                Table("patrol_leg_day", smart_metadata, schema="smart", autoload_with=engine)
track =                         Table("track", smart_metadata, schema="smart", autoload_with=engine)
patrol_leg_members =            Table("patrol_leg_members", smart_metadata, schema="smart", autoload_with=engine)
employee =                      Table("employee", smart_metadata, schema="smart", autoload_with=engine)
area_geometries =               Table("area_geometries", smart_metadata, schema="smart", autoload_with=engine)
conservation_area_property =    Table("conservation_area_property", smart_metadata, schema="smart", autoload_with=engine)
conservation_area =             Table("conservation_area", smart_metadata, schema="smart", autoload_with=engine)
patrol_mandate =                Table("patrol_mandate", smart_metadata, schema="smart", autoload_with=engine)
patrol_transport =              Table("patrol_transport", smart_metadata, schema="smart", autoload_with=engine)
patrol_type =                   Table("patrol_type", smart_metadata, schema="smart", autoload_with=engine)

agency =                        Table("agency", smart_metadata, schema="smart", autoload_with=engine)
station =                       Table("station", smart_metadata, schema="smart", autoload_with=engine)
team =                          Table("team", smart_metadata, schema="smart", autoload_with=engine)
patrol_waypoint =               Table("patrol_waypoint", smart_metadata, schema="smart", autoload_with=engine)
waypoint =                      Table("waypoint", smart_metadata, schema="smart", autoload_with=engine)
wp_observation_group =          Table("wp_observation_group", smart_metadata, schema="smart", autoload_with=engine)
wp_observation =                Table("wp_observation", smart_metadata, schema="smart", autoload_with=engine)
wp_observation_attributes =     Table("wp_observation_attributes", smart_metadata, schema="smart", autoload_with=engine)     
wp_attachments =                Table("wp_attachments", smart_metadata, schema="smart", autoload_with=engine)     
observation_attachment =        Table("observation_attachment", smart_metadata, schema="smart", autoload_with=engine)     

connect_users =                 Table("users", smart_metadata, schema="connect", autoload_with=engine) 
connect_user_roles=             Table("user_roles", smart_metadata, schema="connect", autoload_with=engine) 
connect_user_actions=           Table("user_actions", smart_metadata, schema="connect", autoload_with=engine) 
connect_roles =                 Table("roles", smart_metadata, schema="connect", autoload_with=engine) 
connect_role_actions=           Table("role_actions", smart_metadata, schema="connect", autoload_with=engine) 

connect_dataqueue =             Table("data_queue", smart_metadata, schema="connect", autoload_with=engine) 

dm_category =                   Table("dm_category", smart_metadata, schema="smart", autoload_with=engine) 
dm_attribute =                  Table("dm_attribute", smart_metadata, schema="smart", autoload_with=engine) 
dm_attribute_list =             Table("dm_attribute_list", smart_metadata, schema="smart", autoload_with=engine) 
dm_attribute_tree =             Table("dm_attribute_tree", smart_metadata, schema="smart", autoload_with=engine) 
dm_cat_att_map =                Table("dm_cat_att_map", smart_metadata, schema="smart", autoload_with=engine) 
saved_maps =                    Table("saved_maps", smart_metadata, schema="smart", autoload_with=engine) 

language =                      Table("language", smart_metadata, schema="smart", autoload_with=engine) 
i18n_label=                     Table("i18n_label", smart_metadata, schema="smart", autoload_with=engine)

smart_db_session = smartDbSession()
smart_db_session.load_metadata()

print("Finished read metadata")
#print(engine)
#with engine.connect() as conn:
#        result = conn.execute(sqlalchemy.text('select * from smart.patrol LIMIT (10)'))
#        print(result)
        
#        for row in result.mappings():
#            print(row)

#stmt = sqlalchemy.text('select * from smart.patrol where uuid = :uuid')
#with Session(engine) as session:
#     result = session.execute(stmt, {"uuid":"c01975e3-d292-44aa-aedd-56495dc44b73"})
#     for row in result.mappings():
#          print(row)

@event.listens_for(engine, "connect")
def connect(dbapi_connection, connection_record):
    cursor_obj = dbapi_connection.cursor()
    # Set the default language ID for the get_translation function
    language_uuid = get_settings().LANGUAGE_UUID
    #cursor_obj.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    cursor_obj.execute(f"SET var.lang_uuid='{language_uuid}';")
    cursor_obj.close()

def get_db():
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()
    
def get_smart_db():
    db = smart_db_session
    try:
        yield db
    finally:
        db.close()
    