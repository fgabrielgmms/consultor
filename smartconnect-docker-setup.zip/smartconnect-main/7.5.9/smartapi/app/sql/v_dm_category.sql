-- View: reporting.v_dm_category

-- DROP VIEW reporting.v_dm_category;

CREATE OR REPLACE VIEW reporting.v_dm_category
 AS
 SELECT *
 	FROM smart.dm_category
	LEFT JOIN smart.i18n_label on smart.dm_category.uuid = smart.i18n_label.element_uuid;
    
ALTER TABLE reporting.v_dm_category
    OWNER TO postgres;

GRANT ALL ON TABLE reporting.v_dm_category TO postgres;

-- select * from reporting.v_dm_category where language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'