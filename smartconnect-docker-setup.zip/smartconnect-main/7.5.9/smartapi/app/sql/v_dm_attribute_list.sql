-- View: reporting.v_dm_attribute_list

-- DROP VIEW reporting.v_dm_attribute_list;

CREATE OR REPLACE VIEW reporting.v_dm_attribute_list
 AS
 SELECT *
 	FROM smart.dm_attribute_list
	LEFT JOIN smart.i18n_label on smart.dm_attribute_list.uuid = smart.i18n_label.element_uuid;
    
ALTER TABLE reporting.v_dm_attribute_list
    OWNER TO postgres;

GRANT ALL ON TABLE reporting.v_dm_attribute_list TO postgres;

-- select * from reporting.v_dm_attribute_list where language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'