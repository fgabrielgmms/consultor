from pydantic import BaseModel,TypeAdapter,Json
from uuid import UUID
import datetime
import geopandas as gpd
from pydantic_geojson import GeometryType,MultiLineStringModel,FeatureModel

class Language(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    is_default:             bool   
    code:                   str
    class Config:
        orm_mode = True


class I18nLabel(BaseModel):
    language_uuid:          UUID
    element_uuid:           UUID
    value:                  str|None
    class Config:
        orm_mode = True

    
class PatrolMandate(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    is_active:              bool   
    keyid:                  str
    translated_keyid:        str|None
    class Config:
        orm_mode = True

class Station(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    is_active:              bool   
    desc_uuid:              UUID|None              
    description:            str|None
    name:                   str|None
    class Config:
        orm_mode = True


class Team(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    is_active:              bool   
    keyid:                  str
    desc_uuid:              UUID|None              
    description:            str|None
    name:                   str|None
    #patrol_mandate_uuid:    UUID|None
    class Config:
        orm_mode = True

class PatrolTransporttypes(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    is_active:              bool   
    keyid:                  str
    #t_keyid:                str|None
    patrol_type:            str|None
    
    class Config:
        orm_mode = True

class PatrolType(BaseModel):
    patrol_type:            str
    ca_uuid:                UUID
    is_active:              bool
    max_speed:              int 
    transporttypes:         list[PatrolTransporttypes] = []
    class Config:
        orm_mode = True

class ConservationArea(BaseModel):
    uuid:                   UUID
    id:                     str
    name:                   str
    designation:            str|None
    description:            str|None
    organization:           str|None
    pointofcontact:         str|None
    country:                str|None
    owner:                  str|None
    class Config:
        orm_mode = True

class ConservationAreaProperties(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    pkey:                   str
    value:                  str|None
    class Config:
        orm_mode = True


class AreaGeometry(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    area_type:              str
    keyid:                  str
    geometry:               str|None
    class Config:
        orm_mode = True

class BaseMap(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    #name:                   str|None
    #visible:                bool|None
    #url:                    str|None
    is_default:             bool|None
    map_def:                str|None
    class Config:
        orm_mode = True

class Agency(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    keyid:                  str
    name:                   str|None = None
    class Config:
        orm_mode = True



class EmployeeBase(BaseModel):
    pass

class EmployeeTeam(BaseModel):
    """
    """
    uuid:                   UUID
    ca_uuid:                UUID
    ca:                     ConservationArea|None    
    name:                   str|None
    employees:              list[EmployeeBase] = []
    class Config:
        orm_mode = True

class EmployeeTeamMember(BaseModel):
    team_name:              str|None
    employee:               EmployeeBase
    class Config:
        orm_mode = True



class Employee(EmployeeBase):
    uuid:                   UUID
    ca_uuid:                UUID
    id:                     str
    givenname:              str
    familyname:             str
    startemploymentdate:    datetime.date
    endemploymentdate:      datetime.date|None
    datecreated:            datetime.date
    birthdate:              datetime.date|None
    gender:                 str
    smartuserid:            str|None
    agency_uuid:            UUID|None
    rank_uuid:              UUID|None
    smartuserlevel:         str|None
    #fullname                str|None
    ca:                     ConservationArea|None
    employee_team_members:  list[EmployeeTeamMember] = []
    class Config:
        orm_mode = True


class Track(BaseModel):
    uuid:                   UUID|None
    patrol_leg_day_uuid:    UUID|None 
    #geometry2:               MultiLineStringModel|None
    geometry:               Json|None
    distance:               float|None = 0
    class Config:
        orm_mode = True


class PatrolLegDay(BaseModel):
    uuid:               UUID
    patrol_leg_uuid:    UUID
    patrol_day:         datetime.date
    start_time:         datetime.time
    end_time:           datetime.time
    rest_minutes:       int|None = 0
    track_count:        int|None = 0
    distance:           float = 0
    #track:              list[Track] = []
    class Config:
        orm_mode = True

class PatrolLegMembers(BaseModel):
    patrol_leg_uuid:    UUID
    employee_uuid:      UUID
    is_leader:          bool
    is_pilot:           bool 
    #patrol_leg:         PatrolLeg
    employee:           Employee

    class Config:
        orm_mode = True

class PatrolLeg(BaseModel):
    uuid:          UUID
    id:            str
    start_date:    datetime.date
    end_date:      datetime.date
    employee_count: int = 0
    leg_day_count:  int = 0
    distance:       float = 0
    patrol_leg_days: list[PatrolLegDay] = []
    patrollegmembers: list[PatrolLegMembers] = []

    class Config:
        orm_mode = True



class Patrol(BaseModel):
     uuid:          UUID
     ca_uuid:       UUID
     id:            str
     #station_uuid:  UUID
     #team_uuid:     UUID
     #objective:     str
     #patrol_type:   UUID
     is_armed:      bool
     start_date:    datetime.date
     end_date:      datetime.date
     comment:       str|None
     leg_count:     int = 0
     distance:      float = 0
     patrol_legs:   list[PatrolLeg] = []
     #employees:     list[Employee] = []
     
     class Config:
        orm_mode = True 

class Waypoint(BaseModel):
    uuid:               UUID
    ca_uuid:            UUID
    source:             str # 16
    id:                 str #256
    x:                  float
    y:                  float

    datetime:           datetime.datetime
    #direction real,
    #distance real,
    wp_comment:         str|None
    #last_modified timestamp without time zone NOT NULL,
    #last_modified_by uuid,
    source_cm_uuid:     UUID|None
    geo:                str|None

class wp_observation_base(BaseModel):
    #uuid:       UUID
    #category_uuid:      UUID
    category:           str|None
    #employee_uuid:      UUID|None
    
    pass

class wp_observation_group_base(BaseModel):
    #uuid:               UUID
    #wp_uuid:            UUID
    waypoint:           Waypoint|None
    #wp_observations:    list[wp_observation_base]
    pass

class wp_observation_group(wp_observation_group_base):
    #uuid:               UUID
    #wp_uuid:            UUID
    waypoint:           Waypoint|None
    wp_observations:    list[wp_observation_base]

    class Config:
        orm_mode = True 

class wp_observation_attributes(BaseModel):
    #uuid:                   UUID|None
    attribute:              str|None
    #observation_uuid:       UUID|None
    #attribute_uuid:         UUID|None
    #list_element_uuid:      UUID|None
    list_element:           str|None
    #tree_node_uuid:         UUID|None
    tree_node:              str|None
    number_value:           float|None
    string_value:           str|None
    #observation:            wp_observation_base|None
    class Config:
        orm_mode = True 



class wp_observation(wp_observation_base):
    #uuid:               UUID
    #category_uuid:      UUID
    category:           str|None
    #employee_uuid:      UUID|None
    #wp_group_uuid:      UUID
    #waypoint:           Waypoint|None
    # Referencing the base class here prevents circular references 
    attributes:         list[wp_observation_attributes]
    wp_group:           wp_observation_group_base
    class Config:
        orm_mode = True 


class DM_Category(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    keyid:                  str
    name:                   str|None
    parent_category_uuid:   UUID|None
    is_multiple:            bool|None
    cat_order:              int|None
    is_active:              bool
    hkey:                   str
    icon_uuid:              UUID|None

    class Config:
        orm_mode = True 

class DM_Attribute(BaseModel):
    uuid:                   UUID
    ca_uuid:                UUID
    keyid:                  str
    name:                   str|None
    att_type:               str
    is_required:            bool
    min_value:              float|None
    max_value:              float|None
    regex:                  str|None
    icon_uuid:              UUID|None

    class Config:
        orm_mode = True 

class DM_Attribute_List(BaseModel):
    uuid:                   UUID
    attribute_uuid:         UUID
    keyid:                  str
    list_order:             int
    is_active:              bool
    icon_uuid:              UUID|None
    name:                   str|None
    class Config:
        orm_mode = True 

class DM_Attribute_Tree(BaseModel):
    uuid:                   UUID
    parent_uuid:            UUID|None
    attribute_uuid:         UUID
    keyid:                  str
    node_order:             int
    is_active:              bool
    icon_uuid:              UUID|None
    name:                   str|None
    class Config:
        orm_mode = True 


 