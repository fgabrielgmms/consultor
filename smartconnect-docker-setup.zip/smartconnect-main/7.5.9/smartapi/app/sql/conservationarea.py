from .smartdbsession import smartDbSession
from typing import Annotated
from uuid import UUID
from geoalchemy2 import functions as geofunc


def query_cas(
                db:             smartDbSession,
                #language_uuid:  Annotated[UUID, "Language ID"],
                cas:            Annotated[list[UUID], "List of CAs from access token"]                            
            ):
    #db.set_default_language(language_uuid=language_uuid)
    if cas:
        return db.getSession().query(db.conservation_area).where(db.conservation_area.c.uuid.in_(cas)).all()
    else:
        return db.getSession().query(db.conservation_area).all()
        
def query_ca_properties(db:             smartDbSession,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    ):
    return db.getSession().query(
                db.conservation_area_property
            ).where(db.conservation_area_property.c.ca_uuid == ca_uuid).all()


def query_ca_geometries(
                        db:             smartDbSession,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        area_type:      Annotated[str|None, "Area Type"] = None,
                        keyid:          Annotated[str| None, "Keyid"] = None,
                    ):
    
    query = db.getSession().query(
                    db.area_geometries.c.uuid, 
                    db.area_geometries.c.ca_uuid, 
                    db.area_geometries.c.area_type,
                    db.area_geometries.c.keyid, 
                    geofunc.ST_AsText(geofunc.ST_Force2D(db.area_geometries.c.geom)).label("geometry"),
                    geofunc.ST_AsEWKT(geofunc.ST_GeomFromEWKB(db.area_geometries.c.geom)).label("geometry2")
                ).where(db.area_geometries.c.ca_uuid == ca_uuid)
    
    if area_type:
        query = query.where(db.area_geometries.c.area_type == area_type)

    if keyid:
        query = query.where(db.area_geometries.c.keyid == keyid)
    
    return query.all()
    