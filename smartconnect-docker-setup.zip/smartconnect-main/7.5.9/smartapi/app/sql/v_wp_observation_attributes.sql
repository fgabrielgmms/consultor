-- View: reporting.v_wp_observation_attributes

-- DROP VIEW reporting.v_wp_observation_attributes;

CREATE OR REPLACE VIEW reporting.v_wp_observation_attributes
 AS
 SELECT wpoa.*, 
 		t1.value as attribute_name, t1.language_uuid as attribute_language_uuid, 
		t2.value as list_element_name, t2.language_uuid as list_element_language_uuid, 
		t3.value as tree_node_name, t3.language_uuid as tree_node_language_uuid
 	FROM smart.wp_observation_attributes as wpoa
	
	LEFT JOIN smart.i18n_label as t1 on wpoa.attribute_uuid = t1.element_uuid --and t1.language_uuid = l.uuid
	LEFT JOIN smart.i18n_label as t2 on wpoa.list_element_uuid = t2.element_uuid --and t2.language_uuid = l.uuid
	LEFT JOIN smart.i18n_label as t3 on wpoa.tree_node_uuid = t3.element_uuid; --and t3.language_uuid = l.uuid;
	
	--JOIN smart.language as l on t1.language_uuid = l.uuid or t2.language_uuid = l.uuid or t3.language_uuid = l.uuid;
    
ALTER TABLE reporting.v_wp_observation_attributes
    OWNER TO postgres;

GRANT ALL ON TABLE reporting.v_wp_observation_attributes TO postgres;

select * from reporting.v_wp_observation_attributes where 
attribute_language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8' and list_element_language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'  and tree_node_language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8';