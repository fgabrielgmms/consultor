from typing import Annotated

from fastapi import FastAPI, HTTPException, APIRouter, status, Depends, Security
from fastapi.security import (
    OAuth2PasswordBearer, 
    OAuth2PasswordRequestForm,
    SecurityScopes
)
from pydantic import BaseModel, ValidationError
from main import app, oauth2_scheme

from sqlalchemy import select, union, union_all, func, String
from sql import database
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone

from jose import JWTError, jwt
from passlib.context import CryptContext
from uuid import UUID
from config import get_settings
import re
from enum import Enum, auto, StrEnum
import logging
#from password_policy.data import SimplePCP

#SECRET_KEY = get_settings().SECRET_KEY
#ALGORITHM = get_settings().ALGORITHM
#ACCESS_TOKEN_EXPIRE_MINUTES = get_settings().ACCESS_TOKEN_EXPIRE_MINUTES

        

# The `Token` class defines attributes for an access token and its type.
class Token(BaseModel):
    access_token: str
    token_type: str


# The `TokenData` class defines a data structure with a username attribute that can be a string or
# None, and a scopes attribute that is a list of strings.
class TokenData(BaseModel):
    username: str | None = None
    scopes: list[str] = []

class enum_scopes(StrEnum):
    me         = 'me'
    admin      = 'admin'
    caadmin    = 'caadmin'     # ca_uuid
    addca      = 'addca'
    viewca     = 'viewca'      # ca_uuid
    updateca   = 'updateca'    # ca_uuid
    deleteca   = 'deleteca'
    viewalerts = 'viewalerts'
    createalerts = 'createalerts'
    updatealerts = 'updatealerts'
    deletealerts = 'deletealerts'
    runquery = 'runquery'
    runadvintelquery = 'runadvintelquery'
    advintelviewdata = 'advintelviewdata'
    viewdataqueue = 'viewdataqueue'
    deletedataqueue = 'deletedataqueue'
    processdataqueue = 'processdataqueue'
    adddataqueue = 'adddataqueue'
    runreport = 'runreport'
    ctapikey = 'ctapikey'
    customquery = 'customquery'




# The `User` class defines attributes and methods for managing user permissions and extracting
# resources based on scopes.
class User(BaseModel):
    uuid:               UUID
    username:           str
    email:              str | None = None
    home_ca_uuid:       UUID | None = None
    default_basemaps:   str | None = None
    #disabled:   bool|None = False
    scopes:             list[str]|None

    def extract_resource_from_scopes(self, action:str) -> list[UUID]:
        """
        The function extracts resources from a list of scopes based on a specified action.
        
        :param action: The `action` parameter in the `extract_resource_from_scopes` method is a string
        that represents the action for which you want to extract the resources from the scopes. It is
        used to create a regex pattern to match against the scopes in order to extract the relevant
        resources
        :type action: str
        :return: The function `extract_resource_from_scopes` returns a list of UUIDs extracted from the
        scopes based on the provided action.
        """
        resources: list[UUID]= []
        pattern = f'{action}:(.*)'
        for s in self.scopes:
            match = re.search(pattern, s)
            match = re.findall(pattern, s)
            if match:
                print(match[0])
                if match[0] != 'None':
                    resources.append(UUID(match[0]))

        return resources
    
    def check_permission(self, scope:str, obj_uuid: UUID|None):
        """
        Checks if the user has permission to a specific scope.
        Raises HTTPExeception if permission check failed
        """
        obj_uuids = self.extract_resource_from_scopes(scope)
        if "admin:None" not in self.scopes and obj_uuid not in obj_uuids:
            logging.warn(f"Access denied to user {self.username} on scope {scope}:{obj_uuid}")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Permission denied",
                #headers={"WWW-Authenticate": authenticate_value},
            )
        logging.info(f"Access granted to user {self.username} on scope {scope}:{obj_uuid}")




class UserInDB(User):
    password:   str
    

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")




def get_smart_connect_user(
            username: str, 
            db: Session
    ):

    user = db.query(database.connect_users).where(database.connect_users.c.username == username).first()
    
    if user:
        user_dict = user._asdict()
        # Now load the user and role actions as scopes
        #scopes = ["cas", "me"]
        actions = db.execute(union_all(
                                select(
                                        database.connect_user_actions.c.action,
                                        func.cast(database.connect_user_actions.c.resource, String)
                                    ).where(database.connect_user_actions.c.username == username),
                                select(
                                    database.connect_role_actions.c.action,
                                    func.cast(database.connect_role_actions.c.resource, String)
                                ).join( database.connect_user_roles,
                                       onclause=database.connect_role_actions.c.role_id == database.connect_user_roles.c.role_id
                                       ).where(database.connect_user_roles.c.username == username))
            ).fetchall()
        print(actions)
        # Generate the scopes list
        #scopes: list[str] =['me','cas']
        scopes: list[str] =[]
        for action,resource in actions: scopes.append(f'{action}:{resource}')
        
        user = UserInDB(**user_dict, scopes=scopes)
        return user
    
def check_password_strength(password, MIN_PASSWORD_LENGTH=8, REQUIRED_CHARACTER_TYPES=4):
    """Check if a password meets the defined policies and give random advice."""
    
    if len(password) < MIN_PASSWORD_LENGTH:
        logging.debug(f"Password should be at least {MIN_PASSWORD_LENGTH} characters long.")
    else:
        # Check for the presence of different character types
        character_types = 0
        if re.search(r'\d', password):
            character_types += 1
        else:
            logging.debug("Include at least one number.")

        if re.search(r'[A-Z]', password):
            character_types += 1
        else:
            logging.debug("Include at least one uppercase letter.")

        if re.search(r'[a-z]', password):
            character_types += 1
        else:
            logging.debug("Include at least one lowercase letter.")

        if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            character_types += 1
        else:
            logging.debug("Include at least one special character.")

        if character_types >= REQUIRED_CHARACTER_TYPES:
            logging.debug("Great! Your password meets the strength criteria.")
            return True

    return False

def verify_password(username, plain_password, hashed_password):
    if get_settings().ENABLE_STRICT_PW_CHECKS and not check_password_strength(plain_password):
        # If strcit password check is enable, weak password will not be sucessfully verified
        # and a waring will be logged
        #SimplePCP().validate(plain_password)
        logging.warn(f"Access denied to user {username} because of weak password!")
        return False
    
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)



def authenticate_user(username: str, password: str, db: Session):
    user= get_smart_connect_user(username=username, db=db)
    if not user:
        return False
    if not verify_password(username, password, user.password):
        return False
    
    return user


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, get_settings().SECRET_KEY, algorithm=get_settings().ALGORITHM)
    return encoded_jwt


async def get_current_user(security_scopes: SecurityScopes, 
                           token: Annotated[str, Depends(oauth2_scheme)],
                           db: Session = Depends(database.get_db)):
    if security_scopes.scopes:
        authenticate_value = f'Bearer scope="{security_scopes.scope_str}"'
    else:
        authenticate_value = "Bearer"
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": authenticate_value},
    )
    
    try:
        payload = jwt.decode(token, get_settings().SECRET_KEY, algorithms=[get_settings().ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_scopes = payload.get("scopes", [])
        token_data = TokenData(scopes=token_scopes, username=username)
    except (JWTError, ValidationError):
        raise credentials_exception
    user = get_smart_connect_user(username=token_data.username, db=db)
    if user is None:
        raise credentials_exception
    
    print(security_scopes.scopes)
    print(token_data.scopes)
    #authorized = False
    for scope in security_scopes.scopes:
        for s in token_data.scopes:
            if re.match(scope, s):
                return user
            
    #if scope not in token_data.scopes:
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not enough permissions",
        headers={"WWW-Authenticate": authenticate_value},
    )
    return user


async def get_current_active_user(
    current_user: Annotated[User, Security(get_current_user, scopes=["me"])],
    db: Session = Depends(database.get_db)
):
    #if current_user.disabled:
    #    raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


@app.post("/token")
async def login_for_access_token(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
    db: Session = Depends(database.get_db)
) -> Token:
    user  = authenticate_user(form_data.username, form_data.password, db=db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=get_settings().ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={  "sub": user.username, 
                #"scopes": form_data.scopes
                "scopes": user.scopes
                }, 
        expires_delta=access_token_expires
    )
    return Token(access_token=access_token, token_type="bearer")


@app.get("/users/me/", response_model=User, include_in_schema=False)
async def read_users_me(
    current_user: Annotated[User, Depends(get_current_active_user)]
):
    return current_user


@app.get("/users/me/items/", include_in_schema=False)
async def read_own_items(
    current_user: Annotated[User, Security(get_current_active_user, scopes=["items"])]
):
    return [{"item_id": "Foo", "owner": current_user.username}]