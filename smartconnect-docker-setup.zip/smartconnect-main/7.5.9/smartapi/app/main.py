from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
#from .dependencies import get_query_token, get_token_header
#from .internal import admin
from internal.exception_handler import ArithmeticError_exception_handler,SQLAlchemyError_exception_handler
from sqlalchemy import exc

import logging
from docs.export_project_docs import markdown_exporter

from config import Settings,get_settings

app = FastAPI(#dependencies=[Depends(get_query_token)]
              debug=get_settings().FASTAPI_DEBUGMODE,
              title="SMART Data Access API",
              #summary="",
              #description='SMART\n# SMART Partnership\n## SMART Data API\n',
              #description=markdown_exporter.export_md_files_as_text(),
              version="1.0",
              swagger_ui_parameters={"defaultModelsExpandDepth": 1},              
              root_path="/smartapi/"
            )

logging.basicConfig(level=logging.DEBUG, filename='smartapi.log', filemode='a', format='%(asctime)s - %(levelname)s - %(message)s')

# Add specialized exception handlers
app.add_exception_handler(ArithmeticError, ArithmeticError_exception_handler)
app.add_exception_handler(exc.SQLAlchemyError, SQLAlchemyError_exception_handler)


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token", 
                  # scopes={
                  #           "me": "Read information bout the current user",
                  #           "cas": "Read list of CAs"
                  #       }
                  )

from routers import employee,conservationarea,patrol,language,agency,observations,datamodell,efforts,query,track,dataqueue,attachment,patrol_transport,mandate,patrol_transport,team,station
import user

app.include_router(language.router)
app.include_router(agency.router)
app.include_router(employee.router)
app.include_router(conservationarea.router)
app.include_router(patrol.router)
app.include_router(observations.router)
app.include_router(team.router)
#app.include_router(transporttype.router)
app.include_router(station.router)
app.include_router(datamodell.router)
app.include_router(efforts.router)
app.include_router(mandate.router)
app.include_router(patrol_transport.router)
app.include_router(query.router)
app.include_router(track.router)
app.include_router(dataqueue.router)
app.include_router(attachment.router)