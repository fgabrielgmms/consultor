from fastapi.responses import JSONResponse
from requests import Request
from sqlalchemy import exc

# https://blog.marzeta.pl/maximizing-reliability-in-fastapi-global-exception-handling

async def ArithmeticError_exception_handler(request: Request, exc: ArithmeticError):
    return JSONResponse(
        status_code=500,
        content={"message": "ArithmeticError"},
    )
    
    
async def SQLAlchemyError_exception_handler(request: Request, exc: exc.SQLAlchemyError):
    print (exc)
    return JSONResponse(
        status_code=500,
        content={"message": "SQLAlchemyError"},
    )