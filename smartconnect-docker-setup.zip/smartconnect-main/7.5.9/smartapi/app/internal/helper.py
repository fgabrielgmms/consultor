import time
import json
import datetime
import geopandas as gpd
from uuid import UUID
from user import User


def format_observations(df:gpd.GeoDataFrame):
        g = df.groupby(["waypoint_datetime", "patrol_uuid", "patrol_id","waypoint_id", "wpo_uuid", "dmc_uuid", "category_name","geom"]) #"dmc_uuid", "dma_keyid"
        nObs: int = len(g.groups)
        
        observations = []
        n: int = 0
        t1 = time.perf_counter(), time.process_time()
        
        for x,obs in g:
            n=n+1
            r = dict()   

            r["geometry"] = x[7]
            r['smart_type'] = 'SMART_Observation'
            r["waypoint_datetime"] = x[0]
            r["patrol_uuid"] = x[1]
            r["patrol_id"] = x[2]
            r["waypoint_id"] = x[3]
            r["waypoint_uuid"] = x[4]
            r["category_uuid"] = x[5]
            r["category_name"] = x[6]
            
            
            attributes = dict() 
            attributes_uuids = dict()
            attributes2 = []
            for y in obs.iloc():
                attribute = dict()

                attribute_name = y['wpoa_attribute_name']
                attribute_uuid = y['wpoa_attribute_uuid']
                attribute['uuid'] = y['wpoa_attribute_uuid']
                attribute['name'] = y['wpoa_attribute_name']
                attribute['type'] = y.dma_att_type
                
                if y.dma_att_type == 'LIST':
                    attributes[attribute_name] = y['wpoa_list_element_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_list_element_name']
                    attribute['value'] = y['wpoa_list_element_name']
                    attribute['value_uuid'] = y['wpoa_list_element_uuid']
                elif y['dma_att_type'] == 'NUMERIC':
                    attributes[attribute_name] = y['wpoa_number_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_number_value']
                    attribute['value'] = y['wpoa_number_value']

                elif y['dma_att_type'] == 'STRING':
                    attributes[attribute_name] = y['wpoa_string_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_string_value']
                    attribute['value'] = y['wpoa_string_value']
                else:
                    attributes[attribute_name] = y['wpoa_tree_node_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_tree_node_name']
                    attribute['value'] = y['wpoa_tree_node_name']
                    attribute['value_uuid'] = y['wpoa_tree_node_uuid']
                attributes2.append(attribute)

            r["attributes"] = attributes
            r["attribute_uuids"] = attributes_uuids
            r["attributes2"] = attributes2

                
            #print(r)
            observations.append(r)

        t2 = time.perf_counter(), time.process_time()

        print(f" Real time: {t2[0] - t1[0]:.2f} seconds")
        print(f" CPU time: {t2[1] - t1[1]:.2f} seconds")
        print()

        return gpd.GeoDataFrame.from_dict(observations,geometry="geometry")._to_geo()
    

def format_patrol(df:gpd.GeoDataFrame):
        g = df.groupby(["waypoint_datetime", "patrol_uuid", "patrol_id","waypoint_id", "wpo_uuid", "dmc_uuid", "category_name","geom"]) #"dmc_uuid", "dma_keyid"
        nObs: int = len(g.groups)
        
        observations = []
        n: int = 0
        t1 = time.perf_counter(), time.process_time()
        
        for x,obs in g:
            n=n+1
            r = dict()   

            r["geometry"] = x[7]
            r['smart_type'] = 'SMART_Observation'
            r["waypoint_datetime"] = x[0]
            r["patrol_uuid"] = x[1]
            r["patrol_id"] = x[2]
            r["waypoint_id"] = x[3]
            r["waypoint_uuid"] = x[4]
            r["category_uuid"] = x[5]
            r["category_name"] = x[6]
            
            
            attributes = dict() 
            attributes_uuids = dict()
            attributes2 = []
            for y in obs.iloc():
                attribute = dict()

                attribute_name = y['wpoa_attribute_name']
                attribute_uuid = y['wpoa_attribute_uuid']
                attribute['uuid'] = y['wpoa_attribute_uuid']
                attribute['name'] = y['wpoa_attribute_name']
                attribute['type'] = y.dma_att_type
                
                if y.dma_att_type == 'LIST':
                    attributes[attribute_name] = y['wpoa_list_element_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_list_element_name']
                    attribute['value'] = y['wpoa_list_element_name']
                    attribute['value_uuid'] = y['wpoa_list_element_uuid']
                elif y['dma_att_type'] == 'NUMERIC':
                    attributes[attribute_name] = y['wpoa_number_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_number_value']
                    attribute['value'] = y['wpoa_number_value']

                elif y['dma_att_type'] == 'STRING':
                    attributes[attribute_name] = y['wpoa_string_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_string_value']
                    attribute['value'] = y['wpoa_string_value']
                else:
                    attributes[attribute_name] = y['wpoa_tree_node_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_tree_node_name']
                    attribute['value'] = y['wpoa_tree_node_name']
                    attribute['value_uuid'] = y['wpoa_tree_node_uuid']
                attributes2.append(attribute)

            r["attributes"] = attributes
            r["attribute_uuids"] = attributes_uuids
            r["attributes2"] = attributes2

                
            #print(r)
            observations.append(r)

        t2 = time.perf_counter(), time.process_time()

        print(f" Real time: {t2[0] - t1[0]:.2f} seconds")
        print(f" CPU time: {t2[1] - t1[1]:.2f} seconds")
        print()

        return gpd.GeoDataFrame.from_dict(observations,geometry="geometry")._to_geo()
    
    
    
