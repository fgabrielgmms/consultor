from uuid import UUID
import datetime
from pydantic import BaseModel
import geopandas as gpd
#from ..employee import Employee


def __init__():
    return

class Track(BaseModel):
    uuid:               UUID
    patrol_leg_day_uuid:    UUID 
    geometry:           gpd.GeoSeries
    distance:           float

class PatrolLegDay(BaseModel):
    uuid:               UUID
    patrol_leg_uuid:    UUID
    patrol_day:         datetime.date
    start_time:         datetime.time
    end_time:           datetime.time
    rest_minutes:       int
    track:              Track


class PatrolLeg(BaseModel):
     uuid:              UUID
     patrol_uuid:       UUID
     start_date:        datetime.date
     end_date:          datetime.date
     transport_uuid:    UUID
     id:                str
     mandate_uuid:      UUID
     patrol_leg_days:   list[PatrolLegDay]

class Patrol(BaseModel):
     uuid:          UUID
     ca_uuid:       UUID
     id:            str
     station_uuid:  UUID
     team_uuid:     UUID
     objective:     str
     patrol_type:   UUID
     is_armed:      bool
     start_date:    datetime.date
     end_date:      datetime.date
     comment:       str
     patrol_legs:   list[PatrolLeg]
     #employees:     list[Employee]
