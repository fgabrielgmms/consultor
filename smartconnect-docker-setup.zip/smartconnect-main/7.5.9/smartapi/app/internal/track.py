from pydantic import BaseModel
import shapely
import math
from datetime import timedelta


class Track(BaseModel):

    def __init__(self, geometry):
        self.geometry = geometry

    # Function to calculate distance between two points
    def _calculate_distance(self, point1: shapely.Point, point2: shapely.Point):
        return point1.distance(point2)

    # Function to calculate speed
    def _calculate_speed(self, distance, time_difference):
        """
        The `_calculate_speed` function calculates speed based on distance and time difference, returning
        None if the time difference is 0.
        
        :param distance: Distance is the total distance traveled by an object
        :param time_difference: The `time_difference` parameter represents the difference in time between
        two events. It is used in the `_calculate_speed` method to calculate the speed by dividing the
        distance traveled by the time difference. If the `time_difference` is 0, the method will return
        `None` to avoid division by
        :return: The function `_calculate_speed` returns the speed calculated as the distance divided by
        the time difference, unless the time difference is 0, in which case it returns `None`.
        """
        return distance / time_difference if time_difference != 0 else None

    # Function to calculate direction (bearing) between two points
    def _calculate_direction(self, point1: shapely.Point, point2: shapely.Point):
        x_diff = point2.x - point1.x
        y_diff = point2.y - point1.y
        return math.atan2(y_diff, x_diff) * (180 / math.pi)
        
    def calculate_speed_and_bearing(self):
        # Initialize empty lists to store results
        id_list = []
        start_timestamp_list = []
        end_timestamp_list = []
        distance_list = []
        time_difference_list = []
        speed_list = []
        direction_list = []

        #gdf = gdf.explode()
        #geometry = geometry.explode()
        # Iterate through each row of the GeoDataFrame
        #for idx, row in gdf.iterrows():
            #multi_line = row['geometry']
            #timestamps = [point.z for line in multi_line for point in line.coords[0]]

            #for line in multi_line:
        line = self.geometry
        for i in range(len(line.coords) - 1):
            start_point = shapely.Point(line.coords[i])
            end_point = shapely.Point(line.coords[i + 1])

            start_timestamp = shapely.get_z(start_point)
            end_timestamp = shapely.get_z(end_point)

            distance = _calculate_distance(start_point, end_point)
            time_difference = end_timestamp - start_timestamp
            speed = _calculate_speed(distance, time_difference)
            direction = _calculate_direction(start_point, end_point)

            # Append results to lists
            #id_list.append(row['id'])
            start_timestamp_list.append(start_timestamp)
            end_timestamp_list.append(end_timestamp)
            distance_list.append(distance)
            time_difference_list.append(time_difference)
            speed_list.append(speed)
            direction_list.append(direction)

        # Create a new DataFrame with the results
        result_df = pd.DataFrame({
            #'id': id_list,
            'start_timestamp': start_timestamp_list,
            'end_timestamp': end_timestamp_list,
            'distance': distance_list,
            'time_difference': time_difference_list,
            'speed': speed_list,
            'direction': direction_list
        })



        return result_df