from fastapi import Depends, FastAPI, HTTPException, APIRouter, Security, Query
from fastapi.responses import JSONResponse
#from api import app, oauth2_scheme
from typing import Annotated, List

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

#from pydantic import BaseModel
from pydantic import TypeAdapter

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
import requests
import json
import datetime
import pandas as pd
import geopandas as gpd
from internal.helper import format_observations, format_patrol
#from .employee import Employee
#from ..internal.classes import Patrol

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from geoalchemy2 import functions as geofunc
from datetime import timedelta
import sql.crud
from internal import track
from user import User, get_current_active_user
import numpy as np
from math import radians, sin, cos, sqrt, atan2, degrees
from pyproj import Proj, transform
from pydantic import BaseModel
import datetime
from config import Settings,get_settings

router = APIRouter(
    prefix="/track",
    tags=["track"],
    responses={404: {"description": "Not found"}},
)

# Function to calculate distance between two points using Haversine formula
def haversine_distance(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    radius_earth = 6371000  # Radius of Earth in meters
    distance = radius_earth * c
    return distance

def calculate_heading(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Calculate differences in longitude and latitude
    dlon = lon2 - lon1
    dlat = lat2 - lat1

    # Calculate bearing using atan2
    y = sin(dlon) * cos(lat2)
    x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dlon)
    initial_bearing = atan2(y, x)

    # Convert bearing from radians to degrees
    initial_bearing = degrees(initial_bearing)
    compass_bearing = (initial_bearing + 360) % 360

    return compass_bearing

class Track_speed(BaseModel):
    track_id:             int
    speed:          float
    distance:       float
    time:           float
    heading:        float
    point1_lon:     float
    point1_lat:     float
    point1_timestamp:   str
    point2_lon:     float
    point2_lat:     float
    point2_timestamp:   str
    status:         str
    
class Track_Speed2(BaseModel):
    track_id:       int
    waypoint_id:    int         
    speed:          float|None  # Speed in m/s to the next waypoint. None if last
    distance:       float|None  # Distance to next waypoint. None if last
    time:           float|None  # Time till next waypoint. None if last
    heading:        float|None  # Heading in Degrees to the next waypoint, None if last
    lon:            float       # Latitude
    lat:            float       # Longitude
    timestamp:      str         # Timestamp
    status:         str 
        
    
@router.get("/verify/", response_model=list[Track_speed], include_in_schema=get_settings().DEV_INCLUDE_IN_SCHEMA)
async def get_track(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
            language_uuid:  Annotated[UUID, "Conservation Area ID"],
                        
            patrol_id: Annotated[str|None, "Patrol ID"] = None,
            track_uuid: Annotated[UUID|None, "track_uuid"] = None,
            #current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            
            db: Session = Depends(database.get_db) 
    ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                #.join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                #.join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid )
    )
    q = select(
                            database.patrol.c.uuid.label("uuid"),
                            database.patrol.c.id.label("id"),
                            database.patrol_leg.c.uuid.label('patrol_leg_uuid'),
                            database.patrol_leg.c.id.label('patrol_leg_id'),
                            database.patrol_leg_day.c.patrol_day.label('patrol_leg_day_day'),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("patrol_leg_day_start"),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("patrol_leg_day_end"),
                            #(database.patrol_leg_members.c.employee_uuid).label("patrol_leader_uuid"),
                            #(database.employee.c.givenname + ' ' + database.employee.c.familyname).label("patrol_leader_name"),
                            (database.track.c.distance).label("distance"),
                            (database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            ((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            #geofunc.ST_AsText(geofunc.ST_Force2D(database.track.c.geometry)).label("track"),
                            geofunc.ST_AsText(geofunc.ST_Force3D(database.track.c.geometry)).label("track"),
                            
                            geofunc.ST_Force2D(database.track.c.geometry).label("geometry"),
                            database.track.c.distance
    ).select_from(j)
    if track_uuid:
        q = q.where(database.track.c.uuid == track_uuid)
    if patrol_id:
        q = q.where(database.patrol.c.id == patrol_id)
    try:
        rows = db.execute(q).all()
        
    except Exception as e:
        print(e)
        return e
    if len(rows) == 0:
        raise HTTPException(status_code=404, detail="No Track found")
    
    
    df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
    print(f"Database Distance: {df['distance'][0]}")
    # Convert Track to geomety
    df['geometry'] = df.apply(lambda row: shapely.from_wkt(row.track), axis=1)
    df.set_geometry('geometry', inplace=True, crs=4326)  

    gdf = df.explode()
    #print(gdf.head())
    #print(gdf.geometry.values[0].length)
    #df['speed_and_bearing'] = df2.apply(lambda row: track.Track(row.geometry).calculate_speed_and_bearing(), axis=1)
    
    #linestring = gdf.geometry.iloc[0]
    dfResult = []
    track_id = 0
    for linestring in gdf.geometry.iloc:
        # Iterate over all points in the LineString
        track_id = track_id + 1
        p2 = None
        total_distance = 0.0
        id = 0
        for point in linestring.coords:
            if p2 is not None:
                # Create Shapely Point objects for the current and previous points
                
                current_point = shapely.Point(point[0], point[1])  # Ignore Z coordinate
                prev_point = shapely.Point(p2[0], p2[1])  # Ignore Z coordinate
                
                    # Extract coordinates of current and previous points
                lat1, lon1 = p2[1], p2[0]  # Extracting lat, lon from (lon, lat)
                lat2, lon2 = point[1], point[0]  # Extracting lat, lon from (lon, lat)
        
                # Calculate the distance between the current point and the previous point using Haversine formula
                distance = haversine_distance(lat1, lon1, lat2, lon2)
                heading = calculate_heading(lat1, lon1, lat2, lon2)
                
                timediff = (point[2] - p2[2]) / 1000
                
                speed = distance / timediff * 3.6      # Speed in km/h
                
                status = 'Ok'
                if speed > 10:
                    status = 'Speed to high'
                
                id = id + 1
                row = {'track_id' : track_id, 'speed': speed, 'distance': distance, 'time':timediff, 'heading': heading,
                    'point1_lat':     p2[1],
                    'point1_lon':     p2[0],
                    'point1_timestamp': datetime.datetime.utcfromtimestamp(p2[2]/1000).strftime('%Y-%m-%d %H:%M:%S'),
                    
                    'point2_lat':     point[1],
                    'point2_lon':     point[0],
                    #'point1_timestamp': datetime.datetime(point[2]/1000),             
                    #'point2_timestamp': point[2],             
                    'point2_timestamp': datetime.datetime.utcfromtimestamp(point[2]/1000).strftime('%Y-%m-%d %H:%M:%S'),
                    'status': status
                }
                
                dfResult.append(row)
                
                total_distance += distance
                
            p2 = point

        print("Total distance:", total_distance)

    return dfResult
    
    
@router.get("/speed-bearing/", response_model=list[Track_Speed2], include_in_schema=get_settings().DEV_INCLUDE_IN_SCHEMA)
async def get_track(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
            language_uuid:  Annotated[UUID, "Conservation Area ID"],

            patrol_id: Annotated[str|None, "Patrol ID"] = None,
            track_uuid: Annotated[UUID|None, "track_uuid"] = None,
            #current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            
            db: Session = Depends(database.get_db) 
    ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                #.join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                #.join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid )
    )
    q = select(
                            database.patrol.c.uuid.label("uuid"),
                            database.patrol.c.id.label("id"),
                            database.patrol_leg.c.uuid.label('patrol_leg_uuid'),
                            database.patrol_leg.c.id.label('patrol_leg_id'),
                            database.patrol_leg_day.c.patrol_day.label('patrol_leg_day_day'),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("patrol_leg_day_start"),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("patrol_leg_day_end"),
                            #(database.patrol_leg_members.c.employee_uuid).label("patrol_leader_uuid"),
                            #(database.employee.c.givenname + ' ' + database.employee.c.familyname).label("patrol_leader_name"),
                            (database.track.c.distance).label("distance"),
                            (database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            ((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            #geofunc.ST_AsText(geofunc.ST_Force2D(database.track.c.geometry)).label("track"),
                            geofunc.ST_AsText(geofunc.ST_Force3D(database.track.c.geometry)).label("track"),
                            
                            geofunc.ST_Force2D(database.track.c.geometry).label("geometry"),
                            database.track.c.distance
    ).select_from(j)
    if track_uuid:
        q = q.where(database.track.c.uuid == track_uuid)
    if patrol_id:
        q = q.where(database.patrol.c.id == patrol_id)
    try:
        rows = db.execute(q).all()
        
    except Exception as e:
        print(e)
        return e
    if len(rows) == 0:
        raise HTTPException(status_code=404, detail="No Track found")
    
    
    df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
    print(f"Database Distance: {df['distance'][0]}")
    # Convert Track to geomety
    df['geometry'] = df.apply(lambda row: shapely.from_wkt(row.track), axis=1)
    df.set_geometry('geometry', inplace=True, crs=4326)  

    gdf = df.explode()
    #print(gdf.head())
    #print(gdf.geometry.values[0].length)
    #df['speed_and_bearing'] = df2.apply(lambda row: track.Track(row.geometry).calculate_speed_and_bearing(), axis=1)
    
    #linestring = gdf.geometry.iloc[0]
    dfResult = []
    track_id = 0
    for linestring in gdf.geometry.iloc:
        # Iterate over all points in the LineString
        track_id = track_id + 1
        p2 = None
        total_distance = 0.0
        id = 0
        for point in linestring.coords:
            if p2 is not None:
                # Create Shapely Point objects for the current and previous points
                
                current_point = shapely.Point(point[0], point[1])  # Ignore Z coordinate
                prev_point = shapely.Point(p2[0], p2[1])  # Ignore Z coordinate
                
                    # Extract coordinates of current and previous points
                lat1, lon1 = p2[1], p2[0]  # Extracting lat, lon from (lon, lat)
                lat2, lon2 = point[1], point[0]  # Extracting lat, lon from (lon, lat)
        
                # Calculate the distance between the current point and the previous point using Haversine formula
                distance = haversine_distance(lat1, lon1, lat2, lon2)
                heading = calculate_heading(lat1, lon1, lat2, lon2)
                
                timediff = (point[2] - p2[2]) / 1000
                
                speed = distance / timediff * 3.6      # Speed in km/h
                
                status = 'Ok'
                if speed > 10:
                    status = 'Speed to high'
                
                id = id + 1
                row = {'track_id' : track_id, 'speed': speed, 'distance': distance, 'time':timediff, 'heading': heading,
                    'point1_lat':     p2[1],
                    'point1_lon':     p2[0],
                    'point1_timestamp': datetime.datetime.utcfromtimestamp(p2[2]/1000).strftime('%Y-%m-%d %H:%M:%S'),
                    
                    'point2_lat':     point[1],
                    'point2_lon':     point[0],
                    #'point1_timestamp': datetime.datetime(point[2]/1000),             
                    #'point2_timestamp': point[2],             
                    'point2_timestamp': datetime.datetime.utcfromtimestamp(point[2]/1000).strftime('%Y-%m-%d %H:%M:%S'),
                    'status': status
                }
                
                dfResult.append(row)
                
                total_distance += distance
                
            p2 = point

        print("Total distance:", total_distance)

    return dfResult
        