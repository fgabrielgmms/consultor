from fastapi import APIRouter, Depends, Security,Query
from user import User, get_current_active_user
from typing import Annotated,List

from pydantic import BaseModel

import datetime

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from fastapi.responses import JSONResponse

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database

import sql.agency

router = APIRouter(
    prefix="/agency",
    tags=["agency"],
    responses={404: {"description": "Not found"}},
)


    
# @router.get("/", response_model=list[schemas.Agency])
# def get_agencies(
#                 current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
#                 ca_uuid: Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
#                 language_uuid: Annotated[UUID, "Language UUID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'), 
#                 db = Depends(database.get_smart_db)) :
#     try:
#         current_user.check_permission("viewca", ca_uuid)

#         rows = sql.agency.query_agencies(db=db, ca_uuid=ca_uuid,language_uuid=language_uuid)     
#         return rows   
#     except Exception as e:
#         print(e)
#         raise HTTPException(status_code=500, detail=e)
    
    
@router.get("/") #, response_model=list[schemas.Agency])
#@router.get("/", response_class=JSONResponse)
async def get_agencies(
                current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                language_uuid:  Annotated[UUID, "Language UUID"], 
                agency_uuids:   Annotated[List[UUID], Query(description="List of agency UUIDs")] = [], 
                db =            Depends(database.get_smart_db)) :
    try:
        current_user.check_permission("viewca", ca_uuid)

        rows = await sql.agency.query_agencies(db=db, ca_uuid=ca_uuid,language_uuid=language_uuid,agency_uuids=agency_uuids)    
        # Return only the first row
        print(rows)
        return [_r._asdict() for _r in rows]        
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=e)
    
    
