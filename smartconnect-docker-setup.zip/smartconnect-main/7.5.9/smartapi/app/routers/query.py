from fastapi import APIRouter, Security, Depends
from user import User, get_current_active_user

from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session
from enum import Enum, auto
import requests
import json
from config import Settings, get_settings
#import SMARTConnect as sc


router = APIRouter(
    prefix="/query",
    tags=["query"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class query_type(str, Enum):
    all = "all"
    patrolobservation = 'patrolobservation'
    #'patrolquery', 'patrolwaypoint', 'patrolsummary', 'patrolgrid', 'observationobservation', 'observationwaypoint', 'observationsummary', 'observationgrid', 'entityobservation', 'entitywaypoint', 'entitysummary', 'entitygrid', 'surveyobservation', 'surveywaypoint', 'surveysummary', 'surveygrid', 'surveymission', 'surveymissiontrack', 'assetobservation', 'assetwaypoint', 'assetsummary', 'assetdeploymentsummary', 'compound'
    PatrolSummaryQuery = "patrolsummary"
    "asset_observation_query"
    "asset_summary_query"
    "asset_waypoint_query"
    "compound_query"
    "entity_gridded_query"
    "entity_observation_query"
    "entity_summary_query"
    "entity_waypoint_query"
    grid = "gridded_query"
    "i_entity_record_query"
    "i_entity_summary_query"
    "i_record_obs_query"
    "i_record_query"
    "i_record_summary_query"
    "i_working_set_query"
    observation = "observation_query"
    "obs_gridded_query"
    "obs_observation_query"
    "obs_summary_query"
    "obs_waypoint_query"
    patrol = "patrol_query"
    "report_query"
    "r_query"
    "summary_query"
    "survey_gridded_query"
    "survey_mission_query"
    "survey_mission_track_query"
    "survey_observation_query"
    "survey_summary_query"
    "survey_waypoint_query"
    waypoint = "waypoint_query"



@router.get("/")
async def get_queries(
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    language_uuid: Annotated[UUID, "Conservation Area ID"] = '2af26704-7dd9-4a77-bbd4-c1953800d4f8',
                    querytype: query_type = query_type.all,
                    db:             Session = Depends(database.get_db)

                 ):
    """
    Generates a list of all queries to the user is allowed to run
    """
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    
    
    settings: Settings = get_settings()

    session = requests.Session()
        
    session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
    url = settings.SMART_CONNECT_URL
    
    response = session.get(url=f'{url}/api/querytype?ca={ca_uuid}', verify=False)
    querytypes = json.loads(response.text)
    print(querytypes)
    
    params = {'ca': ca_uuid}

    if querytype != query_type.all:
        params['type'] = querytype

    response = session.get(url=f'{url}/api/query', params=params, verify=False )
    if response.ok:
        print(response.text)
        return json.loads(response.text)
    return response

    #return sc.SMARTConnect().Get_Queries(querytype=querytype)    



    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.team,
               func.reporting.get_translations(database.team.c.uuid, language_uuid).label("name"),
               func.reporting.get_translations(database.team.c.desc_uuid, language_uuid).label("description"),
               ).where(database.team.c.ca_uuid == ca_uuid)
    if active_only:
        q = q.where(database.team.c.is_active == True)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading teams")


@router.get("/{query_uuid}")
async def execute_query(
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    #language_uuid:  Annotated[UUID, "Conservation Area ID"] = '2af26704-7dd9-4a77-bbd4-c1953800d4f8',
                    query_uuid:     Annotated[UUID, "ID of the query"] = "",
                    db:             Session = Depends(database.get_db)

                 ):
    """
    Executes a query
    """
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    settings: Settings = get_settings()

    session = requests.Session()
        
    session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
    url = settings.SMART_CONNECT_URL
    
    params = {}
    params['type'] = 'geojson'
    params['start_date'] = "2023-02-01 00:00:00"
    params['end_date'] = "2024-02-01 00:00:00"
    params['date_filter'] = 'waypointdate'
    params['format'] = 'geojson'
    
        
    response = session.get(url=f'{url}/api/query/{query_uuid}', verify=False, params=params)
    
    if response.ok:
        print(response.text)
        return json.loads(response.text)
        return response.text
    
    print(response.text)
    raise HTTPException(
                status_code=response.status_code,
                detail=response.text,                
            )
