from fastapi import APIRouter, Depends, Security
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database

router = APIRouter(
    prefix="/patrol_transport",
    tags=["patrol_transport"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class PatrolTransport(BaseModel):
    uuid:       UUID
    ca_uuid:    UUID
    keyid:      str
    name:       str|None
    


@router.get("/")
async def get_patrol_transport(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    language_uuid:  Annotated[UUID, "Language UUID"],
                    db:             Session = Depends(database.get_db)
                 ) -> list[PatrolTransport]:
    
    """
    Load the list of patrol mandates for the given CA and translate the names into the given language
    """
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.patrol_transport,
               func.reporting.get_translations(database.patrol_transport.c.uuid, language_uuid).label("name"),
               ).where(database.patrol_transport.c.ca_uuid == ca_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading patrol_mandates")


