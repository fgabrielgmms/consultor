from fastapi import Depends, FastAPI, HTTPException, APIRouter, Security
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import JSONResponse

from pydantic import BaseModel

# import SMARTConnectDatabase as smdb
# import SMARTConnect as sc

from pandas import DataFrame
from uuid import UUID
import requests
import json
from config import Settings, get_settings
from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid
import geopandas as gpd

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from geoalchemy2 import functions as geofunc
from enum import Enum, auto
from main import oauth2_scheme
from user import User, get_current_active_user
from config import Settings,get_settings

router = APIRouter(
    prefix="/attachment",
    tags=["attachment"],
    responses={404: {"description": "Not found"}},
)

@router.get("/{attachment_uuid}", response_model=list[schemas.ConservationArea], include_in_schema=get_settings().DEV_INCLUDE_IN_SCHEMA)
def get_attachment( 
            current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid: Annotated[UUID, "Conservation Area ID"], 
            db: Session = Depends(database.get_db)):
    """
    Returns the attachment as an upload. Can be an image, a pdf or anything that has been attached to the observation
    """
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    #cas = current_user.extract_resource_from_scopes("viewca")
    #if "admin:None" in current_user.scopes or ca_uuid in cas:
    #return db.query(database.wp_attachments).where(database.wp_attachments.c.uuid == attachment_uuid).all()
    return db.query(database.observation_attachment).where(database.observation_attachment.c.uuid == attachment_uuid).all()
