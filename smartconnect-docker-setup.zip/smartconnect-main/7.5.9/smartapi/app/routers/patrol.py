from fastapi import Depends, FastAPI, HTTPException, APIRouter, Security, Query
from fastapi.responses import JSONResponse
#from api import app, oauth2_scheme
from typing import Annotated, List, Union

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

#from pydantic import BaseModel
from pydantic import TypeAdapter

# import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
import requests
import json
import datetime
import pandas as pd
import geopandas as gpd
from internal.helper import format_observations, format_patrol
#from .employee import Employee
#from ..internal.classes import Patrol

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from geoalchemy2 import functions as geofunc
from datetime import timedelta
import sql.crud
from internal import track
from user import User, get_current_active_user
import numpy as np

router = APIRouter(
    prefix="/patrol",
    tags=["patrol"],
    responses={404: {"description": "Not found"}},
)

@router.get("/{patrol_uuid}", response_model=schemas.Patrol)
async def get_patrol_details(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"],
            language_uuid:  Annotated[UUID, "Language UUID"], 
            patrol_uuid:    Annotated[UUID, "patrol_uuid"],
            
            db: Session = Depends(database.get_db) 
    ):
    """Returns all patrol details as GeoJSON
    
        :param patrol_uuid(UUID): The UUID of the patrol to be queried
        :return schemas.Patrol
    """
    
    current_user.check_permission("viewca", ca_uuid)
    
    cas = current_user.extract_resource_from_scopes("viewca")
    if "admin:None" in current_user.scopes or ca_uuid in cas:
        ca = db.query(database.conservation_area).where(database.conservation_area.c.uuid == ca_uuid).first()
    
    
    stmt = select(database.patrol).where(database.patrol.c.uuid == patrol_uuid).where(database.patrol.c.ca_uuid.in_(cas))
    
    try:
        r = db.scalars(stmt)
    except Exception as e:
        print(e)
        return
     
    data = r.first()
    if data is None:
        raise HTTPException(status_code=404, detail="Patrol not found")
    return data


#@router.get("/x/{patrol_uuid}", response_model=schemas.Patrol)
def get_patrol(patrol_uuid: UUID, 
                db: Session = Depends(database.get_db)):
    
    # ORM 
    #models.PatrolBase.leg_count = column_property(select(func.count(models.PatrolLeg.uuid)).where(models.PatrolLeg.patrol_uuid == models.PatrolBase.uuid).scalar_subquery())
    
    patrol = db.query(models.Patrol).filter(models.PatrolBase.uuid == patrol_uuid).first()
    if patrol is None:
        raise HTTPException(status_code=404, detail="Patrol not found")
    return patrol


    # None ORM
    patrol_table = Table ("patrol", smart_metadata, 
                                  #Column("t_keyid", String(30)),
                                  #column_property(select(func.get_translations("uuid", language_uuid)).scalar_subquery()),  
                                Column('uuid', Uuid, primary_key=True, unique=True, index=True),
                                Column('ca_uuid', Uuid),
                                Column('id', String, unique=True, index=True),
                                Column('start_date', Date),
                                Column('end_date', Date),
                                Column('comment', String),
                                Column('is_armed', Boolean),
                                #patrol_legs = relationship("PatrolLeg", back_populates="patrol") 
                                #column_property(select(func.get_translations("uuid", language_uuid)).scalar_subquery()),  
                                #column_property(Column('leg_count', Integer),
                                #        select(func.count(models.PatrolLeg.uuid)).where(models.PatrolLeg.patrol_uuid == uuid).correlate_except(models.PatrolLeg).scalar_subquery()
                                #),
                                schema="smart",
                                extend_existing=True
                        )
    stmt = select(patrol_table).where(patrol_table.c.uuid == patrol_uuid)

    return db.execute(stmt).first()

# Patrol Station
# @router.get("/stations/", response_model=list[schemas.Station])
# async def get_patrol_stations(
#                 current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
#                 ca_uuid:        Annotated[UUID, "Conservation Area ID"],
#                 language_uuid:  Annotated[UUID, "Language UUID"], 
#                 db: Session =   Depends(database.get_db)):
    
#     current_user.check_permission("viewca", ca_uuid)
    
#     # Load the patrol teams
#     query = db.query(models.Station.uuid, models.Station.ca_uuid, models.Station.is_active, 
#                                 models.Station.desc_uuid, 
#                                 func.reporting.get_translations(models.Station.desc_uuid, language_uuid).label("description"),
#                                 func.reporting.get_translations(models.Station.uuid, language_uuid).label("name")).where(models.Station.ca_uuid == ca_uuid)
#     return query.all()


# Patrol Teams
# @router.get("/teams/", response_model=list[schemas.Team])
# async def get_patrol_teams(
#                 current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
#                 ca_uuid:        Annotated[UUID, "Conservation Area ID"],
#                 language_uuid:  Annotated[UUID, "Language UUID"], 
#                 db: Session = Depends(database.get_db)):
    
#     current_user.check_permission("viewca", ca_uuid)
#     # Load the patrol teams
#     query = db.query(models.Team.uuid, models.Team.keyid, models.Team.ca_uuid, models.Team.is_active, 
#                                 models.Team.desc_uuid, #models.Team.patrol_mandate_uuid,
#                                 func.reporting.get_translations(models.Team.desc_uuid, language_uuid).label("description"),
#                                 func.reporting.get_translations(models.Team.uuid, language_uuid).label("name")).where(models.Team.ca_uuid == ca_uuid)
#     return query.all()
    
# # Patrol Mandates
# @router.get("/mandates/", response_model=list[schemas.PatrolMandate])
# async def get_patrol_mandates(
#                 current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
#                 ca_uuid:        Annotated[UUID, "Conservation Area ID"],
#                 language_uuid:  Annotated[UUID, "Language UUID"], 
#                 is_active:      Annotated[bool|None, "is_active"] = True,
#                 db: Session = Depends(database.get_db)):
    
#     current_user.check_permission("viewca", ca_uuid)
#     # Set te User language
#     db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
#     # Load the patrol mandates
#     query = db.query(models.PatrolMandate.uuid, models.PatrolMandate.keyid, models.PatrolMandate.ca_uuid, models.PatrolMandate.is_active, 
#                      func.reporting.get_translations(models.PatrolMandate.uuid, language_uuid).label("translated_keyid")).where(models.PatrolMandate.ca_uuid == ca_uuid)
#     if is_active:
#         query = query.where(models.PatrolMandate.is_active == is_active)
#     return query.all()
    

# @router.get("/transporttypes/", response_model=list[schemas.PatrolTransporttypes])
# def get_patrol_transporttypes(
#                 current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                
#                 ca_uuid:        Annotated[UUID, "Conservation Area ID"],
#                 language_uuid:  Annotated[UUID, "Language UUID"], 
                
#                 db: Session = Depends(database.get_db)) :
    
#     current_user.check_permission("viewca", ca_uuid)
    
#     # Set te User language
#     db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

#     # Load the patrol transport types
#     r = db.query(models.PatrolTransporttypes).filter(models.PatrolTransporttypes.ca_uuid == ca_uuid)
#     if r is None:
#         raise HTTPException(status_code=404, detail="No Transport Type found")
#     df = DataFrame.from_dict(r)
    
#     return r

# #@router.get("/")
# async def xget_patrols(# token: Annotated[str, Depends(oauth2_scheme)],
#             ca_uuid: Annotated[UUID, "CA"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),

#             team_uuid: Annotated[UUID|None, "Team"] = None,
#             station_uuid: Annotated[UUID|None, "Station"] = None,
#             mandate_uuid: Annotated[UUID|None, "Mandate"] = UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol

#             transporttype_uuid: Annotated[UUID|None, "Transport Type"] = UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
#             employee_uuid: Annotated[UUID|None, "Employee Type"] = None, 

#             start_date: Annotated[datetime.date|None, "Start"] = datetime.date(2023,1,1),
#             end_date: Annotated[datetime.date|None, "End"]  = datetime.date(2023,1,2),

#             tracks:  Annotated[bool, "Include Track Data"] = True,
#             observations:  Annotated[bool, "Include Observation Data"] = True,

#             db: Session = Depends(database.get_db)

#         ):
    
#         """
#         Returns all the data of a patrol.
#         """

        
#         df = gpd.GeoDataFrame()
#         db = smdb.SMARTConnectDatabase()

#         patrol = db.get_patrol_details(patrol_uuid=patrol_uuid)
#         #return patrol.to_dict()
#         #return patrol._to_geo()
        
#         #if tracks:
#         #patrol_track: gpd.GeoDataFrame = db.GetPatrolTracksv3(patrolid=patrol_uuid)
        
#         #if observations:
#         patrol_observations: gpd.GeoDataFrame = smdb.SMARTConnectDatabase().GetPatrolObservations(patroluuid=patrol_uuid)

#         #    retval = format_observations(df)
#         # #df =  gpd.GeoDataFrame (pd.concat([patrol_observations, patrol_track, patrol], ignore_index=False))
#         # df =  gpd.GeoDataFrame (pd.concat([patrol, patrol_observations], ignore_index=False))
#         print(df.head())

#         retval = format_patrol(df)

#         return retval

#         #return df.to_dict() 
#         return df._to_geo()


@router.get("/", response_class=JSONResponse) # [List[schemas.Patrol], JSONResponse])
async def find_patrols(
            current_user:           Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],                
            ca_uuid:                Annotated[UUID, "Conservation Area ID"],
            language_uuid:          Annotated[UUID, "Language UUID"], 
                

            team_uuid:              Annotated[UUID|None, "Team"] = None,
            station_uuid:           Annotated[UUID|None, "Station"] = None,
            mandate_uuid:           Annotated[UUID|None, "Mandate"] = None, 
            employee_team_uuid:     Annotated[UUID|None, "Employee Team"] = None,
                
            transport_uuid: Annotated[UUID|None, "Transport Type"] = None, 
            employee_uuid: Annotated[ List[UUID], Query(description="List Employee UUIDs")] = [], 

            patrolleader_uuid: Annotated[UUID|None, "Patrol Leader"] = None, 
            patrol_uuid: Annotated[UUID|None, "Patrol UUID"] = None, 
            patrol_id:  Annotated[str|None, "Patrol ID"] = None,
            timestamp: Annotated[datetime.datetime|None, "Timestamp"] = None, 
            
            start_date: Annotated[datetime.date|None, "Start"] = None,
            end_date: Annotated[datetime.date|None, "End"]  = None,

            # Geographical data
            polygon: Annotated[str|None, "Polygon"] = None,
            area_geometry_uuid: Annotated[UUID|None, "Area Geometry"] = None,

            #tracks:  Annotated[bool|None, "Include Track Data"] = False,
            #observations:  Annotated[bool|None, "Include Observation Data"] = False,
            speed_and_bearing:  
                Annotated[
                        bool|None, 
                        Query(description="Calculate Speed and Bearing for track", include_in_schema=False) 
                        ] = False,
                
            randomize:  Annotated[bool|None, Query(description="Randomize Test Data", include_in_schema=False)] = False,

            limit:      Annotated[int|None, "Max Patrols returned"] = None,    # -1 = no limit

            db: Session = Depends(database.get_db)):
    """
    Searches the database for matching patrols. 
    Returns list of patrol-ids and patrol-uuids
    """
    
    current_user.check_permission("viewca", ca_uuid)
    # Set te User language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})


    rows = sql.crud.find_patrols2(ca_uuid = ca_uuid, team_uuid = team_uuid, 
            station_uuid = station_uuid, mandate_uuid = mandate_uuid, 
            employee_team_uuid = employee_team_uuid, transport_uuid = transport_uuid,
            employee_uuid = employee_uuid, patrolleader_uuid = patrolleader_uuid,
            timestamp = timestamp, start_date = start_date, end_date = end_date,
            polygon = polygon, area_geometry_uuid = area_geometry_uuid,
            patrol_id = patrol_id, patrol_uuid=patrol_uuid, 
            limit = limit, db = db)
    
    #print(len(rows))
    
    df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
    
    # Convert Track to geomety
    df['geometry'] = df.apply(lambda row: shapely.from_wkt(row.track), axis=1)
    df.set_geometry('geometry', inplace=True, crs=4326)  

    if randomize:
        rng = np.random.default_rng()

        sign_x = -1 if rng.random() > 0.5 else 1        
        sign_y = -1 if rng.random() > 0.5 else 1        
        sign_angle = -1 if rng.random() > 0.5 else 1
        print(rng.random())
        #x_rnd = np.random.random(2000)
        #y_rnd = np.random.random(2000)
        #df['geometry'] = df['geometry'].simplify(tolerance=2, preserve_topology=True)
        df['geometry'] = df['geometry'].translate(xoff=sign_x * 20.0 * rng.random(), yoff=sign_y * 10.0 * rng.random()) #, zoff=10.0 * rng.random())
        df['geometry'] = df['geometry'].rotate(angle=sign_angle*180*rng.random(), origin='centroid', use_radians=False)
        #df['geometry'] = df['geometry'].scale(xfact=rng.random(), yfact=rng.random(), zfact=rng.random(), origin='center')
        #df['geometry'] = df['geometry'].skew(xs=10 * rng.random(), ys=-10 * rng.random(), origin='center', use_radians=False)
        # df.loc[df["gender"] == "male", "gender"] = 1
        # Rename Patrol ID
        df['id'] = df.apply(lambda x: f'Patrol_{x.name}', axis=1)
  

    
    if speed_and_bearing:
        df2 = df.explode()
        print(df2.head())
        df['speed_and_bearing'] = df2.apply(lambda row: track.Track(row.geometry).calculate_speed_and_bearing(), axis=1)
    
    return df._to_geo()
    

@router.get("/getlist/", response_class=JSONResponse, include_in_schema=False) # [List[schemas.Patrol], JSONResponse])
async def get_patrols(# token: Annotated[str, Depends(oauth2_scheme)], 
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"],
            language_uuid:  Annotated[UUID, "Language UUID"], 
                

            team_uuid: Annotated[UUID|None, "Team"] = None,
            station_uuid: Annotated[UUID|None, "Station"] = None,
            mandate_uuid: Annotated[UUID|None, "Mandate"] = UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol

            transporttype_uuid: Annotated[UUID|None, "Transport Type"] = UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
            employee_uuid: Annotated[UUID|None, "Employee"] = None, 
            patrolleader_uuid: Annotated[UUID|None, "Patrol Leader"] = None, 

            start_date: Annotated[datetime.date|None, "Start"] = datetime.date(2023,1,1),
            end_date: Annotated[datetime.date|None, "End"]  = datetime.date(2023,1,2),

            tracks:  Annotated[bool|None, "Include Track Data"] = True,
            observations:  Annotated[bool|None, "Include Observation Data"] = True,

            limit:      Annotated[int|None, "Max Patrols returned"] = None,    # -1 = no limit

            db: Session = Depends(database.get_db)):
    
    current_user.check_permission("viewca", ca_uuid)

    stmt = select(models.Patrol,models.wp_observation).where(models.Patrol.ca_uuid == ca_uuid)
        
    if start_date is not None and end_date is not None:
        stmt = stmt.where(models.Patrol.start_date >= start_date).where(models.Patrol.start_date <= end_date)

    if limit is not None and limit > -1:
        stmt = stmt.limit(limit=limit)
    try:
        r = db.scalars(stmt)
    except Exception as e:
        print(e)
        return
    #r = db.execute(stmt)
    #if r is None:
    #    raise HTTPException(status_code=404, detail="No Transport Type found")

    # 
    data = r.fetchall()
    patrols = []
    
    for row in data:
        patrol = dict()
        patrol["id"] = row.id
        patrol["uuid"] = row.uuid
        patrol["ca_uuid"] = row.ca_uuid
        patrol["start_date"] = row.start_date
        patrol["end_date"] = row.end_date
        track = shapely.MultiLineString()
        for pl in row.patrol_legs:
            for pld in pl.patrol_leg_days:
                for tr in pld.track:
                    track = track.union(shapely.from_wkb(tr.geo))
                    #tr.geo

        patrol["geometry"] = track

        # Observations
        patrol_legs = []
        for pl in row.patrol_legs:
            patrol_leg = dict()
            patrol_leg["uuid"] = pl.uuid
            patrol_leg["start_date"] = pl.start_date
            patrol_leg["end_date"] = pl.end_date
            patrol_leg["employee_count"] = pl.employee_count
            patrol_leg["leg_day_count"] = pl.leg_day_count
            patrol_leg["distance"] = pl.distance

            patrol_legs.append(patrol_leg)

            patrol_leg_days = []
            

            for pld in pl.patrol_leg_days:
                patrol_leg_day = dict()
                patrol_leg_day["uuid"] = pld.uuid
                patrol_leg_day["patrol_day"] = pld.patrol_day
                patrol_leg_day["start_time"] = pld.start_time
                patrol_leg_day["end_time"] = pld.end_time
                patrol_leg_day["rest_minutes"] = pld.rest_minutes
                patrol_leg_day["track_count"] = pld.track_count    
                patrol_leg_day["distance"] = pld.distance
                
                waypoints = []
                for pw in pld.patrol_waypoints:
                    waypoint = dict()
                    print(pw.waypoint.wp_observation_group)
                    waypoint["id"] = pw.waypoint.id
                    waypoint["datetime"] = pw.waypoint.datetime
                    waypoint["source"] = pw.waypoint.source
                    waypoint["x"] = pw.waypoint.x
                    waypoint["y"] = pw.waypoint.y
                    #waypoint["geometry"] = shapely.Point(pw.waypoint.x, pw.waypoint.y)

                    observations = []
                    for obs_group in pw.waypoint.wp_observation_group:
                        for obs in obs_group.wp_observations:
                            observation = dict()
                            observation["uuid"] = obs.uuid
                            observation["category"] = obs.category
                            observation["category_uuid"] = obs.category_uuid
                            for a in obs.attributes:
                                print(a.attribute)
                                value = a.string_value if a.string_value else (a.number_value if a.number_value else (a.list_element if a.list_element else (a.tree_node)))
                                observation[a.attribute] = value

                                

                            observations.append(observation)
                    waypoint["observations"] = observations

                    waypoints.append(waypoint)
                patrol_leg_day["waypoints"] = waypoints
                patrol_leg_days.append(patrol_leg_day)

            patrol_leg["patrol_leg_days"] = patrol_leg_days

        patrol["patrol_legs"] = patrol_legs
        patrols.append(patrol)

    
    g = gpd.GeoDataFrame.from_dict(patrols, geometry="geometry")
    return g._to_geo()
    
    
    return r
    

    db = smdb.SMARTConnectDatabase()
    df: DataFrame = db.GetPatrolIDs(start_date=start_date, end_date=end_date, ca=ca, team=team, mandate=mandate, employee=employee, transporttype=transporttype)
    
    return df.to_dict()

#@router.get("/track/{patrol_uuid}")
#async def get_patrol_track(# token: Annotated[str, Depends(oauth2_scheme)], 
##                patrol_uuid: Annotated[str, "patrol_uuid"] = "9ac74ab2-c5d7-4250-899a-a7bb2ae26c70",
#                ca: Annotated[str, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53"):
#    db = smdb.SMARTConnectDatabase()
#    patrol_track: gpd.GeoDataFrame = db.GetPatrolTracksv3(patrolid=patrol_uuid, ca_uuid=ca)
#    print (patrol_track.head())
#    print (patrol_track.columns)
#    #patrol_track = patrol_track.drop("geometry", axis=1)
#    return patrol_track.to_json()

@router.get("/checktrack/{patrol_uuid}", include_in_schema=False)
async def check_patrol_track(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            language_uuid:  Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
            ca_uuid: Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),           
            patrol_uuid: Annotated[UUID, "patrol_uuid"] = UUID("9ac74ab2-c5d7-4250-899a-a7bb2ae26c70"),
            db: Session = Depends(database.get_db)
            ):
    """
    Checks the tracks of the patrol for Spiderlegs or invalid Waypoints
    """
    
    current_user.check_permission("viewca", ca_uuid)
    
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    """
    select p.id, p.start_date, pl.id, pld.start_time, 
	f.distance * 1000 as distance,
	t.distance as total_distance,
	f.time_difference, f.speed, f.direction,
	cast(to_timestamp(f.start_timestamp/1000) as timestamp) as start_timestamp,
	cast(to_timestamp(f.end_timestamp/1000) as timestamp) as end_timestamp,
	st_x(f.a_point), st_y(f.a_point),
	st_x(f.b_point), st_y(f.b_point),
	--st_distance(cast(a_point as geometry), cast (b_point as geometry)) AS distance2,
		
	pl.*
from 
	smart.patrol as p
	join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
	join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
	join smart.track as t on t.patrol_leg_day_uuid = pld.uuid
	left join lateral reporting.get_track_speed_and_direction(t.uuid) f on true
	
where 
	--t.track_uuid = 'f3880857-2568-4f0a-aff5-bde289f09f17'
	p.id like 'LIONSNA_000521'
	--p.start_date >= '2022-01-01' and p.start_date < '2022-02-01'
	--and
	--f.speed > 0.00000001
	--f.distance = 0
	and 
	--pl.transport_uuid = 'c79d084b-3f5f-4d31-b3a6-332af3534fe9' -- Vehicle
	pl.transport_uuid = '76cb89cd-f53b-4884-a697-21fe1a66c7df' -- Foot
    """
    
    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                .join(func.reporting.get_track_speed_and_direction(database.track.c.uuid), func.true()).alias('f').lateral()
        )
    query = select(
                database.patrol.c.id.label('patrol_id'),
                func.cast(database.patrol.c.uuid, String).label('patrol_uuid'),
                database.patrol.c.start_date, 
                database.patrol_leg.c.pl.id, 
                database.patrol_leg.c.start_time, 
	            #f.distance * 1000 as distance,
                #t.distance as total_distance,
                #f.time_difference, f.speed, f.direction,
                #cast(to_timestamp(f.start_timestamp/1000) as timestamp) as start_timestamp,
                #cast(to_timestamp(f.end_timestamp/1000) as timestamp) as end_timestamp,
                #st_x(f.a_point), st_y(f.a_point),
                #st_x(f.b_point), st_y(f.b_point),

    )

    query = query.where(database.patrol.c.uuid == patrol_uuid)        
    print(query)
    try:    
        rows = db.execute(query).fetchall()
        #df = gpd.DataFrame([_r._asdict() for _r in rows])
        #return df
        return rows
        
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading patrol_mandates")
               
     
