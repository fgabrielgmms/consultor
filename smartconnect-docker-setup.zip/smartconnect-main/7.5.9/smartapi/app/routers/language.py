from fastapi import APIRouter, Depends, Security
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from sqlalchemy.sql import text


router = APIRouter(
    prefix="/language",
    tags=["language"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class Language(BaseModel):
    uuid: UUID
    ca_uuid: UUID
    isdefault: bool
    code: str
    



@router.get("/", response_model=list[Language])
async def get_languages(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    db: Session = Depends(database.get_db)
                    ) -> list[Language]:
    
    current_user.check_permission("viewca", ca_uuid)
    
    q = select(database.language).where(database.language.c.ca_uuid == ca_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of languages")


    
    db = smdb.SMARTConnectDatabase()
    df: DataFrame = db.get_languages(ca_uuid=ca_uuid)



    return list(map(lambda row: Language(uuid=row[0], 
                                     ca_uuid=row[1], 
                                     isdefault=row[2], 
                                     code = row[3]), df.values.tolist()))


class Translation(BaseModel):
    #uuid:           UUID
    translation:    str  

@router.get("/translate/{uuid}", response_model=list[Translation])
async def get_translations(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    uuid: Annotated[UUID, "UUID of the item to be translated"],
                    ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                    db: Session = Depends(database.get_db)
                    ) -> list[Translation]:
    
    """
    """
    current_user.check_permission("viewca", ca_uuid)
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(func.reporting.get_translations(uuid, language_uuid).label("translation"))
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading translation")


class i18n_label(BaseModel):
    language_uuid:  UUID
    element_uuid:   UUID
    value:          str

@router.get("/translationtable", response_model=list[i18n_label])
async def get_translation_table(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                    db: Session = Depends(database.get_db)
                    ) -> list[i18n_label]:
    
    """
    Returns the contents of the table i18n_label which provides the translations for 
    given text entries in attributes etc.
    TBD: No filtering of CA currently posssible.
    TBD: Function might be better in the datamodell script
    """
    current_user.check_permission("viewca", ca_uuid)
    #db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.i18n_label).where(database.i18n_label.c.language_uuid == language_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading translation")
