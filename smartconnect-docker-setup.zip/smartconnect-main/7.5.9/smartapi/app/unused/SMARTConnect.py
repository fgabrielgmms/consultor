import requests
import json
# from requests.auth import HTTPBasicAuth
import pandas as pd

import io
#from flask_sqlalchemy import SQLAlchemy     # pip3 install -U Flask-SQLAlchemy
#from sqlalchemy import select
#from sqlalchemy import text
import time
from datetime import date, datetime, timedelta
#import dash
#from flask import redirect, url_for, request 
#import sqlalchemy as sq
#import skimage.io as skio
import numpy as np
#import ibis
import psycopg2
from config import Settings, get_settings




import warnings
warnings.filterwarnings(action='ignore',category=Warning)

#dbSmart = SQLAlchemy()

def smart_is_authenticated(func):
    def wrapper (*args, **kwargs):
        app = dash.get_app().server
        if (app != None and 
            'SMART_CONNECT_AUTHENTICATED' in app.config and app.config['SMART_CONNECT_AUTHENTICATED'] == True and 
            'SMART_CONNECT_USERNAME' in app.config and app.config['SMART_CONNECT_USERNAME'] != '' and 
            'SMART_CONNECT_PASSWORD' in app.config and app.config['SMART_CONNECT_PASSWORD'] != ''):
            return func(*args, **kwargs)
        else:
            return app.redirect(url_for('login'))
                #404,"Access denied"
    return wrapper


class SMARTConnect:
    url: str
    username: str
    password: str
    dbuser: str | None
    dbpassword: str | None
    dbserver: str | None
    dbport: int | None
    dbdatabase: str | None
    session: requests.Session | None
    

    def __init__(self) -> None:
        print ('SMARTConnect __init__')
        settings: Settings = get_settings()

        self.url = settings.SMART_CONNECT_URL
        self.username = settings.SMART_CONNECT_USERNAME
        self.password = settings.SMART_CONNECT_PASSWORD
        self.dbuser = settings.SMART_DATABASE_USER            
        self.dbpassword  = settings.SMART_DATABASE_PASSWORD
        self.dbserver = settings.SMART_DATABASE_SERVER
        self.dbport = settings.SMART_DATABASE_PORT
        self.dbdatabase = settings.SMART_DATABASE_DATABASE

        self.session = None
        
    ###
    ### Execute SQL SELECT Statement and return results as pandas Dataframe
    def _Select(self, query, vars):        
        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                try:
                    cur.execute (query=query, vars=vars)
                    data = cur.fetchall()
                    cols = [desc[0] for desc in cur.description]
                    df = pd.DataFrame((data) , columns=[cols])
                except psycopg2.Error as e:
                    print(e.pgerror)
                    pass
        return df

        
    def Login(self):
        if self.session != None:
            self.Logoff()

        if self.app != None:
            self.username = self.app.server.config['SMART_CONNECT_USERNAME']
            self.password = self.app.server.config['SMART_CONNECT_PASSWORD']

        login_data =  { 'id': 'loginform',
                        'j_username': self.username, 
                        'j_password': self.password  }
        self.session = requests.Session()
        try:
            r = self.session.get(self.url + '/connect/home', verify=False) 
            rLogin = self.session.post(self.url + '/j_security_check', data=login_data, verify=False, cookies=r.cookies)
            if rLogin.ok and "Login failed" not in rLogin.text:
                self.app.server.config['SMART_CONNECT_AUTHENTICATED'] = True
                return True
            else:
                self.app.server.config['SMART_CONNECT_AUTHENTICATED'] = False
                self.session = None
                return False
        except:
            print("Connection to Connect Server refused")
            self.session = None
            #raise ConnectionError

        return False  
    
    def Logoff(self):
        if self.session == None:
            return
        self.app.server.config['SMART_CONNECT_AUTHENTICATED'] = False
        self.session.post(url=self.url+'/logout')
        self.session = None
        return
    
    def GetInfo(self):
        rQuery = self.__get(f'/api/info')
        
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return jsonData
        else:
            return rQuery.status_code, rQuery.text
        

    def GetConnectUser(self):
        rQuery = self.__get(f'api/connectuser')
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData))
            #return jsonData
        else:
            return rQuery.status_code, rQuery.text
        
    #/api/connectuser/getCurrent      
    def GetCurrentUser(self):
        rQuery = self.__get(f'api/connectuser/getCurrent')
        
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData))
            #return jsonData
        else:
            return rQuery.status_code, rQuery.text
        
    #/api/connectuser/iscurrentuseradmin  
    def IsCurrentUserAdmin(self):
        rQuery = self.__get(f'/api/connectuser/iscurrentuseradmin')
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return jsonData
        else:
            return rQuery.status_code, rQuery.text
        
    def GetDesktopUsers(self):
        rQuery = self.__get(f'api/desktopuser')
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData))
        else:
            return rQuery.status_code, rQuery.text
        
    def GetCurrentDesktopUser(self):
        rQuery = self.__get(f'api/desktopuser/getcurrent')
        
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData)), rQuery.status_code
        else:
            return rQuery.text, rQuery.status_code
    
    

    def Execute_Json_Query(self, queryid, datefilter='patrolstart', startdate=date.today()+timedelta(days=-365), enddate=date.today()):
        rQuery = self.__get(f'connect/query/api/{queryid}?format=geojson&date_filter={datefilter}&srid=4326&start_date={startdate} 00:00:00&end_date={enddate} 00:00:00')
        if rQuery.ok:
            jsonData = json.loads(rQuery.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData,"features"))
        else:
            return rQuery.status_code, rQuery.text
        # return pd.DataFrame(data=jsonData,columns=['features'])


    def Execute_CSV_Query(self, queryid, datefilter='patrolstart', startdate=date.today()+timedelta(days=-365), enddate=date.today(), sortcolumn="patrolstart"):
        if startdate is not None:
            rQuery = self.__get(f'connect/query/api/{queryid}?format=csv&date_filter={datefilter}&srid=4326&start_date={startdate} 00:00:00&end_date={enddate} 00:00:00')
        else:
            rQuery = self.__get(f'connect/query/api/' + queryid + '?format=csv')

        csvData = io.StringIO(rQuery.text)
        return pd.read_csv(filepath_or_buffer=csvData,header=0) #,columns=['Patrol ID'])


    def Waypoint_Patrol(self, patrolid):
        rQuery = self.__get(f'api/query/custom/patrol?patrol_uuid={patrolid}')
        jsonData = json.loads(rQuery.text)
        return jsonData
        #return pd.DataFrame(data=pd.json_normalize(jsonData,"features"))
        


    def Get_Patrol_Observations(self, patrol_start_date,patrol_end_date, patrolid=None, queryid='bc48a423-fbbe-4223-b4f6-52e87bcd4cec'):
        rQuery = self.__get(f'connect/query/api/{queryid}?format=csv&date_filter=patrolstart&srid=4326&start_date={patrol_start_date} 00:00:00&end_date={patrol_end_date} 00:00:00&')
        csvData = io.StringIO(rQuery.text)
        df = pd.read_csv(filepath_or_buffer=csvData,header=0) #,columns=['Patrol ID'])

        #jsonData = json.loads(rQuery.text)
        #df = pd.DataFrame(data=pd.json_normalize(jsonData,"features"))
        if (patrolid != None):
            df = df.where(df['Patrol ID'] == patrolid).dropna(how='all')
        return df
    
    def Get_Patrols(self, patrol_start_date,patrol_end_date, queryid='27ef5f23-118b-4bc6-9e8e-cac0ece27b2b'):
        rQuery = self.__get(f'connect/query/api/{queryid}?format=csv&date_filter=patrolstart&srid=4326&start_date={patrol_start_date} 00:00:00&end_date={patrol_end_date} 00:00:00&includeuuids=true')
        csvData = io.StringIO(rQuery.text)
        df = pd.read_csv(filepath_or_buffer=csvData,header=0) #,columns=['Patrol ID'])
        #df["Patrol Start Date"] = pd.to_datetime(df["Patrol Start Date"]) #, format="ISO8601")
        #df["Patrol End Date"] = pd.to_datetime(df["Patrol End Date"]) #, format="ISO8601")
        #df["Patrol Leg Start Date"] = pd.to_datetime(df["Patrol Leg Start Date"]) #, format="ISO8601")
        #df["Patrol Leg End Date"] = pd.to_datetime(df["Patrol Leg End Date"]) #, format="ISO8601")
        
        #jsonData = json.loads(rQuery.text)
        #df = pd.DataFrame(data=pd.json_normalize(jsonData,"features"))
        #df = df.where(df['Patrol ID'] == patrolid).dropna(how='all')
        return df
        


    def Get_Patrol_Tracks(self, queryid):
        if self.session == None:
            self.Login()
        
        PatrolTracks = self.Execute_Json_Query(queryid)
        #print(PatrolTracks["properties.Patrol_ID"].count())
        #print(PatrolTracks.iloc(0))

        Result = pd.DataFrame({"Patrol ID":[], "Patrol Leg ID":[], "x":[], "y":[]})
        #Result.add()
        #Result.columns.append(["Patrol ID", "Patrol Leg ID", "x", "y"])

        for i, j in PatrolTracks.head(100).iterrows():
            #Patrol
            print("Row: {}, Patrol-ID: {}, Leg-ID: {}".format(i, j["properties.Patrol_ID"], j["properties.Patrol_Leg_ID"], j["geometry.coordinates"]))
            track = j["geometry.coordinates"]
            if track:
                #try:
                    for t in track:
                        # Patrol-Leg
                        for t2 in t:
                            # Track Points
                            if len(t2) == 2:
                                Result.loc[len(Result)] = [j["properties.Patrol_ID"],j["properties.Patrol_Leg_ID"],t2[0],t2[1]] 
                            else:
                                Result.loc[len(Result)] = [j["properties.Patrol_ID"],j["properties.Patrol_Leg_ID"]]
                #except:
                #    print(track)
                    
        return Result

    def Get_Query_Types(self):
        rQuery = self.__get(f'api/querytype')
        jsonData = json.loads(rQuery.text)

        return pd.array(data=jsonData)
        
    
    def Get_Queries(self, querytype="patrolquery"):
        if querytype == '':
            rQuery = self.__get(f'api/query')
        else:
            rQuery = self.__get(f'api/query?type={querytype}')

        jsonData = json.loads(rQuery.text)
        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetPatrolTracksv2(self,patrolid):
        qryTracks = '''select
            p.id as Patrol_Id, pl.id as Patrol_Leg_Id, pld.patrol_day,
            vtp.distance,
            --vtp.geom,
            vtp.x,
            vtp.y,
            to_timestamp(z/1000) as datetime
            
        from
            smart.patrol as p 
            join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
            join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
            join reporting.v_track_points as vtp on vtp.patrol_leg_day_uuid = pld.uuid
            
        where 
            p.id = %(patrolid)s
        order by
            vtp.z asc
        '''

        #return self.ExecuteSQLSelect(qryTracks.format(patrolid))
    
        from server import SMARTConnectengine

        with SMARTConnectengine.connect() as connection:
            Ret = connection.execute(qryTracks,{"patrolid": patrolid},)
            df = pd.DataFrame(Ret.fetchall())
            return df
            return pd.read_sql(text(qryTracks), con = connection, params={"patrolid": patrolid})


    #def GetPatrolTracksv1(self,patrolid):
    #    qryTracks = '''select
    #        p.id as Patrol_Id, 
    #        pl.id as Patrol_Leg_Id, 
    #        pld.patrol_day,
    #        vtp.distance,
    #        --vtp.geom,
    #        vtp.x,
    #        vtp.y,
    #        to_timestamp(z/1000) as datetime
    #        
    #    from
    #        smart.patrol as p 
    #        join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
    #        join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
    #        join reporting.v_track_points as vtp on vtp.patrol_leg_day_uuid = pld.uuid
    #        
    #    where 
    #        p.id = '{}'
    #    order by
    #        vtp.z asc
    #    '''
    #    return self.ExecuteSQLSelect(qryTracks.format(patrolid))
    
    
    def GetPatrolIDs(self, start_date, end_date, ca, team, mandate, employee, transporttype, station):
        qry = f'''
            SET intervalstyle = 'postgres';

            select distinct
                min(patrol_id) as patrol_id,
                min(patrol_start_date) as patrol_start_date, 
				max(patrol_end_date) as patrol_end_date, 
                min(ca_name) as CA,
                min(station_uuid) as station_uuid,
                min(team) as team,
                min(objective) as objective,
                --min(patrol_type), 
                min(transporttype) as transporttype,
                min(manadatetype) manadatetype,
                --min(is_armed), 
				min(comment) as comment,
                min(patrol_leg_id) as patrol_leg_id,
                --mandate_uuid
                patrol_uuid,
                --count(patrol_leg_uuid) as count_patrol_legs,
                sum(distance) as distance,
                sum(patrol_led_day_duration) as duration,
				
				EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 * 60 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) * 60 + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 60 as duration_in_minutes,
				
                EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) /60 +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 3600 as duration_in_hours
				
                from reporting.v_patrols
                where patrol_start_date >= '{start_date}' and patrol_start_date <= '{end_date}'
        '''
        vars = [start_date, end_date]
        if ca:
            qry += f" and ca_uuid='{ca}'"
        if team:
            qry += f" and team_uuid='{team}'"
        if mandate:
            qry += f" and mandate_uuid='{mandate}'"
        if employee:
            qry += f" and patrol_leg_uuid IN (select cast(patrol_leg_uuid as text) from smart.patrol_leg_members where employee_uuid = '{employee}')"
        if transporttype:
            qry += f" and transporttype_uuid='{transporttype}'"
        if station:
            qry += f" and station_uuid='{station}'"


        qry += 'GROUP BY patrol_uuid, patrol_leg_uuid'

        print(qry)
        return self.ExecuteSQLSelect(qry)
        #return self._Select(qry, vars)
    

    def ExecuteSQLSelect(self, sql):
        from server import SMARTConnectengine
        #print(sql)

        with SMARTConnectengine.connect() as connection:
            #Ret = connection.execute(sql)
            #df = pd.DataFrame(Ret.fetchall())
            return pd.read_sql_query(text(sql), con = connection)

        

        server = self.app.server
        #engine = server.config.get('SMARTCONNECTENGINE')
        #engine = dbSmart.engine

        with self.engine.connect() as connection:
            #Ret = connection.execute(sql)
            #df = pd.DataFrame(Ret.fetchall())
            df = pd.read_sql(sql, con = connection)

        return df

        
    def Get_Reports (self):
        rQuery = self.__get(f'api/report')
        jsonData = json.loads(rQuery.text)

        return pd.DataFrame(data=pd.json_normalize(jsonData))
    

    #def Call_Report (self, reportid):
    #    rQuery = self.__get(f'api/report/{reportid}?format=html&parameterList=Start Date,2020-01-01 00:00:00,End Date,2023-12-31 00:00:00,Station,Iglulik,')
    #    return rQuery.text
    
    def GetBaseMaps (self):
        settings: Settings = get_settings()

        session = requests.Session()
            
        session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
        url = settings.SMART_CONNECT_URL
            
        response = session.get(url=f"{url}/api/basemap", 
                                        verify=False )
        if response.ok:
            print(response.text)
            return json.loads(response.text)
        else:
            return response.status_code
    
    def GetBaseMapTile (self, uuid, x=0, y=0, z=0):
        rQuery = self.__get(f'api/basemap/{uuid}/{z}/{x}/{y}')
        return rQuery
    
    def GetOSMMapTile(self, x, y, z):
        #https://tile.openstreetmap.org/${z}/${x}/${y}.png
        queryUrl = f'https://tile.openstreetmap.de/{z}/{x}/{y}.png'

        print(queryUrl)
        response = requests.request(url=queryUrl,method="GET",headers={"Referer":"https://lionrangernaconnect.smartconservationtools.org/server"})
        return response
    
        
    
    def GetMapLayers (self):
        rQuery = self.__get(f'api/maplayer')
        jsonData = json.loads(rQuery.text)
        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetMapLayer (self, layername):
        rQuery = self.__get(f'api/maplayer/{layername}')
        jsonData = json.loads(rQuery.text)

        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetConservationAreas(self):
        rQuery = self.__get(f'api/conservationarea?includeSpatialBoundaries=false')
        jsonData = json.loads(rQuery.text)
        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetConservationArea(self, ca_uuid):
        rQuery = self.__get(f'api/conservationarea/{ca_uuid}')
        jsonData = json.loads(rQuery.text)
        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetDataModel(self, cauuid):
        rQuery = self.__get(f'api/metadata/datamodel/{cauuid}')
        return rQuery.text

            
    def ListConfigurableModels(self):
        rQuery = self.__get(f'api/metadata/configurablemodel')
        jsonData = json.loads(rQuery.text)
        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    ####
    def GetTeams(self, ca_uuid = 'a2516167-3da8-440e-b56b-6f68c2f11d53', language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'):
        query = '''select cast(t.uuid as varchar),
                    cast(t.ca_uuid as varchar),
                    t.keyid as keyid,
                    cast(t.desc_uuid as varchar),
                    i.value
                from smart.team as t join smart.i18n_label i on t.desc_uuid = i.element_uuid
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select(query, (ca_uuid, language_uuid,))
        

    def GetMandates(self, ca_uuid  = 'a2516167-3da8-440e-b56b-6f68c2f11d53', language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'):
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    keyid,
					i.value                    
                from smart.patrol_mandate as t join smart.i18n_label i on t.uuid = i.element_uuid				
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select(query, (ca_uuid, language_uuid,))

    def GetTransportTypes(self, ca_uuid  = 'a2516167-3da8-440e-b56b-6f68c2f11d53', language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'):
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    keyid,
					i.value                    
                from smart.patrol_transport as t join smart.i18n_label i on t.uuid = i.element_uuid				
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select(query, (ca_uuid, language_uuid,))


    # returns XML
    def GetConfigurableModel(self, modeluuid):
        rQuery = self.__get(query=f'api/metadata/configurablemodel/{modeluuid}')
        return rQuery.text

    
    def __get(self, query):
        if self.session == None:
            self.Login()

        queryUrl = f'{self.url}/{query}'

        print(queryUrl)

        rQuery = self.session.get(queryUrl, verify=False)
        return rQuery
    

    def LoadDataQueue (self, status = 'QUEUED', cauuid=None):
        if cauuid:
            rQuery = self.__get(f'api/dataqueue/detailedItems?status={status}&cafilter={cauuid}')
        else:
            rQuery = self.__get(f'api/dataqueue/detailedItems?status={status}')
        jsonData = json.loads(rQuery.text)

        return pd.DataFrame(data=pd.json_normalize(jsonData))
    
    def GetDataQueueItem(self, uuid):
        rQuery = self.__get(f'api/dataqueue/items/{uuid}/file') 
        if rQuery.ok:
            return rQuery.text
        else:
            return None
    
    def UpdateDataQueueItem(self, uuid, jsonData):
        if self.session == None:
            self.Login()

        queryUrl = f'{self.url}/api/dataqueue/items/{uuid}/file'

        print(queryUrl)

        rQuery = self.session.get(queryUrl, verify=False)
        #jsonData = json.loads(rQuery.text)

        #return pd.DataFrame(data=pd.json_normalize(jsonData,"features")), 
        return rQuery.text
    
    
    def GetEmployees (self, ca_uuid):
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    id,
                    givenname,
                    familyname,
                    concat(concat(givenname, ' '),familyname) as name,
                    concat(concat(familyname, ' '),givenname) as name2,
                    startemploymentdate,
                    endemploymentdate,
                    cast(agency_uuid as varchar),
                    cast(rank_uuid as varchar),
                    smartuserlevel
                from smart.employee where ca_uuid=%s
            '''
        return self._Select(query, (ca_uuid, ))
        
        
    def GetPatrolEfforts (self, employee_uuid, transporttype='foot'): #startdate, enddate, 
        query = '''select 
                cast(employee_uuid as text) as employee_uuid, familyname, givenname,
                patrol_leg_start,
                date_part('year', patrol_leg_start) as year,
                date_part('month', patrol_leg_start) as month,
                date_part('day', patrol_leg_start) as day,
                patrol_id,
                distance,
                patrol_led_day_duration as duration
            from reporting.v_patrol_efforts 
                where transporttype = %s and employee_uuid = %s
            '''
        return self._Select(query, (employee_uuid, transporttype, ))
        
    def GetTreeAttribute(self, uuid, language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'):
        query = f'''
        select 
            cast (at.uuid as varchar) as uuid,
            cast (a.uuid as varchar) as attribute_uuid,
            cast (a.ca_uuid as varchar) as ca_uuid,
            a.keyid as attribute_keyid,
            att_type,
            at.keyid as attribute_tree_keyid,
            node_order,
            cast(parent_uuid as varchar) as parent_uuid,
            at.hkey,
            i.value
	    from 
            smart.dm_attribute as a 
            join smart.dm_attribute_tree as at on at.attribute_uuid = a.uuid
            left join smart.i18n_label as i on at.uuid = i.element_uuid
            left join smart.icon as icon on at.icon_uuid = icon.uuid
            left join smart.iconfile as iconfile on icon.uuid = iconfile.icon_uuid
            where 
                a. att_type = 'TREE' and
                a.uuid = '{uuid}'
                and 
                i.language_uuid = '{language_uuid}'
                -- Use only Leafes
                and at.uuid in (select uuid from smart.dm_attribute_tree
				where uuid not in (
					select uuid from smart.dm_attribute_tree
						where uuid in (select parent_uuid from smart.dm_attribute_tree)
						and attribute_uuid = '{uuid}')
				and attribute_uuid = '{uuid}'
				);
        '''
        df = self.ExecuteSQLSelect(query)

        return df
    

    def GetDataModelCategory(self):
        query = f'''
        select 
            cast(uuid as varchar) as uuid,
            cast(ca_uuid as varchar) as ca_uuid,
            keyid,
            cat_order,
            cast(parent_category_uuid as varchar) as parent_category_uuid,
            hkey,
            cast(language_uuid as varchar) as language_uuid,
            value

        from smart.dm_category as c
            left join smart.i18n_label as i on c.uuid = i.element_uuid
            where is_active = true	
        '''
        return self.ExecuteSQLSelect(query)
    

    # /api/metadata/configurablemodel
    def GetMetadataConfigurableModel(self, uuid =""):
        if (uuid != ""):
            rQuery = self.__get(f'api/metadata/configurablemodel/{uuid}')
        else:
            rQuery = self.__get(f'api/metadata/configurablemodel')

        if rQuery.ok:
            return json.loads(rQuery.text)
        else:
            return rQuery.text
        
    #/api/metadata/datamodel/{cauuid}
    def GetMetadataDatamodel(self,cauuid):
        rQuery = self.__get(f'api/metadata/datamodel/{cauuid}')
        if rQuery.ok:
            return rQuery.text        
        else:
            return rQuery.text
    
    #/api/metadata/datamodel/{cauuid}/info
    def GetMetadataDatamodelInfo(self,cauuid):
        rQuery = self.__get(f'api/metadata/datamodel/{cauuid}/info')
        if rQuery.ok:
            return json.loads(rQuery.text)
        else:
            return rQuery.text
    


    #/api/metadata/mission/{cauuid}
    def GetMetadataPatrol(self,cauuid):
        rQuery = self.__get(f'api/metadata/patrol/{cauuid}')
        if rQuery.ok:
            return json.loads(rQuery.text), rQuery.status_code
        else:
            return rQuery.text, rQuery.status_code
    
    #/api/metadata/patrol/{cauuid}
    def GetMetadataMission(self,cauuid):
        rQuery = self.__get(f'api/metadata/mission/{cauuid}')
        if rQuery.ok:
            return json.loads(rQuery.text), rQuery.status_code
        else:
            return rQuery.text, rQuery.status_code
        
    #/api/query/custom/patrol
    def GetCustomPatrol(self,patrol_uuid = None,client_patrol_uuid = None):
        assert (patrol_uuid != None or client_patrol_uuid != None), 'Either Patrol_UUID or Client_Patrol_ID has to be set'
        if (patrol_uuid):
            rQuery = self.__get(f'api/query/custom/patrol?patrol_uuid={patrol_uuid}')
        else:
            rQuery = self.__get(f'api/query/custom/patrol?client_patrol_uuid={client_patrol_uuid}')
        
        if rQuery.ok:
            return json.loads(rQuery.text), rQuery.status_code
        else:
            return rQuery.text, rQuery.status_code

    #/api/query/custom/waypoint:
  

    # /api/query/custom/waypoint/incident:
  
    # /api/query/custom/waypoint/patrol:
    def GetCustomWaypointPatrol(self, 
                                #patrol_uuid,client_patrol_uuid,patrolleg_uuid,client_patrolleg_uuid,
                                patrol_id = None
                                #,waypoint_date
                                #,waypoint_uuid
                                #,waypoint_lastmodified 
                                ,patrol_startdate = None
                                ,patrol_enddate = None
                                ):

        if (patrol_id):
            rQuery = self.__get(f'api/query/custom/waypoint/patrol?patrol_id={patrol_id}')
        elif (patrol_startdate):
            rQuery = self.__get(f'api/query/custom/waypoint/patrol?patrol_startdate={patrol_startdate}')
        else:
            rQuery = self.__get(f'api/query/custom/waypoint/patrol')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code

    #  /api/cybertracker/apikey
    def GetCybertrackerApiKeys(self):
        rQuery = self.__get(f'api/cybertracker/apikey')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code

    def GetCybertrackerApiKey(self, uuid):
        rQuery = self.__get(f'api/cybertracker/apikey/{uuid}')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code

    def GetCybertrackerPackages(self, uuid=None):
        if uuid:
            rQuery = self.__get(f'api/cybertracker/packages/{uuid}')
        else:
            rQuery = self.__get(f'api/cybertracker/packages')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code
        
    def GetCybertrackerPackageInfo(self, uuid):
        rQuery = self.__get(f'api/cybertracker/packages/info/{uuid}')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code

    #  /api/cybertracker/navigationlayers
    def GetCybertrackerNavigationlayers(self):
        rQuery = self.__get(f'api/cybertracker/navigationlayers')
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code
        
    def send_json_file(self, cauuid, name, data):
        """
        Uploads a JSON File to the servers dataqueue
        """
        if self.session == None:
            self.Login()

        url = f'{self.url}/api/dataqueue/items'

        session = requests.Session()        
        session.auth = (self.app.server.config['SMART_CONNECT_USERNAME'], self.app.server.config['SMART_CONNECT_PASSWORD'])
        body = {}
        body['conservationArea'] = cauuid
        body['type'] = 'JSON_CT'
        body['name'] = name
        headers = {}
        headers['X-Upload-Content-Length'] = str(len(data))

        response = session.post(url = url, json=body, headers=headers)
        if response.ok:
            location = response.headers['location']
            print(location)
            headers = {}
            
            files = {'upload_file': json.dumps(json.loads(data))}
            response2 = session.post(url=location, files=files)
            print(response2.text)
            if response2.ok:
                return True
            else:
                return False
        else:
            print ("Upload failed")
            return False
    
    
    # /api/data/{cauuid}:
    def SendData(self, cauuid, data):
        if self.session == None:
            self.Login()
        queryUrl = f'{self.url}/api/data/{cauuid}'
        print(queryUrl)
        headers = {'Content-type': 'application/json'}
        rQuery = self.session.post(url=queryUrl, data=data, verify=False, headers=headers)
        if rQuery.ok:
            #return json.loads(rQuery.text), rQuery.status_code
            return rQuery.text, rQuery.status_code
            df = pd.DataFrame(data=pd.json_normalize(json.loads(rQuery.text)))
            return df
        else:
            return rQuery.text, rQuery.status_code
        
    def get_alerts(self, cauuid, start_date, end_date):
        if self.session == None:
            self.Login()

        url = f'api/connectalert?'

        session = requests.Session()
        
        session.auth = (self.app.server.config['SMART_CONNECT_USERNAME'], self.app.server.config['SMART_CONNECT_PASSWORD'])

        params = dict()
        if cauuid: 
            params['caUuidFilter'] = cauuid
        if start_date:
            #params['startDateFilter'] = 1693255168910   # 28.8.2023                                        
            params['startDateFilter'] = "{:0.0f}".format(time.mktime(datetime.strptime(start_date, "%Y-%m-%d").timetuple())*1000)
        if end_date:
            #params['endDateFilter'] = 1696019968910 # 28.9.2023
            params['endDateFilter'] = "{:0.0f}".format(time.mktime(datetime.strptime(end_date, "%Y-%m-%d").timetuple())*1000)

        params['typeUuidFilter'] = "50e7d853-2006-4175-bb99-77cf4e14ae88,91c6cbfd-459f-44b3-873a-424d1eca0eec,24ffd0e0-2bc5-4171-a6ac-28960617b5b7,e27ef15d-065e-4c2c-ac2a-299cf406bc48,"
        #params['statusFilter'] = "ACTIVE,DISABLED,"
        params['statusFilter'] = "ACTIVE,"
        params['levelFilter'] = "1,2,3,4,5,"
        params['textSearchFilter'] = ''
        params['sortBy'] = 'date'
        params['sortAscending'] = 'false'
        params['maxAlertOverride'] = '1000'

        response = session.get(url=f'{self.url}/{url}', params=params, verify=False )
        if response.ok:
            print(response.text)
            jsonData = json.loads(response.text)
            return pd.DataFrame(data=pd.json_normalize(jsonData, "features"))
        
    
        
        
class OpenWeather:

    def WeatherDataToDataFrame(queryUrl):
        print (queryUrl)
        rQuery = requests.get(queryUrl)
        weatherdata = json.loads(rQuery.content.decode('utf-8'))
        #print(rQuery.text)
        #jsonData = json.loads(rQuery.text)
        #weatherdata = pd.DataFrame(data=pd.json_normalize(jsonData,"hourly"))


        #print(weatherdata)
        #print(weatherdata['hourly']['temperature_2m'])
        hourly = {}
        cleaned_data = {}
        for i in weatherdata['hourly']:
            #print(i)
            data = {}
            #print(weatherdata['hourly'][i])
            for j in range(len(weatherdata['hourly'][i])-1):
                #print(j)
                data[weatherdata["hourly"]["time"][j]] = weatherdata['hourly'][i][j]
            hourly[i] = data
            #print(data)
        cleaned_data["hourly"] = hourly
        weatherdata = pd.DataFrame(hourly)
        weatherdata['time'] = weatherdata['time'].apply(pd.to_datetime)
        return weatherdata
