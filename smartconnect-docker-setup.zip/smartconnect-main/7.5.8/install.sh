#!/bin/bash

export SMART_CONNECT_PUBLIC_SERVERNAME=$1
export SMART_CONNECT_PUBLIC_PORT=$2
export SMART_CONNECT_PUBLIC_VOLUME=$3
export SMART_CONNECT_POSTGRES_PORT=5432

CERTKEY=./apache2/server.key
CERT=./apache2/server.crt
PROJECTNAME=$1

# Let's Encrypt certbot https://blockdev.io/quick-and-easy-lets-encrypt-certificates-using-docker/
# http://olislaptop.8pv9o180upa5vb3v.myfritz.net:8080
# 8pv9o180upa5vb3v.myfritz.net
#docker run -it --rm -p 443:443 -p 80:80 --name letsencrypt -v "/etc/letsencrypt:/etc/letsencrypt" -v "/var/lib/letsencrypt:/var/lib/letsencrypt" quay.io/letsencrypt/letsencrypt:latest auth
#cp /etc/letsencrypt/live/<url>/privkey.pem ./apache2/server.key
#cp /etc/letsencrypt/live/<url>/fullchain.pem ./apache2/server.crt
if test -f "$CERTKEY"; then
    echo "$CERTKEY exists."
else
	echo "Generate Self-Signed Certificate for $SMART_CONNECT_PUBLIC_SERVERNAME"
	openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -subj "/CN=$SMART_CONNECT_PUBLIC_SERVERNAME" -keyout "$CERTKEY" -out "$CERT" -extensions san -config ./apache2/ssl-config.cfg
fi



echo "Prepare the directory structure in $SMART_CONNECT_PUBLIC_VOLUME"
if [ ! -d "$SMART_CONNECT_PUBLIC_VOLUME" ] 
then
	mkdir  $SMART_CONNECT_PUBLIC_VOLUME
fi

if [ ! -d "$SMART_CONNECT_PUBLIC_VOLUME/smart-db-data" ] 
then
	mkdir  $SMART_CONNECT_PUBLIC_VOLUME/smart-db-data
fi

if [ ! -d "$SMART_CONNECT_PUBLIC_VOLUME/smartfilestore" ] 
then
	mkdir  $SMART_CONNECT_PUBLIC_VOLUME/smartfilestore
fi
if [ ! -d "$SMART_CONNECT_PUBLIC_VOLUME/tomcatlogs" ] 
then
	mkdir  $SMART_CONNECT_PUBLIC_VOLUME/tomcatlogs
fi

echo "Start Building docker container"
docker compose -f docker-compose.yml -p $PROJECTNAME build
echo "Start the Container"
docker compose -f docker-compose.yml -p $PROJECTNAME up -d

echo "Finished. The Server should be available in a few minutes: https://$SMART_CONNECT_PUBLIC_SERVERNAME/server/connect"

read -p "Press ENTER to cleanup"

echo "Cleanup"
docker compose -p $PROJECTNAME down
docker compose -p $PROJECTNAME rm
rm -rf $SMART_CONNECT_PUBLIC_VOLUME