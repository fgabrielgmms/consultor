#!/bin/bash
# This script is used by docker compose health checker  to verify that the connect database is available
su postgres -c '/usr/local/bin/psql -d connect -c "select * from connect.connect_version;"' | grep "6\.3\.0"
#su postgres -c '/usr/local/bin/psql -d connect -c "select * from connect.connect_version;"' | grep "7\.5\.7"
