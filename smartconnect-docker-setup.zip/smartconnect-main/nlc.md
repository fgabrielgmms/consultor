# SMART Connect Installation NLC



```		
apt install unzip
mkdir /smart
cd /smart/
unzip smartconnect-main.zip
```	
```
cd /smart/smartconnect-main/7.5.7/
```

nano .env

SMART_CONNECT_PUBLIC_SERVERNAME="ec2-3-27-140-11.ap-southeast-2.compute.amazonaws.com"

## Create cerificate
```
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -subj "/CN=ec2-3-27-140-11.ap-southeast-2.compute.amazonaws.com" -keyout ./apache2/server.key -out ./apache2/server.crt # -extensions san -config ./ssl-config.cfg
```

## Build

```
docker compose build
```

## Run
```
docker compose up -d
```


## Create the database
```
docker exec 757-smartdb-1 psql -U postgres connect -f docker-entrypoint-initdb.d/20-connect.sql
```