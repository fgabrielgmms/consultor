INSERT INTO ohrm_rot_post (name, type, min_staff, requires_pras) VALUES
('PC San José', 'terrestrial', 4, 1),
('PC Ceilán', 'terrestrial', 4, 1),
('PC Tiputini', 'aquatic', 4, 1),
('PC Añangu', 'terrestrial', 4, 1),
('PC Yasuní', 'terrestrial', 4, 1),
('PC Chiro Isla', 'aquatic', 4, 1),
('PC Tambococha', 'block31', 4, 1),
('PC Ishpingo', 'block43', 4, 1),
('PC Pompeya', 'terrestrial', 4, 1),
('PC Boca Tiputini', 'aquatic', 4, 1),
('PC Zancudo', 'aquatic', 4, 1),
('PC Limón Cocha', 'aquatic', 4, 1),
('PC Pañacocha', 'aquatic', 4, 1);
