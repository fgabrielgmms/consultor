
INSERT INTO ohrm_user_role (name, display_name, is_assignable)
SELECT 'ROLE_ROTATION_MANAGER','Rotation Manager',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ohrm_user_role WHERE name='ROLE_ROTATION_MANAGER');
CREATE TABLE IF NOT EXISTS ohrm_rot_permission (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) UNIQUE,
  description VARCHAR(255)
);
INSERT IGNORE INTO ohrm_rot_permission (code, description) VALUES
('rot_rotation_view','View rotations'),
('rot_rotation_generate','Generate rotations'),
('rot_rotation_publish','Publish rotations');
