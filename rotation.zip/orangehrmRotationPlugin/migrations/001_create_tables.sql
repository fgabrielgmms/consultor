
CREATE TABLE IF NOT EXISTS ohrm_rot_post (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type VARCHAR(50) NOT NULL,
  min_staff TINYINT NOT NULL DEFAULT 4,
  requires_pras TINYINT(1) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_rot_post_name (name)
);
CREATE TABLE IF NOT EXISTS ohrm_rot_rotation (
  id INT AUTO_INCREMENT PRIMARY KEY,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ohrm_rot_assignment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  rotation_id INT NOT NULL,
  employee_id INT NOT NULL,
  post_id INT NOT NULL,
  from_date DATE NOT NULL,
  to_date DATE NOT NULL,
  shift_type VARCHAR(10) NOT NULL,
  is_coordinator TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT fk_rot_assignment_rotation FOREIGN KEY (rotation_id) REFERENCES ohrm_rot_rotation(id) ON DELETE CASCADE,
  INDEX ix_rot_assignment_emp (employee_id),
  INDEX ix_rot_assignment_post (post_id)
);
