<?php

class RotationDao {

    public function getRotationById($id) {
        // TODO: Query DB
        return null;
    }
}
