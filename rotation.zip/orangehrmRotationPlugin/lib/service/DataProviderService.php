<?php

class DataProviderService {

    public function getActiveEmployees($options = array()) {
        return array(); // TODO: fetch from DB
    }

    public function getPosts() {
        return array(); // TODO: fetch from DB
    }

    public function getRotationWithAssignments($id) {
        return array('id'=>$id,'items'=>array());
    }
}
