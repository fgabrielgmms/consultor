<?php

class ConstraintEngine {

    private $hardViolations = array();
    private $warnings = array();

    public function reset() {
        $this->hardViolations = array();
        $this->warnings = array();
    }

    public function getViolations() { return $this->hardViolations; }
    public function getWarnings() { return $this->warnings; }

    public function validateCandidate($candidate) {
        $ok = true;
        $emp = isset($candidate['employee']) ? $candidate['employee'] : array();
        $post = isset($candidate['post']) ? $candidate['post'] : array();

        if (!empty($emp['lastPosts'])) {
            $lastDate = isset($emp['lastPosts'][$candidate['postId']]) ? $emp['lastPosts'][$candidate['postId']] : null;
            if ($lastDate && strtotime($candidate['from']) < strtotime($lastDate . ' +12 months')) {
                $this->hardViolations[] = "Employee {$emp['id']} repeated post within 12 months";
                $ok = false;
            }
        }

        if (!empty($post['requiresPras']) && empty($emp['isPras'])) {
            $this->hardViolations[] = "Post {$candidate['postId']} requires PRAS";
            $ok = false;
        }

        if ((isset($emp['gender']) ? $emp['gender'] : '') !== 'F') {
            $this->warnings[] = "Gender balance check pending for post {$candidate['postId']}";
        }

        if ((isset($post['type']) ? $post['type'] : '') === 'aquatic' && !empty($emp['lastEndDate'])) {
            if (strtotime($candidate['from']) < strtotime($emp['lastEndDate'] . ' +2 days')) {
                $this->hardViolations[] = "Employee {$emp['id']} needs 2-day gap before aquatic post";
                $ok = false;
            }
        }

        foreach (isset($emp['vacations']) ? $emp['vacations'] : array() as $v) {
            if (!($candidate['to'] < $v['from'] || $candidate['from'] > $v['to'])) {
                $this->hardViolations[] = "Employee {$emp['id']} has vacation overlap";
                $ok = false; break;
            }
        }
        foreach (isset($emp['leaves']) ? $emp['leaves'] : array() as $l) {
            if (!($candidate['to'] < $l['from'] || $candidate['from'] > $l['to'])) {
                $this->hardViolations[] = "Employee {$emp['id']} has leave overlap";
                $ok = false; break;
            }
        }

        return $ok;
    }

    public function validateGroup($group) {
        $ok = true;
        $assignments = isset($group['assignments']) ? $group['assignments'] : array();
        $minStaff = isset($group['post']['minStaff']) ? $group['post']['minStaff'] : 4;

        if (count($assignments) < $minStaff) {
            $this->hardViolations[] = "Post {$group['postId']} below min staff ($minStaff)";
            $ok = false;
        }
        if (!array_filter($assignments, function($c) { return (isset($c['employee']['gender']) ? $c['employee']['gender'] : '') === 'F'; })) {
            $this->hardViolations[] = "Post {$group['postId']} requires at least one woman";
            $ok = false;
        }
        if (!empty($group['post']['requiresPras'])) {
            if (!array_filter($assignments, function($c) { return !empty($c['employee']['isPras']); })) {
                $this->hardViolations[] = "Post {$group['postId']} requires at least one PRAS";
                $ok = false;
            }
        }
        $shifts = array_count_values(array_map(function($c) { return $c['shiftType']; }, $assignments));
        if (empty($shifts['20_9']) || empty($shifts['5_2'])) {
            $this->warnings[] = "Post {$group['postId']} missing ideal 20/9 + 5/2 mix";
        }

        return $ok;
    }
}
