<?php

class RotationService {

    protected $rotationDao;
    protected $dataProvider;
    protected $engine;

    public function __construct() {
        $this->rotationDao = new RotationDao();
        $this->dataProvider = new DataProviderService();
        $this->engine = new ConstraintEngine();
    }

    public function generateRotation($options = array()) {
        $start = isset($options['startDate']) ? $options['startDate'] : date('Y-m-01');
        $end = isset($options['endDate']) ? $options['endDate'] : date('Y-m-t', strtotime($start . ' +3 months'));

        $employees = $this->dataProvider->getActiveEmployees();
        $posts = $this->dataProvider->getPosts();

        $assignmentsByPost = array();
        $this->engine->reset();

        foreach ($posts as $post) {
            $postId = $post['id'];
            $assignmentsByPost[$postId] = array('postId'=>$postId, 'post'=>$post, 'assignments'=>array());

            foreach ($employees as $emp) {
                if (count($assignmentsByPost[$postId]['assignments']) >= (isset($post['minStaff']) ? $post['minStaff'] : 4)) {
                    break;
                }
                foreach (array('20_9','5_2') as $shift) {
                    $candidate = array(
                        'employeeId'=>$emp['id'],'postId'=>$postId,'from'=>$start,'to'=>$end,
                        'shiftType'=>$shift,'isCoordinator'=>0,'employee'=>$emp,'post'=>$post
                    );
                    if ($this->engine->validateCandidate($candidate)) {
                        $assignmentsByPost[$postId]['assignments'][] = $candidate;
                        break;
                    }
                }
            }
            $this->engine->validateGroup($assignmentsByPost[$postId]);
        }

        return array(
            'status' => empty($this->engine->getViolations()) ? 'ok' : 'conflict',
            'startDate' => $start,
            'endDate' => $end,
            'posts' => array_values($assignmentsByPost),
            'violations' => $this->engine->getViolations(),
            'warnings' => $this->engine->getWarnings()
        );
    }

    public function publishRotation($id) {
        return array('status' => 'published', 'id' => $id);
    }

    public function getRotation($id) {
        return $this->dataProvider->getRotationWithAssignments($id);
    }
}
