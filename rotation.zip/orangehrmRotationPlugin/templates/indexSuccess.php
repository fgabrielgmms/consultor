<h1>Catálogo de Puestos de Control - PNY</h1>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Nombre</th>
        <th>Tipo</th>
        <th>Min. Personal</th>
        <th>Requiere PRAS</th>
    </tr>
    <?php foreach ($posts as $p): ?>
    <tr>
        <td><?php echo htmlspecialchars($p['name']); ?></td>
        <td><?php echo htmlspecialchars($p['type']); ?></td>
        <td><?php echo (int)$p['min_staff']; ?></td>
        <td><?php echo $p['requires_pras'] ? 'Sí' : 'No'; ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<br>
<form method="post" action="<?php echo url_for('rotation/generate'); ?>">
    <input type="hidden" name="startDate" value="<?php echo date('Y-m-01'); ?>">
    <input type="hidden" name="endDate" value="<?php echo date('Y-m-t', strtotime('+3 months')); ?>">
    <button type="submit">Generar Rotación</button>
</form>
