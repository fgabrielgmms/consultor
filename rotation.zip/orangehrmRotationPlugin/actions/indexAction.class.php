<?php

class rotationIndexAction extends sfAction {
    public function execute($request) {
        $conn = Doctrine_Manager::getInstance()->getCurrentConnection();
        $result = $conn->fetchAll("SELECT * FROM ohrm_rot_post ORDER BY name ASC");
        $this->posts = $result;
    }
}
