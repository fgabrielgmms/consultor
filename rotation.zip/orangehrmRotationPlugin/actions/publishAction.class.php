<?php

class rotationPublishAction extends sfAction {
    public function execute($request) {
        $id = $request->getParameter('id');
        $service = new RotationService();
        $data = $service->publishRotation($id);
        return $this->renderText(json_encode($data));
    }
}
