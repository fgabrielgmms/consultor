<?php

class rotationGenerateAction extends sfAction {
    public function execute($request) {
        $service = new RotationService();
        $data = $service->generateRotation($request->getParameterHolder()->getAll());
        return $this->renderText(json_encode($data));
    }
}
