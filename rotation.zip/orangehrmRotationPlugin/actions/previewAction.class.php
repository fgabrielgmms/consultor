<?php

class rotationPreviewAction extends sfAction {
    public function execute($request) {
        $id = $request->getParameter('id');
        $service = new RotationService();
        $data = $service->getRotation($id);
        return $this->renderText(json_encode($data));
    }
}
