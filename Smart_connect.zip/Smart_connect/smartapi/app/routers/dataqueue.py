from fastapi import Depends, FastAPI, HTTPException, APIRouter, Security, Query
from fastapi.responses import JSONResponse
from user import User, get_current_active_user
#from api import app, oauth2_scheme
from typing import Annotated, List, Union

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

#from pydantic import BaseModel
from pydantic import TypeAdapter
import os

#import SMARTConnectDatabase as smdb

from pandas import DataFrame
from uuid import UUID
import requests
import json
import datetime
import pandas as pd
import geopandas as gpd
from internal.helper import format_observations, format_patrol
#from .employee import Employee
#from ..internal.classes import Patrol

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from geoalchemy2 import functions as geofunc
from datetime import timedelta
import sql.crud
from internal import track
from user import User, get_current_active_user
import numpy as np
from math import radians, sin, cos, sqrt, atan2, degrees
from pyproj import Proj, transform
from pydantic import BaseModel
import datetime
from config import Settings, get_settings
#import SMARTConnect as sc
import re
import logging
from config import Settings,get_settings


router = APIRouter(
    prefix="/dataqueue",
    tags=["dataqueue"],
    responses={404: {"description": "Not found"}},
)

class DataqueueEntry(BaseModel):
    uuid:       UUID
    type:       str
    ca_uuid:    UUID
    name:       str|None
    uploaded_date: datetime.datetime
    lastmodified_date: datetime.datetime|None
    uploaded_by:    str
    file: str|None
    status: str
    status_message: str|None
    work_item_uuid: UUID|None
        

@router.get("/load/", response_model=list[DataqueueEntry], include_in_schema=get_settings().DEV_INCLUDE_IN_SCHEMA)
async def load_dataqueue(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
            language_uuid:  Annotated[UUID, "Conservation Area ID"],

            status:         Annotated[str, "Status"] = "QUEUED",
            
            db: Session = Depends(database.get_db) 
    ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    logging.debug(f"load_dataqueue(ca_uuid={ca_uuid}, status={status})")

    # Verify, if user has permission to view this CA
    #current_user.check_permission("viewca", ca_uuid)
    
    query = db.query(
                    database.connect_dataqueue
                ).where(database.connect_dataqueue.c.ca_uuid == ca_uuid)
    
    if status:
        query = query.where(database.connect_dataqueue.c.status == status)

    rows = query.all()
    if rows is None:
        raise HTTPException(status_code=404, detail="Area geometry not found")
    
    return rows

@router.get("/files/", include_in_schema=get_settings().DEV_INCLUDE_IN_SCHEMA) #, response_class=JSONResponse)
async def load_dataqueue_item(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
            language_uuid:  Annotated[UUID, "Conservation Area ID"],

            uuid: Annotated[list[UUID], Query()] = [],
            deviceid: Annotated[str|None, "Device ID"] = None,# UUID("682db27fb03b5ee40000000000000000"),
            status: Annotated[str|None, "Status"] = None,
            start_date: Annotated[datetime.date|None, "Uploaded Start"] = None,
            end_date: Annotated[datetime.date|None, "Uploaded End"]  = None,

            #current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            
            
            db: Session = Depends(database.get_db) 
    ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    logging.debug(f"load_dataqueue_item(uuid={uuid}, ca_uuid={ca_uuid}, deviceid={deviceid}, status={status}, start_date={start_date}, end_date={end_date})")

    """Returns a dataqueue record"""
    
    dataqueue_path = "C:/Smart/ConnectInstall/docker/smart755/smartdata/smartfilestore/filestore"
    
    query = db.query(
                    database.connect_dataqueue.c.uuid,
                    database.connect_dataqueue.c.ca_uuid,
                    database.connect_dataqueue.c.name,
                    database.connect_dataqueue.c.file,
                    database.connect_dataqueue.c.status,
                    database.connect_dataqueue.c.uploaded_date
                ).where(database.connect_dataqueue.c.ca_uuid == ca_uuid)
    
    if len(uuid) > 0:
        query = query.where(database.connect_dataqueue.c.uuid.in_(uuid))
    
    if status:
        query = query.where(database.connect_dataqueue.c.status == status)

    if start_date:
        query = query.where(database.connect_dataqueue.c.uploaded_date >= start_date)
    if end_date:
        query = query.where(database.connect_dataqueue.c.uploaded_date <= end_date)

    
    rows = query.all()
    
    employees = db.query(
                                                    database.employee.c.uuid, 
                                                    database.employee.c.givenname,
                                                    database.employee.c.familyname
                                                ).where(database.employee.c.ca_uuid == ca_uuid).all()
    dfEmployees = pd.DataFrame([_r._asdict() for _r in employees])
    
    
    gpdf = gpd.GeoDataFrame()
    
    for row in rows:
        u = row.uuid
        filename = f'{dataqueue_path}/{row.file}'
        #print(filename)
        try: 
            with open(filename, 'r') as f:
                df = gpd.GeoDataFrame.from_file(f)
                df['status'] = row.status
                gpdf: gpd.GeoDataFrame = pd.concat([gpdf, df]).reindex()
        except FileNotFoundError: 
            print(f'{filename} not found')
        except IsADirectoryError:
            pass
        except:
            print(f'Exception when reading {filename}')
            pass
            
    if deviceid:
        gpdf = gpdf.where(gpdf.deviceId == deviceid).dropna(how='all')
        
    # Find the Patrol Leader
    for s in gpdf.where(gpdf.SMART_ObservationType != 'waypoint').dropna(how='all').iloc():
        leader_uuid = UUID(s.sighting['SMART_Leader'].split(':')[1])
        leader = dfEmployees.where(dfEmployees['uuid'] == leader_uuid).dropna(how='all') #.first()
        if len(leader)==1:
            s.sighting['Patrol_Leader'] = f'{leader.givenname.values[0]} {leader.familyname.values[0]}' 
            #s['Patrol_Leader'] = f'{leader.givenname.values[0]} {leader.familyname.values[0]}' 
        #print(s)
    
    #print(gpdf.info())
        
    if len(gpdf.index) > 0:
        return gpdf._to_geo()
    else:
        raise HTTPException(status_code=404,detail="File not found")    
            
        
    settings: Settings = get_settings()

    session = requests.Session()
        
    session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
    url = settings.SMART_CONNECT_URL
    
    response = session.get(url=f'{url}/api/dataqueue/items/{uuid}/file', verify=False)
    
    if response.ok:
        #print(response.text)
        return json.loads(response.text)
        return response.text
    
    print(response.text)
    raise HTTPException(
                status_code=response.status_code,
                detail=response.text,                
            )

#@router.get("/", response_class=JSONResponse)
async def load_dataqueue_item2(
            current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
            language_uuid:  Annotated[UUID, "Conservation Area ID"],

            uuid: Annotated[list[UUID], "UUID"],
            
            db: Session = Depends(database.get_db) 
    ):
    

    """Returns a list of dataqueue record"""
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    settings: Settings = get_settings()

    session = requests.Session()
        
    session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
    url = settings.SMART_CONNECT_URL
    
    response = session.get(url=f'{url}/api/dataqueue/items/{uuid}/file', verify=False)
    
    if response.ok:
        #print(response.text)
        return json.loads(response.text)
        return response.text
    
    print(response.text)
    raise HTTPException(
                status_code=response.status_code,
                detail=response.text,                
            )

