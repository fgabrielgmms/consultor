from fastapi import APIRouter, Depends, Security
from user import User, get_current_active_user

from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database


router = APIRouter(
    prefix="/patrol_mandate",
    tags=["patrol_mandate"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class PatrolMandate(BaseModel):
    uuid:       UUID
    ca_uuid:    UUID
    keyid:      str|None
    #desc_uuid:  UUID|None
    name:       str|None
    is_active:  bool

    class Config:
        orm_mode = True

    


@router.get("/", response_model=list[PatrolMandate])
async def get_mandates(
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    language_uuid:  Annotated[UUID, "Language ID"],
                    db:             Session = Depends(database.get_db)
                 ) -> list[PatrolMandate]:
    """
    Load the list of patrol mandates for the given CA and translate the names into the given language
    """
    current_user.check_permission("viewca", ca_uuid)

    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.patrol_mandate,
               func.reporting.get_translations(database.patrol_mandate.c.uuid, language_uuid).label("name"),
               ).where(database.patrol_mandate.c.ca_uuid == ca_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading patrol_mandates")



@router.get("/{uuid}/", response_model=PatrolMandate)
async def get_mandates(current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    uuid:           Annotated[UUID, "Mandate UUID"],
                    language_uuid:  Annotated[UUID, "Language UUID"],
                    db:             Session = Depends(database.get_db)
                 ) -> list[PatrolMandate]:
    
    current_user.check_permission("viewca", ca_uuid)

    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.patrol_mandate,
               func.reporting.get_translations(database.patrol_mandate.c.uuid, language_uuid).label("name"),
               ).where(database.patrol_mandate.c.uuid == uuid)
    try:
        return db.execute(q).first()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading patrol_mandates")




#@router.put("/{mandate_uuid}")
#async def update_mandate(mandate_uuid:str):
#    raise HTTPException(404,"Not implemented yet")
#    return ""

#@router.post("/{mandate_uuid}")
#async def add_mandate(mandate_uuid:str):
#    raise HTTPException(404,"Not implemented yet")
#    return ""

#@router.delete("/{mandate_uuid}")
#async def delete_mandate(mandate_uuid:str):
#    raise HTTPException(404,"Not implemented yet")
#    return ""
