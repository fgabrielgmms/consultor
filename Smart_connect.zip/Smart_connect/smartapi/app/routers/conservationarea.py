from fastapi import Depends, FastAPI, HTTPException, APIRouter, Security
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import JSONResponse

from pydantic import BaseModel

# import SMARTConnectDatabase as smdb
# import SMARTConnect as sc

from pandas import DataFrame
from uuid import UUID
import requests
import json
from config import Settings, get_settings
from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid
import geopandas as gpd

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from geoalchemy2 import functions as geofunc
from enum import Enum, auto
from main import oauth2_scheme
from user import User, get_current_active_user

import sql.conservationarea


router = APIRouter(
    prefix="/conservationarea",
    tags=["conservationarea"],
    responses={404: {"description": "Not found"}},
)


# def exception_handler(func):
#     def inner_function(*args, **kwargs):
#         try:
#             func(*args, **kwargs)
#         except ZeroDivisionError as zde:
#             print(zde)
#             raise HTTPException(status_code=500, detail="Division by zero")
#         except Exception as e:
#             print(e)
#             raise HTTPException(status_code=500, detail=e)
    
#     return inner_function
    



@router.get("/", 
            response_model=list[schemas.ConservationArea],
            description="Return the list of CAs hosted by the server the user has access to")
async def get_conservation_areas(
            current_user:       Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            #language_uuid:      Annotated[UUID, "Language ID"],
            db =                Depends(database.get_smart_db)
          ):
    
    # Find the CAs allowed to view
    if "admin:None" in current_user.scopes:
        return sql.conservationarea.query_cas(db=db, cas=None)
    
    cas = current_user.extract_resource_from_scopes("viewca")
    
    return sql.conservationarea.query_cas(db=db, cas=cas)
    
    

    
@router.get("/{ca_uuid}", response_model=list[schemas.ConservationArea])
async def get_ca( current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
            ca_uuid:            Annotated[UUID, "Conservation Area ID"], 
            language_uuid:      Annotated[UUID, "Language ID"],
            
            db: Session = Depends(database.get_smart_db)):
    """
    Get Details for the CA
    """
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    return sql.conservationarea.query_cas(db=db, language_uuid=language_uuid, cas=[ca_uuid])
    
    
    
@router.get("/{ca_uuid}/properties", 
            response_model=list[schemas.ConservationAreaProperties], 
            summary="Returns the properties of the CA", 
            description="The properties of a CA are set of key and value pairs")
async def get_conservation_area_properties(# token: Annotated[str, Depends(oauth2_scheme)],
                        current_user:       Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        ca_uuid:            Annotated[UUID, "Conservation Area ID"], 
                        language_uuid:      Annotated[UUID, "Language ID"],
                        db                  = Depends(database.get_smart_db)
                      ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Return the properties of the CA
    return sql.conservationarea.query_ca_properties(db= db, ca_uuid = ca_uuid)

# @router.get("/{ca_uuid}/basemaps", response_model=list[schemas.BaseMap]
#             #response_class=JSONResponse            
#             )
# async def get_conservation_basemaps(# token: Annotated[str, Depends(oauth2_scheme)],
#                         current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
#                         ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53", 
#                         db: Session = Depends(database.get_db)
#                       ):
#     """
#     Returns the Basemaps from SMART Connect
#     TBD: Filter on ca_uuid not working
#     TBD: Change to direct database access
#     """
#     # Verify, if user has permission to view this CA
#     current_user.check_permission("viewca", ca_uuid)

#     rows = db.query(
#                     database.saved_maps.c.uuid,
#                     database.saved_maps.c.ca_uuid,
#                     database.saved_maps.c.is_default,
#                     database.saved_maps.c.map_def,
                    
#                 ).where(database.saved_maps.c.ca_uuid == ca_uuid).all()
#     #return rows
#     #df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
#     df = DataFrame([_r._asdict() for _r in rows])
#     # Extract additional info
#     for saved_map in df.iloc():
#         mapdef = json.loads(saved_map.map_def)
#         print(mapdef['name'])
    
#     return df


    
#     settings: Settings = get_settings()

#     session = requests.Session()
        
#     session.auth = (settings.SMART_CONNECT_USERNAME, settings.SMART_CONNECT_PASSWORD)
#     url = settings.SMART_CONNECT_URL
#     response = session.get(url=f"{url}/api/basemap", verify=False )
#     if response.ok:
#         print(response.text)
#         return json.loads(response.text)
    
#     return sc.SMARTConnect().GetBaseMaps()    

class area_types(str, Enum):
    BA:     str =       "BA"
    CA:     str =       "CA"
    PTRL:   str =       "PTRL"
    ADMIN:  str =       "ADMIN"
    MNGT:   str =       "MNGT"

    
@router.get("/{ca_uuid}/area_geometry", 
            response_class=JSONResponse
            #response_model=list[schemas.AreaGeometry]
            )
async def get_conservation_area_geometry(# token: Annotated[str, Depends(oauth2_scheme)],
                        current_user: Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        ca_uuid: Annotated[UUID, "Conservation Area ID"], 
                        area_type: Annotated[area_types|None, "Area Type"] = None,
                        #area_type: Annotated[str| None, "Area Type"] = None,
                        keyid:  Annotated[str| None, "Keyid"] = None,
                        output_type:    Annotated[str|None, "Output Type"] = "geojson",          # raw, geojson, flat                        
                        db = Depends(database.get_smart_db)
                      ):
    """
    Return a list of area_geometries as GeoJSON
    """

    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
   
    rows = sql.conservationarea.query_ca_geometries(db= db, ca_uuid = ca_uuid, area_type=area_type, keyid=keyid)

    if rows is None:
        raise HTTPException(status_code=404, detail="Area geometry not found")
    #return ag
    df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
        
    # Convert Track to geomety
    df['geometry'] = df.apply(lambda row: shapely.from_wkt(row.geometry), axis=1)
    df.set_geometry('geometry', inplace=True, crs=4326) 

    print(df.head())

    return df._to_geo()

