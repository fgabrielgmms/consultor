from fastapi import APIRouter, File, UploadFile, Depends, HTTPException, Query, Security
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel
from pydantic.types import StrictBool

import datetime

from pandas import DataFrame
from uuid import UUID
from sql import models,schemas
from sql import database
from sqlalchemy import select, func, join
from sqlalchemy.orm import Session
from sqlalchemy.sql import text
from fastapi.responses import JSONResponse

import sql.datamodel


router = APIRouter(
    prefix="/datamodell",
    tags=["datamodell"],
    responses={404: {"description": "Not found"}},
)

class dm_attribute_list(BaseModel):
    uuid:           UUID
    name:           str
    keyid:          str    
    attribute_uuid: UUID
    list_order:     int
    is_active:      bool
    icon_uuid:      UUID|None
    class Config:
        orm_mode = True 


class dm_attribute_tree(BaseModel):
    uuid:           UUID
    name:           str
    keyid:          str    
    attribute_uuid: UUID
    parent_uuid:    UUID|None
    node_order:     int
    is_active:      bool
    icon_uuid:      UUID|None
    class Config:
        orm_mode = True 

                                        

class dm_attribute(BaseModel):
    uuid:               UUID
    name:               str
    keyid:              str
    att_type:           str
    min_value:          float|None
    max_value:          float|None
    regex:              str|None
    icon_uuid:          UUID|None
    is_required:        bool|None
    attribute_list:     list[dm_attribute_list] = []
    attribute_tree:     list[dm_attribute_tree] = []
    class Config:
        orm_mode = True 

                                        

class dm_category(BaseModel):
    uuid:   UUID
    name:   str
    ca_uuid:    UUID
    keyid:      str
    is_active:  bool
    hkey:       str|None
    parent_category_uuid: UUID|None
    is_multiple:    bool|None
    cat_order:      int
    icon_uuid:      UUID|None
                                        
    attributes: list[dm_attribute] = []
    class Config:
        orm_mode = True 


#@router.get("/category/{category_uuid}", response_class=JSONResponse  )
@router.get("/category/{category_uuid}", response_model=list[dm_category])
async   def get_dm_category(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        category_uuid:  Annotated[UUID, "category_uuid"],
                        
                        ca_uuid:        Annotated[UUID|None, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID|None, "Language ID"],
                        
                        db =            Depends(database.get_smart_db),
                        ):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    try:
    #     rows = db.execute(q).fetchall()
        rows = sql.datamodel.query_dm_category(db=db, category_uuid = category_uuid, ca_uuid = ca_uuid, language_uuid = language_uuid)
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of dm_categories")
    
    print(len(rows))
    #json_data = [_r._asdict() for _r in rows]

    
    result = []
    
    prevuuid = None
    cat = None
    for row in rows:
        if row.uuid != prevuuid:
            cat=dm_category(uuid=row.uuid, name=row.name, ca_uuid=row.ca_uuid, keyid = row.keyid, is_active=row.is_active, hkey=row.hkey, parent_category_uuid=row.parent_category_uuid, is_multiple=row.is_multiple, cat_order=row.cat_order, icon_uuid=row.icon_uuid)

        att = dm_attribute(uuid=row.attribute_uuid, name=row.attribute_name, 
                                keyid = row.attribute_keyid,
                                att_type = row.attribute_att_type,
                                min_value = row.attribute_min_value,
                                max_value = row.attribute_max_value,
                                regex = row.attribute_regex,
                                icon_uuid = row.attribute_icon_uuid,
                                is_required = row.attribute_is_required
        )

        if row.attribute_att_type == "TREE":
            att.attribute_tree.append(get_dm_attribute_tree(current_user=current_user, ca_uuid=ca_uuid,language_uuid=language_uuid,attribute_uuid=row.attribute_uuid,is_active=True, db=db))
        if row.attribute_att_type == "LIST":
            att.attribute_list.append(get_dm_attribute_list(current_user=current_user, ca_uuid=ca_uuid,language_uuid=language_uuid,attribute_uuid=row.attribute_uuid,is_active=True, db=db))

        cat.attributes.append(att)
            
        prevuuid = row.uuid

    result.append(cat)
    return result


@router.get("/category/", response_model=list[schemas.DM_Category])
#@router.get("/category/")
def get_dm_categories(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        
                        ca_uuid:        Annotated[UUID|None, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
                        language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        active_only:    Annotated[bool|None, "active only"] = True,
                        db  =           Depends(database.get_smart_db)):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    try:
        return sql.datamodel.query_dm_categories(db=db, ca_uuid = ca_uuid, language_uuid = language_uuid, active_only=active_only)            
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of categories")
    
    

    
@router.get("/attribute/", response_model=list[schemas.DM_Attribute])
def get_dm_attributes(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        
                        ca_uuid:        Annotated[UUID|None, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
                        language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        att_type:       Annotated[str|None, Query(title = "Attribute Type",
                                                                  description="LIST, NUMERIC, BOOLEAN, TEXT, TREE",
                                                                  pattern="^(LIST|NUMERIC|BOOLEAN|TEXT|TREE)$")
                                                                  ] = None,
                        db =   Depends(database.get_smart_db)):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    try:
        return sql.datamodel.query_dm_attributes(db=db,ca_uuid = ca_uuid, language_uuid = language_uuid, att_type=att_type)    
    except Exception as e:
            print(e)
            raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
    
    
#@router.get("/attribute/{attribute_uuid}") #, response_model=list[schemas.DM_Attribute])
@router.get("/attribute/{attribute_uuid}")# , response_class=dm_attribute)
async def get_dm_attribute(
                        current_user:       Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        attribute_uuid:     Annotated[UUID|None, "Attribute UUID"],
                        ca_uuid:            Annotated[UUID|None, "Conservation Area ID"],
                        language_uuid:      Annotated[UUID, "Language ID"],
                        # att_type:           Annotated[str|None, Query(title = "Attribute Type",
                        #                                           description="LIST, NUMERIC, BOOLEAN, TEXT, TREE",
                        #                                           pattern="^(LIST|NUMERIC|BOOLEAN|TEXT|TREE)$")
                        #                                           ] = None,
                        db =   Depends(database.get_smart_db)):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    try:
        row = sql.datamodel.query_dm_attribute(db=db, ca_uuid = ca_uuid, language_uuid = language_uuid, attribute_uuid=attribute_uuid)
        
        att = dm_attribute(     uuid = row.uuid, 
                                name = row.name, 
                                keyid = row.keyid,
                                att_type = row.att_type,
                                min_value = row.min_value,
                                max_value = row.max_value,
                                regex = row.regex,
                                icon_uuid = row.icon_uuid,
                                is_required = row.is_required                                
        )
        if att.att_type == 'LIST':
            rows = sql.datamodel.query_dm_attribute_list(db=db, ca_uuid=ca_uuid, language_uuid=language_uuid, attribute_uuid=attribute_uuid)
        
            result = []
            for row in rows:
                result.append(dm_attribute_list(uuid=row.uuid, attribute_uuid = row.attribute_uuid, 
                                    keyid=row.keyid, list_order=row.list_order, is_active=row.is_active, icon_uuid=row.icon_uuid, name=row.name))
            att.attribute_list = result
            
        elif att.att_type == 'TREE':
            rows = sql.datamodel.query_dm_attribute_tree(db=db, ca_uuid=ca_uuid, language_uuid=language_uuid, attribute_uuid=attribute_uuid)
        
            result = []
            for row in rows:
                result.append(dm_attribute_tree(uuid=row.uuid, attribute_uuid = row.attribute_uuid, 
                                    keyid=row.keyid, is_active=row.is_active, icon_uuid=row.icon_uuid, name=row.name, parent_uuid=row.parent_uuid, node_order=row.node_order))
            att.attribute_tree = result
        
        return att
    except Exception as e:
            print(e)
            raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
    
    

@router.get("/attribute_list/", response_model=list[dm_attribute_list])
def get_dm_attribute_list(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID, "Language ID"],
                        attribute_uuid: Annotated[UUID, "Attribute UUID"],
                        is_active:      Annotated[bool|None, "active only"] = True,
                        db =   Depends(database.get_smart_db)):
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    try:        
        rows = sql.datamodel.query_dm_attribute_list(db=db, ca_uuid=ca_uuid, language_uuid=language_uuid, attribute_uuid=attribute_uuid, is_active=is_active)
        
        result = []
        for row in rows:
            result.append(dm_attribute_list(uuid=row.uuid, attribute_uuid = row.attribute_uuid, 
                                keyid=row.keyid, list_order=row.list_order, is_active=row.is_active, icon_uuid=row.icon_uuid, name=row.name))
        return result
    except Exception as e:
            print(e)
            raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
    

    
@router.get("/attribute_tree/", response_model=list[dm_attribute_tree])
def get_dm_attribute_tree(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        
                        ca_uuid:        Annotated[UUID|None, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
                        language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        attribute_uuid: Annotated[UUID, "Attribute UUID"] = UUID('47efe273-01b1-4b45-aea6-90c06aef4eb4'),
                        is_active:    Annotated[bool|None, "active only"] = True,
                        db =   Depends(database.get_smart_db),):
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    result = []
    try:
        rows = sql.datamodel.query_dm_attribute_tree(db=db, ca_uuid=ca_uuid, language_uuid=language_uuid, attribute_uuid=attribute_uuid, is_active=is_active)
        for row in rows:
            result.append(dm_attribute_tree(uuid=row.uuid, attribute_uuid = row.attribute_uuid, parent_uuid=row.parent_uuid,
                                keyid=row.keyid,node_order=row.node_order,is_active=row.is_active, icon_uuid=row.icon_uuid, name=row.name))
        return result
    except Exception as e:
            print(e)
            raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
        
