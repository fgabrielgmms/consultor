from fastapi import Depends, FastAPI, HTTPException, APIRouter, Query, Security
from user import User, get_current_active_user

from fastapi.responses import JSONResponse
#from api import app, oauth2_scheme
from typing import Annotated, List
from enum import Enum, auto

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

#from pydantic import BaseModel
from pydantic import TypeAdapter

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
import requests
import json
import datetime
import pandas as pd
import geopandas as gpd
from internal.helper import format_observations, format_patrol
#from .employee import Employee
#from ..internal.classes import Patrol

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text, functions
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt, distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database 
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
import shapely
from config import get_settings



router = APIRouter(
    prefix="/efforts",
    tags=["efforts"],
    responses={404: {"description": "Not found"}},
)

class group_bys(str, Enum):
    employee : str =      "employee"
    team: str =           "team"
    days: str =             "days"
    month: str =             "month"
    year: str =             "year"


@router.get("/", response_class=JSONResponse)
async def get_efforts(
                current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                        
                ca_uuid: Annotated[UUID, "CA"] = get_settings().DEFAULT_CA_UUID, #UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
                language_uuid:  Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        
                team_uuid: Annotated[UUID|None, "Team"] = None,
                employee_team_uuid: Annotated[UUID|None, "Emplyee Team"] = None,
                station_uuid: Annotated[UUID|None, "Station"] = None,
                mandate_uuid: Annotated[UUID|None, "Mandate"] = None, #UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol

                transport_uuid: Annotated[UUID|None, "Transport Type"] = None, # UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
                #employee_uuid: List[UUID] = Query(None, description="List Employee UUIDs"),
                employee_uuid: Annotated[ List[UUID], Query(description="List Employee UUIDs")] = [], 

                start_date: Annotated[datetime.date|None, "Start"] = datetime.date(2023,1,1),
                end_date: Annotated[datetime.date|None, "End"]  = datetime.date(2023,2,1),

                include_observations: Annotated[bool, "Include Statistics on Observations"]  = False,

                #group_by: group_bys = group_bys.employee,
                group_by2: group_bys = group_bys.employee,
                
                db: Session = Depends(database.get_db) ):
    """
    Retrieves Patrol Efforts.
    Returns JSON with the following fields:
        Number of Patrols, Patrol-Legs and Patrol-Leg-Days
        Number of Observations from these patrols (add filter for categories?)
        Covered Distance
        Duration
        Avg Speed
    """

    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})


    #Define the joins
    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                .join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
    )

    if employee_uuid:
        j = (j
                    .join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid, isouter=False)
        )

    if include_observations:
        j = (j
                    .join(database.patrol_waypoint, database.patrol_waypoint.c.leg_day_uuid == database.patrol_leg_day.c.uuid, isouter=True)
                    .join(database.waypoint, database.waypoint.c.uuid == database.patrol_waypoint.c.wp_uuid, isouter=True)
                    .join(database.wp_observation_group, database.wp_observation_group.c.wp_uuid == database.waypoint.c.uuid, isouter=True)
                    .join(database.wp_observation, database.wp_observation.c.wp_group_uuid == database.wp_observation_group.c.uuid, isouter=True)
        )

    q = select(
                            functions.count(distinct(database.patrol.c.uuid)).label("Patrol Count"),
                            functions.count(distinct(database.patrol_leg.c.uuid)).label("Patrol Leg Count"),
                            functions.count(distinct(database.patrol_leg_day.c.uuid)).label("Patrol Leg Day Count"),
                            functions.sum(database.track.c.distance).label("distance"),

                            functions.min(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("First Patrol Start Time "),
                            functions.max(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("Last Patrol End Time "),
                    
                            # Duration
                            functions.sum(database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            functions.sum((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            func.avg(database.track.c.distance).label("average distance"),


                    ).select_from(j)#.group_by(database.patrol.c.ca_uuid)
    # Set the CA filter
    
    q = q.where(database.patrol.c.ca_uuid == ca_uuid)
      
    if start_date is not None and end_date is not None:
        q = q.where(database.patrol.c.start_date >= start_date).where(database.patrol.c.start_date <= end_date) 

    if team_uuid:
        q = q.where(database.patrol.c.team_uuid == team_uuid)

    if employee_team_uuid:
        pass
        #stmt = stmt.where(models.Patrol.team_uuid == team_uuid)

    if station_uuid:
        q = q.where(database.patrol.c.station_uuid == station_uuid)

    if mandate_uuid:
        q = q.where(database.patrol_leg.c.mandate_uuid == mandate_uuid)

    if transport_uuid:
        q = q.where(database.patrol_leg.c.transport_uuid == transport_uuid)

    if employee_uuid:
        q = q.add_columns(database.patrol_leg_members.c.employee_uuid)
        #q = q.add_columns(database.employee.c.givenname)
        #q = q.add_columns(database.employee.c.familyname)
        q = q.group_by(database.patrol_leg_members.c.employee_uuid)
        if UUID("00000000-0000-0000-0000-000000000000") not in employee_uuid:
            q = q.where(database.patrol_leg_members.c.employee_uuid.in_(employee_uuid))

    if include_observations:
        q = q.add_columns(functions.count(distinct(database.wp_observation.c.uuid)).label("observation_count"))
        q = q.add_columns((functions.count(distinct(database.wp_observation.c.uuid))/functions.count(distinct(database.patrol.c.uuid))).label("average_observation_count"))
        
        
    #print(q)

    try:
        rows = db.execute(q).all()
    except Exception as e:
        print(e)
        return e
    
    # Convert rows into dict to output as JSON
    json_data = [_r._asdict() for _r in rows]
    return json_data
    