from fastapi import APIRouter, Security, Depends
from user import User, get_current_active_user

from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime


from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session

router = APIRouter(
    prefix="/team",
    tags=["team"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class Team(BaseModel):
    uuid:           UUID
    ca_uuid:        UUID
    keyid:          str
    desc_uuid:      UUID|None
    name:           str|None
    description:    str|None
    is_active:      bool
    


@router.get("/")
async def get_teams(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid: Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    language_uuid: Annotated[UUID, "Conservation Area ID"] = '2af26704-7dd9-4a77-bbd4-c1953800d4f8',
                    active_only: Annotated[bool, "Show only active teams"] = True,
                    db:             Session = Depends(database.get_db)

                 ) -> list[Team]:
    
        # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.team,
               func.reporting.get_translations(database.team.c.uuid, language_uuid).label("name"),
               func.reporting.get_translations(database.team.c.desc_uuid, language_uuid).label("description"),
               ).where(database.team.c.ca_uuid == ca_uuid)
    if active_only:
        q = q.where(database.team.c.is_active == True)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading teams")

    
    
# @router.put("/{team_uuid}")
# async def update_employee(team_uuid:str):
#     raise HTTPException(404,"Not implemented yet")
#     return ""


# @router.post("/{team_uuid}")
# async def add_employee(team_uuid:str):
#     raise HTTPException(404,"Not implemented yet")
#     return ""

# @router.delete("/{team_uuid}")
# async def delete_employee(team_uuid:str):
#     raise HTTPException(404,"Not implemented yet")
#     return ""
