from fastapi import APIRouter, File, UploadFile, Depends, HTTPException, status, Query, Body, Form, Response, Security
from user import User, get_current_active_user

from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
#from api import app, oauth2_scheme
from typing import Annotated, List
from config import get_settings

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel
import aiofiles
import os
import pandas as pd
#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
import uuid
import requests
import json
import datetime
import geopandas as gpd
#from config import get_translations
import time
from internal.helper import format_observations
from sql import models,schemas
from sql import database
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update
from sqlalchemy.orm import Session
from sqlalchemy.sql import text
#from geoalchemy2 import Geography,Geometry
import shapely
import sys
import sql.crud
import io
from user import User, get_current_active_user



# Bahari import
from PIL import Image, ExifTags


router = APIRouter(
    prefix="/observation",
    tags=["observation"],
    responses={404: {"description": "Not found"}},
)



@router.get("/{uuid}", response_model=schemas.wp_observation)
async def get_wp_observation(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
                        uuid: Annotated[str|None, "wp_observation UUID"] = "6e34c045-b835-42cd-9963-27dd5cee7b9f",
                       language_uuid: Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                       db: Session = Depends(database.get_db)):
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    r: schemas.wp_observation | None = db.query(models.wp_observation).filter(models.wp_observation.uuid == uuid).first()
    if r is None:
        raise HTTPException(status_code=404, detail="Observation not found")
    return r



# @router.get("/wp_observation_group/{uuid}", response_model=schemas.wp_observation_group)
# async def get_wp_observation_group(current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
#                             uuid: Annotated[UUID|None, "wp_observation_group UUID"] = UUID('1ea40ee0-0182-565d-4473-0000064973a0'), #696a2595-cda2-4668-8a34-e89b64fd57d5
#                              language_uuid: Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
#                             db: Session = Depends(database.get_db)):
#     # Verify, if user has permission to view this CA
#     current_user.check_permission("viewca", ca_uuid)
    
#     db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
#     r: schemas.wp_observation_group | None = db.query(models.wp_observation_group).filter(models.wp_observation_group.uuid == uuid).first()
#     if r is None:
#         raise HTTPException(status_code=404, detail="Observation Group not found")
#     return r

    
    

    
# @router.get("/patrolobservations/", response_class=JSONResponse)
# async def get_patrol_observations(
#                             current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
#                             ca_uuid: Annotated[UUID, "Conservation Area ID"],
#                             patrol_uuid: Annotated[UUID|None, "patrol_uuid"] = None,
#                             patrol_id:  Annotated[str|None, "patrol_id"] = None,
                        
#                             language_uuid: Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
#                             db: Session = Depends(database.get_db)
#                             ):
#     """Loads all observations of a given patrol"""
#     # Verify, if user has permission to view this CA
#     current_user.check_permission("viewca", ca_uuid)
    
#     result = sql.crud.observations_query(ca_uuid = ca_uuid, patrol_uuid=patrol_uuid, 
#                                                                      patrol_id=patrol_id,
#                                                                      language_uuid=language_uuid, limit=None, db=db)
    
#     return result
    

# Function to convert a group to JSON
def group_to_json(group):
    # Convert the group to a DataFrame and drop group columns
    group_df = pd.DataFrame(group).reset_index(drop=True)
    
    # Convert the group DataFrame to a dictionary and then to JSON
    group_json = group_df.to_dict(orient='records')
    return json.dumps(group_json)

    
#@router.get("/wp_observation/", response_model=list[Observation])
@router.get("/") #, response_class=JSONResponse)
#@router.get("/wp_observation/", response_class=[JSONResponse,FileResponse])
async def get_observations_by_category(
                        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"), 
                        language_uuid:  Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        category_uuid:  Annotated[ List[UUID], Query(description="Category UUIDs")] = [], 
                        tree_filter:    Annotated[ List[UUID], Query(description="List of tree UUIDs, that should not be displayed")] = [],
                        list_filter:    Annotated[ List[UUID], Query(description="List of list UUIDs, that should not be displayed")] = [],

                        start_date:     Annotated[datetime.datetime|None, "Start Date"] = None, #datetime.datetime(2023,1,1,0,0,0),
                        end_date:       Annotated[datetime.datetime|None, "End Date"] = None, #datetime.datetime(2023,1,2,0,0,0),
                        randomize_x:    Annotated[float, "Randomize X by Factor"] = 0, 
                        randomize_y:    Annotated[float, "Randomize Y by Factor"] = 0, 
                        
                        patrol_uuid:    Annotated[UUID|None, "patrol_uuid"] = None,
                        patrol_id:      Annotated[str|None, "patrol_id"] = None,
                        
                        limit:          Annotated[int|None, "limit"] = None,
                        output_type:    Annotated[str|None, "Output Type"] = "geojson",          # raw, geojson, flat
                        db: Session = Depends(database.get_db)):
    
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    
    #print(tree_filter)
    #print(list_filter)

    #cas = current_user.extract_resource_from_scopes("viewca")
    #if ca_uuid not in cas:
    #    raise HTTPException(
    #        status_code=status.HTTP_403_FORBIDDEN,
    #        detail="Permission denied",
            #headers={"WWW-Authenticate": authenticate_value},
    #    )
    #print(cas)


    rows = sql.crud.observations_query(ca_uuid = ca_uuid, category_uuid=category_uuid, 
                                        language_uuid=language_uuid, start_date=start_date, end_date=end_date, limit=limit, db=db, 
                                        list_filter=list_filter, tree_filter=tree_filter, randomize_x=randomize_x, randomize_y=randomize_y)

    if output_type == 'raw':
        return [_r._asdict() for _r in rows]
    elif output_type == 'geojson_flat':

        df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
        df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)

        pivot = df.pivot(index=['uuid','category','datetime','X','Y','geometry'], columns='attribute', values=['value'])
        #pivot = df.pivot(index=['uuid','category','datetime','geometry'], columns='attribute', values=['value'])
        pivot.columns = pivot.columns.get_level_values(1)
        pivot_flat = gpd.GeoDataFrame(pivot.to_records())
        return pivot_flat._to_geo()
    
    elif output_type == 'geojson':
        dfresult = []
        df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
        df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)

        gdf = df.groupby(['geometry','uuid','category_uuid', 'category', 'X', 'Y', 'datetime', 'patrol_uuid', 'patrol_id'])
        # Apply the function to each group and create a new column 'json_data'

        result_dataframe = df.groupby(['geometry','uuid','category_uuid', 'category', 'X', 'Y', 'datetime', 'patrol_uuid', 'patrol_id']).apply(group_to_json).reset_index(name='attributes')
        #print(result_dataframe)
        return gpd.GeoDataFrame(result_dataframe, geometry='geometry', crs=4326)._to_geo()
    
    elif output_type == 'flat':
        df = DataFrame([_r._asdict() for _r in rows])
        #df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)

        pivot = df.pivot(index=['uuid','category','datetime','X','Y'], columns='attribute', values=['value'])
        pivot.columns = pivot.columns.get_level_values(1)
        pivot_flat = DataFrame(pivot.to_records())
        return pivot_flat.to_json(indent=2)
    
    elif output_type == 'csv':
        df = DataFrame([_r._asdict() for _r in rows])
        #df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)

        pivot = df.pivot(index=['uuid','category','datetime','X','Y'], columns='attribute', values=['value'])
        pivot.columns = pivot.columns.get_level_values(1)
        pivot_flat = DataFrame(pivot.to_records())

        stream = io.StringIO()
        pivot_flat.to_csv(stream, index=False)
        response = StreamingResponse(
            iter([stream.getvalue()]), media_type="text/csv")
        response.headers["Content-Disposition"] = "attachment; filename=export.csv"
        return response
        #return pivot_flat.to_csv()
        
    # The above code snippet is a Python code block that handles a specific condition when the
    # `output_type` is `'shp'`. Here is a breakdown of what the code is doing:
    elif output_type == 'GPKG':
        
        df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
        df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)

        gdf = df.groupby(['geometry','uuid','category_uuid', 'category', 'X', 'Y', 'datetime', 'patrol_uuid', 'patrol_id'])
        # Apply the function to each group and create a new column 'json_data'

        result_dataframe = df.groupby(['geometry','uuid','category_uuid', 'category', 'X', 'Y', 'datetime', 'patrol_uuid', 'patrol_id']).apply(group_to_json).reset_index(name='attributes')
        #print(result_dataframe)
        gdf = gpd.GeoDataFrame(result_dataframe, geometry='geometry', crs=4326)
               
        
        stream = io.BytesIO()
        #gdf.to_file(stream, driver='ESRI Shapefile')
        gdf.to_file(stream, driver='GPKG')
        response = StreamingResponse(
            iter([stream.getvalue()]), media_type="application/octet-stream")
        response.headers["Content-Disposition"] = "attachment; filename=export.GPKG"
        
        return response
        
    else:
        return "Unsupported"    







    df = pd.DataFrame([_r._asdict() for _r in rows])
    return df.to_json()

    df = gpd.GeoDataFrame([_r._asdict() for _r in rows])
    # Claculate the geometry column
    df['geometry'] = df.apply(lambda row: shapely.Point(row.X, row.Y), axis=1)
    # Set GeoPandas geometry
    df.set_geometry('geometry', inplace=True)
    # Return a GeoJSON
    return df.to_json()
    return df._to_geo()


    result = dict()


    grpdf = df.groupby(by=['uuid','category','datetime','X','Y'])['attribute'].min()
    for grp in grpdf:
        print(grp)
        obs = dict()
        obs['uuid'] = grp[0][0]     # uuid
        obs['category'] = grp[0][1] # category
        obs['uuid'] = grp[0][2]     # datetime

        observation = gpd.GeoDataFrame(grp[0])
        print(observation)
        
        attributes = gpd.GeoDataFrame.pivot_table(grp[1], columns='attribute', values='value',aggfunc="min" )

        obs['attributes'] = attributes.to_dict()
        print(obs)
        #for att in grp[1]:
        #    print(att)

    # Return a GeoJSON
    return df._to_geo()

    #return pd.DataFrame([_r._asdict() for _r in rows])

    #df['value'] = df['string_value'] if df['string_value'] else df['number_value'] if df['number_value'] else df['list_element'] if df['list_element'] else df['tree_element'] if df['tree_element'] else None
    #df['value'] = df.apply(lambda row: row.string_value if row.string_value else row.number_value) # df['string_value'] if df['string_value'] else df['number_value'] if df['number_value'] else df['list_element'] if df['list_element'] else df['tree_element'] if df['tree_element'] else None
    #,'number_value','list_element','tree_element'
    #return gpd.GeoDataFrame.pivot_table(df, index=['uuid','category','datetime','X','Y'], columns='attribute', values='value',aggfunc="min")
    grp = df.groupby(by=['uuid','category','datetime','X','Y'], )
    print(grp)
    pivot = df.pivot(index=['uuid','category','datetime','X','Y'], columns='attribute', values=['value']).reset_index()
    
    for row in rows:
        print(row)
        print(row.category)
        obs = dict()
        obs["uuid"] = row.uuid
        obs["category"] = row.category
        print(obs)

    #result = result.reindex()
    
    result = df.to_dict('records')
    print(result)
    return JSONResponse(content=result)


    #return rows
    #return result.to_string()
    ##return Response(result.to_json(orient='records'), media_type='application/json')
    #jsonresult = result.to_json() #orient='records')
    #return json.loads(jsonresult)
    
    #return result

    results = []

    for row in rows:
        print(row)
        obs = dict()
        # Flatten attributes
        obs["category"] = row.category
        obs["uuid"] = row.uuid
        obs["geo"]  = shapely.Point([row.wp_group.waypoint.x,row.wp_group.waypoint.y])        #row.wp_group.waypoint.geo
        obs["datetime"] = row.wp_group.waypoint.datetime
        obs["waypoint_id"] = row.wp_group.waypoint.id
        #obs["x"] = row.wp_group.waypoint.x
        #obs["y"] = row.wp_group.waypoint.y
        obs["waypoint_comment"] = row.wp_group.waypoint.wp_comment
        obs["patrol_id"] = row.wp_group.waypoint.patrol_waypoint[0].patrol_leg_day.patrol_leg.patrol.id
        obs["patrol_start"] = row.wp_group.waypoint.patrol_waypoint[0].patrol_leg_day.patrol_leg.patrol.start_date
        obs["patrol_end"] = row.wp_group.waypoint.patrol_waypoint[0].patrol_leg_day.patrol_leg.patrol.end_date
        
        
        for a in row.attributes:
            print(a.attribute)
            value = a.string_value if a.string_value else (a.number_value if a.number_value else (a.list_element if a.list_element else (a.tree_node)))
            obs[a.attribute] = value
        print(obs)
        results.append(obs)
    g = gpd.GeoDataFrame.from_dict(results, geometry="geo")
    return g._to_geo()
    #print(g)    
    #for x in data:
    #    print(x.__dict__)
    #    g = gpd.GeoDataFrame.from_dict(x.__dict__)
    #    y= format_observations(g)
    
    
    return data



def translate(translation_table:DataFrame, element_uuid:UUID, default:str = "", language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'))->str|None:
    if element_uuid is None:
        return None
    
    if any(translation_table.element_uuid == element_uuid):
        return translation_table.loc[translation_table.element_uuid == element_uuid].value.item()
    else:
        return default
    

# @router.get("/")
# async def get_observations(
#                     current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
#                     patrol_uuid: Annotated[UUID|None, "patrol_uuid","c7e38e11-a1b3-4a09-b088-acce233ba56c"] = None, #UUID("c7e38e11-a1b3-4a09-b088-acce233ba56c"),
#                     wpo_uuid: Annotated[UUID|None, "Conservation Area ID"] = None, #UUID("221bd162-1e69-46d9-85cf-308ad51be2a5"),
#                     start_date: Annotated[datetime.datetime|None, "Start Date"] = datetime.datetime(2023,1,1,0,0,0),
#                     end_date: Annotated[datetime.datetime|None, "End Date"] = datetime.datetime(2023,1,2,0,0,0),
#                     category_uuid: Annotated[UUID|None, "Category UUID"] = None,
#                     ca: Annotated[UUID|None, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
#                     language_uuid: Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
#                     raw: bool| None = False
#                     ):
#     # Verify, if user has permission to view this CA
#     current_user.check_permission("viewca", ca_uuid)
    

#     t1 = time.perf_counter(), time.process_time()
#     df: gpd.GeoDataFrame = smdb.SMARTConnectDatabase().GetPatrolObservations(patroluuid=patrol_uuid, ca_uuid=ca, from_datetime=start_date, to_datetime=end_date, wpo_uuid=wpo_uuid, language_uuid=language_uuid, category_uuid=category_uuid)
#     t2 = time.perf_counter(), time.process_time()

#     print(f" Real time: {t2[0] - t1[0]:.2f} seconds")
#     print(f" CPU time: {t2[1] - t1[1]:.2f} seconds")
#     print()

#     if raw:
#         return df._to_geo()
    
#     t1 = time.perf_counter(), time.process_time()

#     retval = format_observations(df)
    
#     t2 = time.perf_counter(), time.process_time()

#     print(f" Real time: {t2[0] - t1[0]:.2f} seconds")
#     print(f" CPU time: {t2[1] - t1[1]:.2f} seconds")
#     print()


#     return retval
    

# @router.get("/patrol_observations")
# async def get_patrol_observation(current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                     
#                 patrol_uuid: Annotated[UUID, "patrol_uuid","c7e38e11-a1b3-4a09-b088-acce233ba56c"] = UUID("c7e38e11-a1b3-4a09-b088-acce233ba56c"),
#                 ca: Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53")):
#     # Verify, if user has permission to view this CA
#     current_user.check_permission("viewca", ca_uuid)
    
#     df: gpd.GeoDataFrame = smdb.SMARTConnectDatabase().GetPatrolObservations(patroluuid=patrol_uuid)

#     retval = format_observations(df)

#     return retval

class dm_Attribute(schemas.BaseModel):
    attribute_uuid:     UUID
    list_element_uuid:  UUID|None = None
    tree_node_uuid:     UUID|None = None
    number_value:       float|None = None
    string_value :      str|None = None
    #class Config:
    #    orm_mode = True

class upload_result(schemas.BaseModel):
    filename:           str
    timestamp:          str
    size:               float
    patrols:            list[str] = []
        

@router.post("/upload_attachments/", include_in_schema=False)
async def upload_attachments(
        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
        #files:           Annotated[list[UploadFile], list[File()]],
        files:          List[UploadFile] = File(...),
        #attributes:     Annotated[list[dm_Attribute], Form()],
        #files:           Annotated[list[bytes], File()],
        ca_uuid:        Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
        patrol_uuid:    Annotated[UUID, "patrol_uuid"] = UUID("c7e38e11-a1b3-4a09-b088-acce233ba56c"),
        db:             Session = Depends(database.get_db)
    ):

    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    

    #return {"message": f"Successfully uploaded {len(file)}"}
    #return {"message": f"Successfully uploaded {file.filename}"}

    path = get_settings().ATTACHMENT_PATH

    results = []

    for file in files:
        filename:str = os.path.join(path, file.filename) #output file path
        async with aiofiles.open(filename, 'wb') as out_file:
            while content := await file.read(1024):  # async read file chunk
                await out_file.write(content)  # async write file chunk

        # Extract the EXIF timestamp
        img = Image.open(filename)
        img_exif = img.getexif()
        print(img_exif)
        

        for key, val in img_exif.items():
            #print(key)
            if key in ExifTags.TAGS:
                print(f'{ExifTags.TAGS[key]}:{val}')
            else:
                print(f'{key}:{val}')

        dtstr = img_exif.get(306)
        dt = datetime.datetime.strptime(dtstr, '%Y:%m:%d %H:%M:%S')
        print(dt)
        #size = 128, 128
        #thumbnail = img.copy()
        #thumbnail.thumbnail(size)
        #thumbnail.save(filename)

        # Search matching patrol and waypoint     
        patrols = sql.crud.find_waypoints(timestamp=dt, db=db)
        print(patrols)

        # Build return structure
        fileinfo = {}
        fileinfo["filename"] = file.filename
        fileinfo["timestamp"] = dt
        fileinfo["size"] = file.size
        #fileinfo["thumbnail"] = thumbnail.tobytes()
        #fileinfo["patrols"] = 
        #return patrols.to_dict(orient="records")
        


        results.append(fileinfo)

    return results 

@router.post("/create_observations/", include_in_schema=False)
async def create_observation(
        current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    
        attributes:     Annotated[list[dm_Attribute], Body(embed=False)],
        #file:           Annotated[UploadFile|None, File()]  = None,
        ca_uuid:        Annotated[UUID, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
        patrol_uuid:    Annotated[UUID, "patrol_uuid"] = UUID("c7e38e11-a1b3-4a09-b088-acce233ba56c"),
        category_uuid:  Annotated[UUID|None, "category_uuid"] = UUID("ee72fc4d-c0b1-4dc1-9baf-a2b517ae9567"),
        waypoint_uuid:  Annotated[UUID|None, "waypoint_uuid"] = UUID("0fcbdf76-7498-4df0-90d0-0dd3db4b8169"),
        #attributes:     Annotated[list[dm_Attribute]|None, Body(embed=True)] = None,
        #file:           UploadFile | None = None,
        filename:       Annotated[str|None, "filename"] = None,
        db:             Session = Depends(database.get_db)
    ):
    """
    This function is used to upload a picture and create an observation as part of a patrol based on the submitted data. The picture will be added to the observation as an attachment.
    The request for that function comes from a use case of Baharihai in Keny. They collect underwater pictures with a GoPro camera, while a boye is dragged on a rope by the divers which has a smart phone running a SMART Mobile Patrol.
    With this function these pictures shall be geolocated by using the track information of the patrol.
    """
    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)
    
    # First check if there is already a wp_observation_group for this waypoint
    query = select(database.wp_observation_group.c.uuid).where(database.wp_observation_group.c.wp_uuid==waypoint_uuid)
    print(query)
    try:    
        r: ScalarResult[models.wp_observation] = db.scalar(query)
        if r:
            print(r)
            wpog_uuid = r
        else:
            wpog_uuid = uuid.uuid4()
            stmt = database.wp_observation_group.insert().values(uuid=wpog_uuid, wp_uuid=waypoint_uuid)
            result = db.execute(stmt)   
        print(wpog_uuid)
        # Insert new Observation
        obs_uuid = uuid.uuid4()
        stmt = database.wp_observation.insert().values(uuid=obs_uuid, category_uuid=category_uuid, wp_group_uuid=wpog_uuid)
        result = db.execute(stmt)
        #obs_uuid = result.inserted_primary_key

        print(attributes)

        # Insert the attributes for that observation
        for attribute in attributes:
            db.execute(database.wp_observation_attributes.insert().values(uuid=uuid.uuid4(),
                                                           observation_uuid = obs_uuid,
                                                           attribute_uuid = attribute.attribute_uuid,
                                                           list_element_uuid = attribute.list_element_uuid,
                                                           tree_node_uuid = attribute.tree_node_uuid,
                                                           number_value = attribute.number_value,
                                                           string_value = attribute.string_value))
        
        db.commit() 
    except Exception as e:
        print(e)
        return 
    
    return {"message": f"Successfully"}
    
