from fastapi import APIRouter, Depends, Security
#from api import app, oauth2_scheme
from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
#from sql import models,schemas
from sql import database
from user import User, get_current_active_user



router = APIRouter(
    prefix="/employee",
    tags=["employee"],
    responses={404: {"description": "Not found"}},
)



def __init__():
    return

class Employee(BaseModel):
    uuid:       UUID
    ca_uuid:    UUID
    id:         str
    givenname:  str|None
    familyname: str|None
    #name:       str|None
    #name2:      str|None
    startemploymentdate: datetime.date|None
    endemploymentdate: datetime.date|None
    agency_uuid: UUID|None
    rank_uuid:  UUID|None
    smartuserlevel: str|None


@router.get("/")
async def get_employees(   #token: Annotated[str, Depends(oauth2_scheme)], 
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    db:             Session = Depends(database.get_db)
                 ) -> list[Employee]:
    
    #db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    current_user.check_permission("viewca", ca_uuid)
    
    q = select(database.employee).where(database.employee.c.ca_uuid == ca_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of employees")

