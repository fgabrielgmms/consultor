from fastapi import APIRouter, Security, Depends
from user import User, get_current_active_user

#from api import app, oauth2_scheme
from typing import Annotated
#from fastapi.security import OAuth2PasswordBearer

from pydantic import BaseModel

import datetime

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
from fastapi import HTTPException
from sql import models,schemas
from sql import database
from sqlalchemy import select, Sequence, ScalarResult, Insert, Update, text, func
from sqlalchemy.orm import Session



router = APIRouter(
    prefix="/station",
    tags=["station"],
    responses={404: {"description": "Not found"}},
)


def __init__():
    return

class Station(BaseModel):
    uuid: UUID
    ca_uuid: UUID
    desc_uuid: UUID|None
    is_active: bool|None
    name: str|None
    description: str|None
    


@router.get("/", response_model=list[Station])
async def get_stations(
                    current_user:   Annotated[User, Security(get_current_active_user, scopes=["admin:None", "viewca:.*"])],
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"] = "a2516167-3da8-440e-b56b-6f68c2f11d53",
                    language_uuid:  Annotated[UUID, "Language ID"] = '2af26704-7dd9-4a77-bbd4-c1953800d4f8',
                    db:             Session = Depends(database.get_db)
                 ) -> list[Station]:

    # Verify, if user has permission to view this CA
    current_user.check_permission("viewca", ca_uuid)

    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
    
    q = select(database.station,
               func.reporting.get_translations(database.station.c.uuid, language_uuid).label("name"),
               func.reporting.get_translations(database.station.c.desc_uuid, language_uuid).label("description"),
               ).where(database.station.c.ca_uuid == ca_uuid)
    try:
        return db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading stations")
