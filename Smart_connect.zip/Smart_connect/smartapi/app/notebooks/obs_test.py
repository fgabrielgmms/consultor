import requests 
import json
import pandas as pd 
from pandas import DataFrame
import geopandas as gpd
from matplotlib import artist
import matplotlib.pyplot as plt
import contextily as ctx


def test_obs():
    url = 'http://localhost:8000/observation/wp_observation/'
    session = requests.Session()
    params = {}
    params["category_uuid"] = "17218360-6c42-4f19-9637-1d7c8fc20802"
    params["category_uuid"] = "ee72fc4d-c0b1-4dc1-9baf-a2b517ae9567"
    params["language_uuid"] = "2af26704-7dd9-4a77-bbd4-c1953800d4f8"
    params["start_date"] = "2022-01-01T00:00:00"
    params["end_date"] = "2023-06-02T00:00:01"
    params["limit"] = 20

    r = session.get(url, verify=False, params=params) 
    print(r.status_code)
    j = json.loads(r.content)
    print(json.dumps(j, indent=4))
    df = pd.json_normalize(j, ["features"])
    print(df.head())
    #df["properties.Status"].fillna("Unknown", inplace=True)
    #print(df.groupby("properties.Status").sum("properties.Number of homesteads"))
    
    #print(df.groupby("properties.Status").count())

    gdf = gpd.GeoDataFrame.from_features(j)
    print(gdf)
    print(gdf.columns)

    myplot = gdf.plot(legend=True,
                      #column="Number of People", 
                      column="Species",
                      figsize=(10, 8))
    
    myplot.set_picker(True)
    myplot.set_mouseover(True)
    #a = artist.Artist()
    
    #myplot.set_axis_off()
    #ctx.add_basemap(ax=myplot, source=ctx.providers.OpenStreetMap.Mapnik, zoom=18)  # I'm using OSM as the source. See all provides with ctx.providers
    plt.title("Observations")
    plt.magma()
    plt.ion()
    plt.show(block=True)
    
    #print(pd.json_normalize(j, record_path=['attributes'], ))

    #df = gpd.GeoDataFrame.from_records(pd.json_normalize(j))
    #print(df)
    #print(df.to_json(indent=4))
    #df = pd.json_normalize(j)
    #print(df["attributes"][0])
    #return r


def test_patrol():
    url = 'http://localhost:8000/patrol/getlist/'
    session = requests.Session()
    params = {}
    #params["language_uuid"] = "2af26704-7dd9-4a77-bbd4-c1953800d4f8"
    params["start_date"] = "2023-01-01T00:00:00"
    params["end_date"] = "2023-01-01T00:00:00"
    params["limit"] = 200

    r = session.get(url, verify=False, params=params) 
    print(r.status_code)
    j = json.loads(r.content)
    #print(json.dumps(j, indent=4))
    #return
    df = pd.json_normalize(j, ["features"])
    #print(df.head())
    #df["properties.Status"].fillna("Unknown", inplace=True)
    #print(df.groupby("properties.Status").sum("properties.Number of homesteads"))
    
    #print(df.groupby("properties.Status").count())

    gdf = gpd.GeoDataFrame.from_features(j)
    #print(gdf)
    print(gdf.columns)

    #fig,ax = plt.subplots()
    #ax.plot(gdf)

    myplot = gdf.plot(legend=True,
                      #column="Number of People", 
                      column="id",

                      figsize=(10, 8))
    
    myplot.set_picker(True)
    myplot.set_mouseover(True)
    #a = artist.Artist()
    
    #myplot.set_axis_off()
    #ctx.add_basemap(ax=myplot, source=ctx.providers.OpenStreetMap.Mapnik, zoom=18)  # I'm using OSM as the source. See all provides with ctx.providers
    plt.title("Patrols")
    plt.magma()
    plt.ion()
    plt.show(block=True)


test_patrol()
# test_obs()      

