
import requests
import json
import numpy as np
import pandas as pd
import geopandas as gpd
from datetime import datetime
import shapely





class smart_api():
    def __init__(self,urlBase:str, username:str, password:str, ca_uuid:str, language_uuid: str):
        print(urlBase)
        self._urlBase = urlBase
        self._username = username
        self._password = password
        self._ca_uuid = ca_uuid
        self._language_uuid = language_uuid
        
    def login(self):
        login_data = {
            "username" : self._username,
            "password" : self._password,
        }
        print(self._urlBase)
        response = requests.post(f"{self._urlBase}token", data=login_data)
        print(response)
        if response.status_code == 200:
            self._token = response.json()["access_token"]
            return self._token
        else:
            #token = None
            raise Exception("failed to login")

    def query_data(self, url, params={}):
        #if not token:
        #    token = login (username='smartuser', password='smart1234')
            
        headers = {"Authorization": f"Bearer {self._token}", }
    
        session = requests.Session()
        r = session.get(f'{self._urlBase}{url}', verify=False, params=params, headers=headers) 
        
        if r.status_code == 200:
            #print(r.json())
            df = pd.DataFrame(r.json())
            # df.to_file("observations-v2.geojson", driver="GeoJSON")
            # df.to_file("observations-v2.gpkg", driver="GPKG")
            
        else:
            print (r.status_code)
            df = None
        
        return df

    def query_geojson_data(self, url, params={}) -> gpd.GeoDataFrame | None:
        #if not token:
        #    token = login (username='smartuser', password='smart1234')
            
        headers = {"Authorization": f"Bearer {self._token}", }
    
        session = requests.Session()
        r = session.get(f'{self._urlBase}{url}', verify=False, params=params, headers=headers) 
        
        if r.status_code == 200:
            df = gpd.GeoDataFrame.from_features(r.json(), crs=4326)
            # df.to_file("observations-v2.geojson", driver="GeoJSON")
            # df.to_file("observations-v2.gpkg", driver="GPKG")
            
        else:
            print (r.status_code)
            df = None
        
        return df
    
    def get(self, url, params={}):
        #if not token:
        #    token = login (username='smartuser', password='smart1234')
            
        headers = {"Authorization": f"Bearer {self._token}", }
    
        session = requests.Session()
        r = session.get(f'{self._urlBase}{url}', verify=False, params=params, headers=headers) 
        return r
        if r.status_code == 200:
            #print(r.json())
            return r.json()
            # df.to_file("observations-v2.geojson", driver="GeoJSON")
            # df.to_file("observations-v2.gpkg", driver="GPKG")
            
        else:
            print (r.status_code)
            return None
        
        
