from pydantic_settings import BaseSettings, SettingsConfigDict
import pydantic
import fastapi
from functools import lru_cache
#from pandas import DataFrame
#import SMARTConnectDatabase as smdb
from uuid import UUID

import sqlalchemy
#from sqlalchemy.orm import Session
import geoalchemy2
#import pydantic_geojson 
import geopandas
import logging


print(f'SQLAlchemy: {sqlalchemy.__version__}')
print(f'Pydantic: {pydantic.__version__}')
print(f'FastAPI: {fastapi.__version__}')
print(f'GeoAlchemy2: {geoalchemy2.__version__}')
print(f'pydantic_geojson: 0.1.1')
print(f'geopandas: {geopandas.__version__}')

class Settings(BaseSettings):
    SMART_DATABASE_USER:        str = "postgres"
    SMART_DATABASE_PASSWORD:    str = "mysecretpassword"
    SMART_DATABASE_SERVER:      str = "localhost"
    SMART_DATABASE_PORT:        int = 5432
    SMART_DATABASE_DATABASE:    str = "connect"
    
    
    SMART_CONNECT_URL:          str
    SMART_CONNECT_AUTHENTICATED: bool
    SMART_CONNECT_USERNAME:     str
    SMART_CONNECT_PASSWORD:     str
    
    
    LANGUAGE_UUID:              str
    DEFAULT_CA_UUID:            UUID
    SECRET_KEY:                 str
    ALGORITHM:                  str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 3600
    ATTACHMENT_PATH:            str
    
    FASTAPI_DEBUGMODE:          bool = False
    DEV_INCLUDE_IN_SCHEMA:      bool = False             # Controls if functions still under develpoment are included in the schema
    ENABLE_STRICT_PW_CHECKS:    bool = True
    LOGLEVEL:                   int = logging.ERROR
    
    
    model_config = SettingsConfigDict(env_file=".env")
    #model_config = SettingsConfigDict(env_file=".env_lionrangernaconnect")
    

@lru_cache
def get_settings() -> Settings:
    return Settings()

#@lru_cache()
#def get_translations(language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')) -> DataFrame:
#    print (f'Load Language {language_uuid}')
#    return smdb.SMARTConnectDatabase().LoadTranslationTable(language_uuid=language_uuid)
    
