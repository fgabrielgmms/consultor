import psycopg2
import pandas as pd
from pandas import DataFrame
import geopandas as gpd
from datetime import datetime
from datetime import timedelta
import collections
import configparser
from uuid import UUID
#from main import get_settings
from config import Settings, get_settings
import time


class SMARTConnectDatabase:
    dbuser: str | None
    dbpassword: str | None
    dbserver: str | None
    dbport: int | None
    dbdatabase: str | None
    

    def __init__(self) -> None:
        print ('SMARTConnectDatabase __init__')
        settings: Settings = get_settings()

        self.dbuser = settings.SMART_DATABASE_USER            
        self.dbpassword  = settings.SMART_DATABASE_PASSWORD
        self.dbserver = settings.SMART_DATABASE_SERVER
        self.dbport = settings.SMART_DATABASE_PORT
        self.dbdatabase = settings.SMART_DATABASE_DATABASE


    ###
    ### Execute SQL SELECT Statement and return results as pandas Dataframe
    def _Select(self, query:str, vars:list):        
        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                try:
                    cur.execute (query=query, vars=vars)
                    data = cur.fetchall()
                    cols = [desc[0] for desc in cur.description]
                    df = pd.DataFrame((data) , columns=[cols])
                except psycopg2.Error as e:
                    print(e.pgerror)
                    pass
        return df
  
    def _Select2(self, query:str, params:list|None) -> DataFrame:   
        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:        
            return pd.read_sql_query(sql = query, con = conn, params=params)



    def get_languages(self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53')):
        query = '''
            select  
                uuid, ca_uuid, isdefault, code
                from smart.language where ca_uuid = %(ca_uuid)s
            '''
        return self._Select2(query, params = {"ca_uuid": str(ca_uuid)})

    def LoadTranslationTable(self, language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')) -> DataFrame:
        query = '''
            select * from smart.i18n_label as il
	            --join smart.language as l on l.uuid = il.language_uuid
            where  il.language_uuid = %(language_uuid)s
        '''
        return self._Select2(query, params = {"language_uuid": str(language_uuid)})
    
    def get_agencies(self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'), language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')) -> DataFrame: 
        query = '''select 
                    cast(t.uuid as varchar),
                    cast(t.ca_uuid as varchar),
                    t.keyid as keyid
                    ,i.value
                from smart.agency as t join smart.i18n_label i on t.uuid = i.element_uuid
                where t.ca_uuid = %(ca_uuid)s 
            '''
        return self._Select2(query, {"ca_uuid": str(ca_uuid)} )
    

    def GetPatrolTracksv2(self,patrolid):
        qryTracks = '''select
            p.id as Patrol_Id, pl.id as Patrol_Leg_Id, pld.patrol_day,
            vtp.distance,
            --vtp.geom,
            vtp.x,
            vtp.y,
            to_timestamp(z/1000) as datetime
            
        from
            smart.patrol as p 
            join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
            join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
            join reporting.v_track_points as vtp on vtp.patrol_leg_day_uuid = pld.uuid
            
        where 
            p.id = %(patrolid)s
        order by
            vtp.z asc
        '''

        
        from server import SMARTConnectengine

        with SMARTConnectengine.connect() as connection:
            Ret = connection.execute(qryTracks,{"patrolid": patrolid},)
            df = pd.DataFrame(Ret.fetchall())
            return df
            return pd.read_sql(text(qryTracks), con = connection, params={"patrolid": patrolid})


    def GetPatrolTracksv1(self,patrolid):
        qryTracks = '''select
            p.id as Patrol_Id, 
            pl.id as Patrol_Leg_Id, 
            pld.patrol_day,
            vtp.distance,
            vtp.geom,
            vtp.x,
            vtp.y,
            to_timestamp(z/1000) as datetime
            
        from
            smart.patrol as p 
            join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
            join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
            join reporting.v_track_points as vtp on vtp.patrol_leg_day_uuid = pld.uuid
            
        where 
            p.id = %s
        order by
            vtp.z asc
        '''

        return self._Select2(qryTracks, params = (patrolid, ))
    
    def GetPatrolTracksv3(self,patrolid:UUID, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53')) -> gpd.GeoDataFrame:
        qryTracks = '''select t.geometry::geometry as geom,
            --*
            p.id as Patrol_Id, 
            pl.id as Patrol_Leg_Id 
            --pld.patrol_day
            --vtp.distance,
            --ST_AsBinary(vtp.geom) as geom,
            --vtp.x,
            --vtp.y,
            --to_timestamp(z/1000) as datetime
            
        from
            smart.patrol as p 
            join smart.patrol_leg as pl on pl.patrol_uuid = p.uuid
            join smart.patrol_leg_day as pld on pl.uuid = pld.patrol_leg_uuid
            --join reporting.v_track_points as vtp on vtp.patrol_leg_day_uuid = pld.uuid
            LEFT join smart.track as t on t.patrol_leg_day_uuid = pld.uuid
            
        where 
            p.uuid = %s
            and p.ca_uuid = %s
        '''

        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:        
            gdf = gpd.GeoDataFrame.from_postgis(sql=qryTracks, con=conn, geom_col = "geom", params=(str(patrolid), str(ca_uuid), ))
        return gdf

    
    
    def GetPatrolIDs(self, start_date:datetime.date, end_date:datetime.date, ca:UUID|None = None, team:UUID|None = None, mandate:UUID|None = None, employee:str|None = None, transporttype:UUID|None = None) -> DataFrame:
        qry = f'''
            SET intervalstyle = 'postgres';

            select distinct
                min(patrol_id) as patrol_id,
                min(patrol_start_date) as patrol_start_date, 
				max(patrol_end_date) as patrol_end_date, 
                min(ca_name) as CA,
                cast(min(station_uuid) as text) as station_uuid,
                min(team) as team,
                min(objective) as objective,
                --min(patrol_type), 
                min(transporttype) as transporttype,
                min(manadatetype) manadatetype,
                --min(is_armed), 
				min(comment) as comment,
                --min(patrol_leg_id) as patrol_leg_id,
                --mandate_uuid
                cast(patrol_uuid as text),
                count(patrol_leg_uuid) as count_patrol_legs,
                sum(distance) as distance,
                sum(patrol_led_day_duration) as duration,
				
				EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 * 60 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) * 60 + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 60 as duration_in_minutes,
				
                EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) /60 +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 3600 as duration_in_hours
				
                from reporting.v_patrols
                where patrol_start_date >= %s and patrol_start_date <= %s
        '''
        vars = [start_date, end_date]
        if ca:
            qry += f" and ca_uuid=%s"
            vars.append(ca)
        if team:
            qry += f" and team_uuid=%s"
            vars.append(team)
        if mandate:
            qry += f" and mandate_uuid=%s"
            vars.append(mandate)
        if employee:
            qry += f" and patrol_leg_uuid IN (select cast(patrol_leg_uuid as text) from smart.patrol_leg_members where employee_uuid = %s)"
            vars.append(employee)
        if transporttype:
            qry += f" and transporttype_uuid=%s"
            vars.append(transporttype)

        qry += 'GROUP BY patrol_uuid, patrol_leg_uuid'

        return self._Select2(qry, vars)
    
    def get_patrol_details (self, patrol_uuid:UUID):
        qry = '''
            select 
                --ST_DumpPoints(t.geometry::geometry),
                --ST_AsGeoJSON(t.geometry::geometry), 
                --ST_AsGeoJSON(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1)) as start_point, 
                ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1) as start_point,
                --ST_PointN(ST_GeometryN(t.geometry::geometry, 1), -1) as last_point, 
                --ST_AsText(ST_Points(t.geometry::geometry)), 
                t.geometry::geometry as geometry,
                pl.id as patrol_leg_id,
                p.id as patrol_id,
                to_timestamp(st_z(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), 1)) / 1000::double precision) as timestamp_start
                --to_timestamp(st_z(ST_PointN(ST_GeometryN(t.geometry::geometry, 1), -1)) / 1000::double precision) as timestamp_last
            from smart.track as t
            join smart.patrol_leg_day as pld on t.patrol_leg_day_uuid = pld.uuid
            join smart.patrol_leg as pl on pld.patrol_leg_uuid = pl.uuid
            --join smart.patrol_leg_members as plm on plm.patrol_leg_uuid = pl.uuid
            --join smart.employee as e on plm.employee_uuid = e.uuid
            join smart.patrol as p on p.uuid = pl.patrol_uuid
            where pl.patrol_uuid = %s
            order by pl.id
        '''
        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:        
            gdf = gpd.GeoDataFrame.from_postgis(sql=qry, con=conn, geom_col = "geometry", index_col="timestamp_start", params=[str(patrol_uuid),])
        return gdf


        qry = '''
            select distinct
                min(patrol_id) as patrol_id,
                min(patrol_start_date) as patrol_start_date, 
				max(patrol_end_date) as patrol_end_date, 
                min(ca_name) as CA,
                cast(min(station_uuid) as text) as station_uuid,
                min(team) as team,
                min(objective) as objective,
                --min(patrol_type), 
                min(transporttype) as transporttype,
                min(manadatetype) manadatetype,
                --min(is_armed), 
				min(comment) as comment,
                --min(patrol_leg_id) as patrol_leg_id,
                --mandate_uuid
                cast(patrol_uuid as text),
                count(patrol_leg_uuid) as count_patrol_legs,
                sum(distance) as distance,
                sum(patrol_led_day_duration) as duration,
				
				EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 * 60 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) * 60 + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 60 as duration_in_minutes,
				
                EXTRACT(day FROM sum(patrol_led_day_duration)) * 24 + 
				EXTRACT(hour FROM sum(patrol_led_day_duration)) + 
				EXTRACT(minute FROM sum(patrol_led_day_duration)) /60 +
				EXTRACT(second FROM sum(patrol_led_day_duration)) / 3600 as duration_in_hours
				
                from reporting.v_patrols
                where patrol_uuid = %s

                GROUP BY patrol_uuid, patrol_leg_uuid
        '''
        vars = [str(patrol_uuid),]
        
        df = self._Select2(qry, params=vars)


        
    
    def format_observations(self, df:gpd.GeoDataFrame):
        g = df.groupby(["waypoint_datetime", "patrol_uuid", "patrol_id","waypoint_id", "wpo_uuid", "dmc_uuid", "category_name","geom"]) #"dmc_uuid", "dma_keyid"
        nObs: int = len(g.groups)
        
        observations = []
        n: int = 0
        t1 = time.perf_counter(), time.process_time()
        
        for x,obs in g:
            n=n+1
            r = dict()   

            r["geometry"] = x[7]
            r['smart_type'] = 'SMART_Observation'
            r["waypoint_datetime"] = x[0]
            r["patrol_uuid"] = x[1]
            r["patrol_id"] = x[2]
            r["waypoint_id"] = x[3]
            r["waypoint_uuid"] = x[4]
            r["category_uuid"] = x[5]
            r["category_name"] = x[6]
            
            
            attributes = dict() 
            attributes_uuids = dict()
            attributes2 = []
            for y in obs.iloc():
                attribute = dict()

                attribute_name = y['wpoa_attribute_name']
                attribute_uuid = y['wpoa_attribute_uuid']
                attribute['uuid'] = y['wpoa_attribute_uuid']
                attribute['name'] = y['wpoa_attribute_name']
                attribute['type'] = y.dma_att_type
                
                if y.dma_att_type == 'LIST':
                    attributes[attribute_name] = y['wpoa_list_element_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_list_element_name']
                    attribute['value'] = y['wpoa_list_element_name']
                    attribute['value_uuid'] = y['wpoa_list_element_uuid']
                elif y['dma_att_type'] == 'NUMERIC':
                    attributes[attribute_name] = y['wpoa_number_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_number_value']
                    attribute['value'] = y['wpoa_number_value']

                elif y['dma_att_type'] == 'STRING':
                    attributes[attribute_name] = y['wpoa_string_value']
                    attributes_uuids[attribute_uuid] = y['wpoa_string_value']
                    attribute['value'] = y['wpoa_string_value']
                else:
                    attributes[attribute_name] = y['wpoa_tree_node_name']
                    attributes_uuids[attribute_uuid] = y['wpoa_tree_node_name']
                    attribute['value'] = y['wpoa_tree_node_name']
                    attribute['value_uuid'] = y['wpoa_tree_node_uuid']
                attributes2.append(attribute)

            r["attributes"] = attributes
            r["attribute_uuids"] = attributes_uuids
            r["attributes2"] = attributes2

                
            #print(r)
            observations.append(r)

        t2 = time.perf_counter(), time.process_time()

        print(f" Real time: {t2[0] - t1[0]:.2f} seconds")
        print(f" CPU time: {t2[1] - t1[1]:.2f} seconds")
        print()

        return gpd.GeoDataFrame.from_dict(observations,geometry="geometry")._to_geo()
    
    


    def GetTeams(self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'), language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')) -> DataFrame: 
        query = '''select cast(t.uuid as varchar),
                    cast(t.ca_uuid as varchar),
                    t.keyid as keyid,
                    cast(t.desc_uuid as varchar),
                    i.value
                from smart.team as t join smart.i18n_label i on t.desc_uuid = i.element_uuid
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select2(query, (str(ca_uuid), str(language_uuid),))
        

    def GetMandates(self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'), language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')):
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    keyid,
					i.value                    
                from smart.patrol_mandate as t join smart.i18n_label i on t.uuid = i.element_uuid				
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select2(query, (str(ca_uuid), str(language_uuid),))

    def GetTransportTypes(self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'), language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')):
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    keyid,
					i.value                    
                from smart.patrol_transport as t join smart.i18n_label i on t.uuid = i.element_uuid				
                where t.ca_uuid = %s and i.language_uuid = %s
            '''
        return self._Select2(query, (str(ca_uuid), str(language_uuid),))

    def GetEmployees (self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53')) -> DataFrame:
        query = '''select cast(uuid as varchar),
                    cast(ca_uuid as varchar),
                    id,
                    givenname,
                    familyname,
                    concat(concat(givenname, ' '),familyname) as name,
                    concat(concat(familyname, ' '),givenname) as name2,
                    startemploymentdate,
                    endemploymentdate,
                    cast(agency_uuid as varchar),
                    cast(rank_uuid as varchar),
                    smartuserlevel
                from smart.employee where ca_uuid=%s
            '''
        return self._Select2(query, (str(ca_uuid), ))
        
    def GetStations (self, ca_uuid:UUID = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'), language_uuid:UUID = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8')):
        query = '''
        select cast(uuid as varchar), 
                    cast(ca_uuid as varchar),
                    cast(desc_uuid as varchar),
                    i.value as name,
					i2.value,
                    cast(i.language_uuid as varchar)
                from smart.station as t join smart.i18n_label i on t.uuid = i.element_uuid 
				join smart.i18n_label i2 on t.desc_uuid = i2.element_uuid				
                where t.ca_uuid = %(ca_uuid)s and t.is_active = true  and i.language_uuid = %(language_uuid)s
            '''
        return self._Select2(query, {"ca_uuid": str(ca_uuid), "language_uuid": str(language_uuid)})
        
    def GetPatrolEfforts (self, employee_uuid:UUID, transporttype='foot'): #startdate, enddate, 
        query = '''select 
                cast(employee_uuid as text) as employee_uuid, familyname, givenname,
                patrol_leg_start,
                date_part('year', patrol_leg_start) as year,
                date_part('month', patrol_leg_start) as month,
                date_part('day', patrol_leg_start) as day,
                patrol_id,
                distance,
                patrol_led_day_duration as duration
            from reporting.v_patrol_efforts 
                where transporttype = %s and employee_uuid = %s
            '''
        return self._Select2(query, params=(transporttype, str(employee_uuid), ))
    

        
    def GetTreeAttribute(self, uuid, language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'):
        query = f'''
        select 
            cast (at.uuid as varchar) as uuid,
            cast (a.uuid as varchar) as attribute_uuid,
            cast (a.ca_uuid as varchar) as ca_uuid,
            a.keyid as attribute_keyid,
            att_type,
            at.keyid as attribute_tree_keyid,
            node_order,
            cast(parent_uuid as varchar) as parent_uuid,
            at.hkey,
            i.value
	    from 
            smart.dm_attribute as a 
            join smart.dm_attribute_tree as at on at.attribute_uuid = a.uuid
            left join smart.i18n_label as i on at.uuid = i.element_uuid
            left join smart.icon as icon on at.icon_uuid = icon.uuid
            left join smart.iconfile as iconfile on icon.uuid = iconfile.icon_uuid
            where 
                a. att_type = 'TREE' and
                a.uuid = %(uuid)s
                and 
                i.language_uuid = %(language_uuid)s
                -- Use only Leafes
                and at.uuid in (select uuid from smart.dm_attribute_tree
				where uuid not in (
					select uuid from smart.dm_attribute_tree
						where uuid in (select parent_uuid from smart.dm_attribute_tree)
						and attribute_uuid = %(uuid)s)
				and attribute_uuid = %(uuid)s
				);
        '''

        return self._Select2(query, params={'uuid': uuid, 'language_uuid': language_uuid })
        df = self.ExecuteSQLSelect(query)

        return df
    def GetDataModelCategory(self):
        query = f'''
        select 
            cast(uuid as varchar) as uuid,
            cast(ca_uuid as varchar) as ca_uuid,
            keyid,
            cat_order,
            cast(parent_category_uuid as varchar) as parent_category_uuid,
            hkey,
            cast(language_uuid as varchar) as language_uuid,
            value

        from smart.dm_category as c
            left join smart.i18n_label as i on c.uuid = i.element_uuid
            where is_active = true	
        '''
        return self._Select2(query)
    
    def GetDataQueueStatistics(self, cauuid):
        query = '''select status, count(*) from connect.data_queue where ca_uuid = %(cauuid)s group by status;'''
        return self._Select2(query, params={'cauuid': cauuid, })

    def GetPatrolsByEmployee(self, cauuid, employee_uuid):
        query = '''
            select *
            from smart.employee as e
                left join smart.patrol_leg_members as plm on plm.employee_uuid = e.uuid
                join smart.patrol_leg as pl on pl.uuid = plm.patrol_leg_uuid
                join smart.patrol as p on p.uuid = pl.patrol_uuid
            where 
                e.uuid = %(employee_uuid)s
                and e.ca_uuid = %(cauuid)s
                --and pl.start_date = '2023-10-07'        
        '''
        return self._Select2(query, params={'cauuid': cauuid, 'employee_uuid': employee_uuid, })
    
    def GetPatrolsByDeviceId(self, device_id):
        query = '''
            select * 
            from 
                smart.ct_patrol_link as cpl
                join smart.patrol_leg as pl on pl.uuid = cpl.patrol_leg_uuid
                join smart.patrol as p on p.uuid = pl.patrol_uuid
                where ct_device_id = %(device_id)s        
        '''
        return self._Select2(query, params={'device_id': device_id, })


    def GetPatrolsByWaypoint(self, datetime: datetime, x: float, y: float, time_spread:int = 10, x_spread: float = 0.01, y_spread: float = 0.01):
        print (datetime - timedelta(minutes=time_spread))
        print(datetime + timedelta(minutes=time_spread))
        print(x - x_spread)
        print(x + x_spread)
        print(y - y_spread)
        print(y + y_spread)

        query = '''select * 
                        from reporting.v_track_points as vtp
                        left join smart.patrol_leg_day as pld on pld.uuid = vtp.patrol_leg_day_uuid
                        left join smart.patrol_leg as pl on pl.uuid = pld.patrol_leg_uuid
                        left join smart.patrol as p on p.uuid = pl.patrol_uuid

                            where 
                            vtp.datetime between %(from_datetime)s and %(to_datetime)s
                            and 
                            vtp.x between %(lower_x)s and %(upper_x)s and 
                            vtp.y between %(lower_y)s and %(upper_y)s
                '''
        return self._Select2(query, params={'from_datetime': datetime - timedelta(minutes=time_spread), 'to_datetime': datetime + timedelta(minutes=time_spread), 'lower_x': x - x_spread, 'upper_x': x + x_spread, 'lower_y': y - y_spread, 'upper_y': y + y_spread, })
    

    def GetPatrolObservations(self, 
                              from_datetime: datetime|None = None, 
                              to_datetime: datetime|None = None, 
                              patrolids:UUID|None = None, 
                              patroluuid:UUID|None = None, 
                              ca_uuid:UUID|None = UUID('a2516167-3da8-440e-b56b-6f68c2f11d53'),
                              wpo_uuid:UUID|None = None,
                              category_uuid:UUID|None = None,
                              language_uuid:UUID|None = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                              ) -> gpd.GeoDataFrame:
        query = '''
            select 
                point(wp.x, wp.y)::geometry as geom,
                wpo.uuid as wpo_uuid,
                wpog.uuid as wpog_uuid,
	            --dmc.keyid as category_keyid,

                wp.source as waypoint_source,
                wp.id::int as waypoint_id,
                --wp.x as waypoint_x,
                --wp.y as waypoint_y,
                wp.datetime::timestamp as waypoint_datetime,
                wp.wp_comment as waypoint_commect,
                
                --pld.patrol_day as pld_patrol_day,
                --pld.start_time as pld_start_time,
                --pld.rest_minutes as pld_rest_minutes,
                --pld.end_time as pld_end_time,
                --pld.end_time - pld.start_time as pld_duration,
                
                --pl.start_date as pl_start_date,
                --pl.end_date as pl_end_date,
                --pl.transport_uuid as pl_transport_uuid,
                --pl.id as pl_id,
                --pl.mandate_uuid as pl_mandate_uuid,
                
                p.id as patrol_id,
                p.uuid as patrol_uuid,
                --p.station_uuid as patrol_station_id,
                --p.team_uuid as patrol_team_uuid,
                --p.objective as patrol_objective,
                --p.patrol_type as patrol_patrol_type,
                p.start_date as patrol_start_date,
                p.end_date as patrol_end_date,
                --p.comment as patrol_comment,
                
                oa.filename as oa_filename,
                oa.uuid as oa_uuid,
                oa.obs_uuid as oa_obs_uuid,
                oa.signature_type_uuid as oa_signature_type_uuid,
                
                dma.keyid as dma_keyid,
                dma.att_type as dma_att_type,
                --dma.min_value as dma_min_value,
                --dma.max_value as dma_max_value,
                dma.uuid as dma_uuid,
                --dma.value as attribute_name,
                reporting.get_translations(dma.uuid, %(language_uuid)s) as attribute_name,
                --dma.ca_uuid as dma_ca_uuid,
                --dma.is_required as dma_is_required,
                --dma.regex as dma_regex,
                --dma.icon_uuid as dma_icon_uuid,

                dmal.keyid as dmal_keyid,
                dmal.uuid as dmal_uuid,
                dmal.attribute_uuid as dmal_attribute_uuid,
                --dmal.value as dmal_value,
                --dmal.list_order as dmal_list_order,
                --dmal.is_active as dmal_is_active,
                --dmal.icon_uuid as dmal_icon_uuid,
                
                dmat.keyid as dmat_keyid,
                dmat.uuid as dmat_uuid,
                dmat.node_order as dmat_node_order,
                dmat.parent_uuid as dmat_parent_uuid,
                dmat.attribute_uuid as dmat_attribute_uuid,
                --dmat.is_active as dmat_is_active,
                dmat.hkey as dmat_hkey,
                --dmat.icon_uuid as dmat_icon_uuid,
                --dmat.value as dmat_value,
                

                dmc.uuid as dmc_uuid,
                dmc.ca_uuid as dmc_ca_uuid,
                dmc.keyid as dmc_keyid,
                dmc.parent_category_uuid as dmc_parent_category_uuid,
                dmc.is_multiple as dmc_is_multiple,
                dmc.cat_order as dmc_cat_order,
                dmc.is_active as dmc_is_active,
                dmc.hkey as dmc_hkey,
                --dmc.icon_uuid as dmc_icon_uuid
                --dmc.value as category_name,
                reporting.get_translations(dmc.uuid, %(language_uuid)s) as category_name,

                --, dm_cat_att_map.*
                wpoa.observation_uuid as wpoa_observation_uuid,
                wpoa.uuid as wpoa_uuid,
                wpoa.attribute_uuid as wpoa_attribute_uuid,
                reporting.get_translations(wpoa.attribute_uuid, %(language_uuid)s) as wpoa_attribute_name,

                wpoa.list_element_uuid as wpoa_list_element_uuid,
                reporting.get_translations(wpoa.list_element_uuid, %(language_uuid)s) as wpoa_list_element_name,

                wpoa.tree_node_uuid as wpoa_tree_node_uuid,
                reporting.get_translations(wpoa.tree_node_uuid, %(language_uuid)s) as wpoa_tree_node_name,

                wpoa.number_value as wpoa_number_value,
                wpoa.string_value as wpoa_string_value
                --wpoal.list_element_uuid as wpoal_list_element_uuid,
                --wpoal.observation_attribute_uuid as wpoal_observation_attribute_uuid,

                --wpoal.value as wpoa_list_value

            from 
                smart.wp_observation as wpo 
                join smart.wp_observation_group as wpog on wpog.uuid = wpo.wp_group_uuid
                join smart.waypoint as wp on wpog.wp_uuid = wp.uuid
                join smart.patrol_waypoint as pwp on wp.uuid = pwp.wp_uuid
                join smart.patrol_leg_day as pld on pwp.leg_day_uuid = pld.uuid
                join smart.patrol_leg as pl on pl.uuid = pld.patrol_leg_uuid
                join smart.patrol as p on p.uuid = pl.patrol_uuid
                
                left join smart.observation_attachment as oa on oa.obs_uuid = wpo.uuid
                left join smart.wp_observation_attributes as wpoa on wpoa.observation_uuid = wpo.uuid
                left join smart.wp_observation_attributes_list as wpoal on  wpoal.observation_attribute_uuid = wpoa.uuid
                
                left join smart.dm_attribute as dma on wpoa.attribute_uuid = dma.uuid
                left join smart.dm_attribute_list as dmal on wpoa.list_element_uuid = dmal.uuid
                left join smart.dm_attribute_tree as dmat on wpoa.tree_node_uuid = dmat.uuid    
                left join smart.dm_category as dmc on wpo.category_uuid = dmc.uuid     
                
            where
                1 = 1
            '''
        params = {}

        if from_datetime is not None and to_datetime is not None:
            query += " and wp.datetime between %(from_datetime)s and %(to_datetime)s"
            params['from_datetime'] = from_datetime
            params['to_datetime'] = to_datetime

        if patrolids is not None:
            if type(patrolids) in (tuple, list):
                query += " and p.id in %(patrolids)s"
                params['patrolids'] = patrolids
        
        if patroluuid is not None:
            query += " and p.uuid = %(patroluuid)s"
            params['patroluuid'] = str(patroluuid)

        if ca_uuid is not None:
            query += " and p.ca_uuid = %(ca_uuid)s"
            params['ca_uuid'] = str(ca_uuid)
            
        if wpo_uuid is not None:
            query += " and wpo.uuid = %(wpo_uuid)s"
            params['wpo_uuid'] = str(wpo_uuid)

        if category_uuid is not None:
            query += " and dmc.uuid = %(category_uuid)s"
            params['category_uuid'] = str(category_uuid)
        
        #query += " and wpoa_list.language_uuid = %(language_uuid)s"
        #query += " and dmc.language_uuid = %(language_uuid)s"
        #query += " and dma.language_uuid = %(language_uuid)s"
        params['language_uuid'] = str(language_uuid)
        
        
        with psycopg2.connect(user=self.dbuser, password=self.dbpassword, host=self.dbserver, port=self.dbport, dbname=self.dbdatabase) as conn:
            return gpd.GeoDataFrame.from_postgis(sql=query, con=conn, geom_col = "geom", params=params)        

    def GetConservationAreaProperties(self, ca_uuid: UUID):
        query = '''
                select * from smart.conservation_area_property where ca_uuid=%(ca_uuid)s            
            '''
        return self._Select2(query, params={'ca_uuid': str(ca_uuid), })