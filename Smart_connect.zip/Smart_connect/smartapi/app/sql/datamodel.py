from .smartdbsession import smartDbSession
from typing import Annotated
from uuid import UUID
from geoalchemy2 import functions as geofunc
from sqlalchemy import select, func, join



def query_dm_category(db:             smartDbSession,
                    ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                    language_uuid:  Annotated[UUID, "Language ID"],
                    category_uuid:  Annotated[UUID|None, "category_uuid"] = None,                        
                    active_only:    Annotated[bool|None, "active only"] = True,
                    ):


    db.set_default_language(language_uuid=language_uuid)
    
    j = (db.dm_category
                .join(db.dm_cat_att_map, db.dm_category.c.uuid == db.dm_cat_att_map.c.category_uuid, isouter=True)
                .join(db.dm_attribute, db.dm_attribute.c.uuid == db.dm_cat_att_map.c.attribute_uuid, isouter=True)
    )

    q = select(
                            db.dm_category.c.uuid, 
                            db.dm_category.c.ca_uuid,
                            db.dm_category.c.keyid,
                            db.dm_category.c.is_active,
                            db.dm_category.c.hkey,
                            db.dm_category.c.parent_category_uuid,
                            db.dm_category.c.is_multiple,
                            db.dm_category.c.cat_order,
                            db.dm_category.c.icon_uuid,
                            func.reporting.get_translations(db.dm_category.c.uuid, language_uuid).label("name"),

                            db.dm_attribute.c.uuid.label("attribute_uuid"), 
                            db.dm_attribute.c.keyid.label("attribute_keyid"), 
                            db.dm_attribute.c.att_type.label("attribute_att_type"), 
                            db.dm_attribute.c.min_value.label("attribute_min_value"), 
                            db.dm_attribute.c.max_value.label("attribute_max_value"), 
                            db.dm_attribute.c.regex.label("attribute_regex"), 
                            db.dm_attribute.c.icon_uuid.label("attribute_icon_uuid"), 
                            db.dm_attribute.c.is_required.label("attribute_is_required"), 
                            func.reporting.get_translations(db.dm_attribute.c.uuid, language_uuid).label("attribute_name")
                            ).select_from(j)
    q = q.where(db.dm_category.c.ca_uuid == ca_uuid)
    
    if category_uuid:
            q = q.where(db.dm_category.c.uuid == category_uuid)
    if active_only:
        q = q.where(db.dm_category.c.is_active == True)
        
    
    return db._dbSession.execute(q).fetchall()



def query_dm_categories(db:             smartDbSession,
                    ca_uuid:        Annotated[UUID|None, "Conservation Area ID"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),
                    language_uuid:  Annotated[UUID, "Language ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                    active_only:    Annotated[bool|None, "active only"] = True,
                    ):

    db.set_default_language(language_uuid=language_uuid)

    q = select(
                                        db.dm_category.c.uuid, 
                                        db.dm_category.c.ca_uuid,
                                        db.dm_category.c.keyid,
                                        db.dm_category.c.is_active,
                                        db.dm_category.c.hkey,
                                        db.dm_category.c.parent_category_uuid,
                                        db.dm_category.c.is_multiple,
                                        db.dm_category.c.cat_order,
                                        db.dm_category.c.icon_uuid,
                                        func.reporting.get_translations(db.dm_category.c.uuid, language_uuid).label("name"))
    
    q = q.where(db.dm_category.c.ca_uuid == ca_uuid)
    if active_only:
        q = q.where(db.dm_category.c.is_active == True)
    return db._dbSession.execute(q).fetchall()


def query_dm_attributes(db:             smartDbSession,
                ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                language_uuid:  Annotated[UUID, "Language ID"],
                att_type:       Annotated[str|None, "att_type"] = None,
                ):
    
    db.set_default_language(language_uuid=language_uuid)

    q = select(
                                        db.dm_attribute.c.uuid, 
                                        db.dm_attribute.c.ca_uuid, 
                                        db.dm_attribute.c.keyid,
                                        db.dm_attribute.c.att_type,
                                        db.dm_attribute.c.min_value,
                                        db.dm_attribute.c.max_value,
                                        db.dm_attribute.c.regex,
                                        db.dm_attribute.c.icon_uuid,
                                        db.dm_attribute.c.is_required,
                                        func.reporting.get_translations(db.dm_attribute.c.uuid, language_uuid).label("name"))
    
    q = q.where(db.dm_attribute.c.ca_uuid == ca_uuid)
    if att_type:
        q = q.where(db.dm_attribute.c.att_type == att_type)

    return db._dbSession.execute(q).fetchall()
    
def query_dm_attribute(db:             smartDbSession,
                ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                language_uuid:  Annotated[UUID, "Language ID"],
                attribute_uuid:     Annotated[UUID|None, "Attribute UUID"],
                ):
    
    db.set_default_language(language_uuid=language_uuid)

    q = select(
                                        db.dm_attribute.c.uuid, 
                                        db.dm_attribute.c.ca_uuid, 
                                        db.dm_attribute.c.keyid,
                                        db.dm_attribute.c.att_type,
                                        db.dm_attribute.c.min_value,
                                        db.dm_attribute.c.max_value,
                                        db.dm_attribute.c.regex,
                                        db.dm_attribute.c.icon_uuid,
                                        db.dm_attribute.c.is_required,
                                        func.reporting.get_translations(db.dm_attribute.c.uuid, language_uuid).label("name"))
    
    q = q.where(db.dm_attribute.c.ca_uuid == ca_uuid)
    q = q.where(db.dm_attribute.c.uuid == attribute_uuid)

    return db._dbSession.execute(q).fetchone()
    


def query_dm_attribute_list(db:             smartDbSession,
                        #db:             Session,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID, "Language ID"],
                        attribute_uuid: Annotated[UUID, "Attribute UUID"],
                        is_active:      Annotated[bool|None, "active only"] = True,
                        
                    ):
    db.set_default_language(language_uuid=language_uuid)

    q = select(
                                        db.dm_attribute_list.c.uuid, 
                                        db.dm_attribute_list.c.attribute_uuid,
                                        db.dm_attribute_list.c.keyid,
                                        db.dm_attribute_list.c.list_order,
                                        db.dm_attribute_list.c.is_active,
                                        db.dm_attribute_list.c.icon_uuid,
                                        func.reporting.get_translations(db.dm_attribute_list.c.uuid, language_uuid).label("name"))
    
    if attribute_uuid:
        q = q.where(db.dm_attribute_list.c.attribute_uuid == attribute_uuid)
    if is_active:
        q = q.where(db.dm_attribute_list.c.is_active == is_active)

    rows = db._dbSession.execute(q).fetchall()
    return rows


def query_dm_attribute_tree(db:             smartDbSession,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID, "Language ID"],
                        attribute_uuid: Annotated[UUID, "Attribute UUID"],
                        is_active:      Annotated[bool|None, "active only"] = True,
                        
                    ):
    
    db.set_default_language(language_uuid=language_uuid)

    q = select(
                                        db.dm_attribute_tree.c.uuid, 
                                        db.dm_attribute_tree.c.parent_uuid,
                                        db.dm_attribute_tree.c.attribute_uuid,
                                        db.dm_attribute_tree.c.keyid,
                                        db.dm_attribute_tree.c.node_order,
                                        db.dm_attribute_tree.c.is_active,
                                        db.dm_attribute_tree.c.icon_uuid,
                                        func.reporting.get_translations(db.dm_attribute_tree.c.uuid, language_uuid).label("name"))
    
    if attribute_uuid:
        q = q.where(db.dm_attribute_tree.c.attribute_uuid == attribute_uuid)
    if is_active:
        q = q.where(db.dm_attribute_tree.c.is_active == is_active)

    rows = db._dbSession.execute(q).fetchall()
    
    return rows