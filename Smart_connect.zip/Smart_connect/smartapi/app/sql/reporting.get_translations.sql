-- drop function reporting.get_translations;

create or replace function reporting.get_translations(element uuid, language uuid)
   returns text 
   language plpgsql
   STABLE 
   RETURNS NULL ON NULL INPUT
  as
$$
declare 
	translated_text text;
begin
 	select i.value into translated_text from smart.i18n_label as i where i.element_uuid = element and i.language_uuid = language;
	if translated_text is null then
		-- get the translation for the default language
		select i.value into translated_text from 
			smart.i18n_label as i
			left join smart.language as l on i.language_uuid = l.uuid and l.isdefault = True
			where i.element_uuid = element;
	end if;
	return translated_text;
end;
$$;


ALTER FUNCTION reporting.get_translations
    OWNER TO postgres;

GRANT EXECUTE ON FUNCTION reporting.get_translations TO postgres;


select reporting.get_translations('ee72fc4d-c0b1-4dc1-9baf-a2b517ae9567', '2af26704-7dd9-4a77-bbd4-c1953800d4f8') as attribute_name2