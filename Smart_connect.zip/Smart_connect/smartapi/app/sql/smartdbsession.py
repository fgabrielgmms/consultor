
from sqlalchemy import create_engine, event, MetaData,Table
from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import text
from sqlalchemy import select, func, join

from config import get_settings

from typing import Annotated
from uuid import UUID


# class smartDbException(Exception):
#     pass

# def set_default_language(attribute):
#     def _set_default_language(f):
    
#         def wrapper(self, *args):
#             #language_uuid = args["language_uuid"]
#             #args[0]._dbSession.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})        
#             print (getattr(self, attribute))
#             return f(self, *args)
#         return wrapper
#     return _set_default_language


class smartDbSession():
    
    _engine = None
    _dbSession = None
    _metadata = None
    _default_language_uuid = None
    
    def __init__(self) -> None:
        self._engine = create_engine(f'postgresql+psycopg2://{get_settings().SMART_DATABASE_USER}:{get_settings().SMART_DATABASE_PASSWORD}@{get_settings().SMART_DATABASE_SERVER}:{get_settings().SMART_DATABASE_PORT}/{get_settings().SMART_DATABASE_DATABASE}', 
                       echo=False, connect_args={'options': '-c statement_timeout=15000'})
        s = sessionmaker(autocommit=False, autoflush=False, bind=self._engine)
        self._dbSession = s()

        self._metadata = MetaData()
    
    def close(self):
        if self._dbSession:
            self._dbSession.close()
            
    def getSession(self):
        return self._dbSession
        
    def load_metadata(self):
        self.patrol =                        Table("patrol", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_leg =                    Table("patrol_leg", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_leg_day =                Table("patrol_leg_day", self._metadata, schema="smart", autoload_with=self._engine)
        self.track =                         Table("track", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_leg_members =            Table("patrol_leg_members", self._metadata, schema="smart", autoload_with=self._engine)
        self.employee =                      Table("employee", self._metadata, schema="smart", autoload_with=self._engine)
        self.area_geometries =               Table("area_geometries", self._metadata, schema="smart", autoload_with=self._engine)
        self.conservation_area_property =    Table("conservation_area_property", self._metadata, schema="smart", autoload_with=self._engine)
        self.conservation_area =             Table("conservation_area", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_mandate =                Table("patrol_mandate", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_transport =              Table("patrol_transport", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_type =                   Table("patrol_type", self._metadata, schema="smart", autoload_with=self._engine)

        self.agency =                        Table("agency", self._metadata, schema="smart", autoload_with=self._engine)
        self.station =                       Table("station", self._metadata, schema="smart", autoload_with=self._engine)
        self.team =                          Table("team", self._metadata, schema="smart", autoload_with=self._engine)
        self.patrol_waypoint =               Table("patrol_waypoint", self._metadata, schema="smart", autoload_with=self._engine)
        self.waypoint =                      Table("waypoint", self._metadata, schema="smart", autoload_with=self._engine)
        self.wp_observation_group =          Table("wp_observation_group", self._metadata, schema="smart", autoload_with=self._engine)
        self.wp_observation =                Table("wp_observation", self._metadata, schema="smart", autoload_with=self._engine)
        self.wp_observation_attributes =     Table("wp_observation_attributes", self._metadata, schema="smart", autoload_with=self._engine)     
        self.wp_attachments =                Table("wp_attachments", self._metadata, schema="smart", autoload_with=self._engine)     
        self.observation_attachment =        Table("observation_attachment", self._metadata, schema="smart", autoload_with=self._engine)     

        self.connect_users =                 Table("users", self._metadata, schema="connect", autoload_with=self._engine) 
        self.connect_user_roles=             Table("user_roles", self._metadata, schema="connect", autoload_with=self._engine) 
        self.connect_user_actions=           Table("user_actions", self._metadata, schema="connect", autoload_with=self._engine) 
        self.connect_roles =                 Table("roles", self._metadata, schema="connect", autoload_with=self._engine) 
        self.connect_role_actions=           Table("role_actions", self._metadata, schema="connect", autoload_with=self._engine) 

        self.connect_dataqueue =             Table("data_queue", self._metadata, schema="connect", autoload_with=self._engine) 

        self.dm_category =                   Table("dm_category", self._metadata, schema="smart", autoload_with=self._engine) 
        self.dm_attribute =                  Table("dm_attribute", self._metadata, schema="smart", autoload_with=self._engine) 
        self.dm_attribute_list =             Table("dm_attribute_list", self._metadata, schema="smart", autoload_with=self._engine) 
        self.dm_attribute_tree =             Table("dm_attribute_tree", self._metadata, schema="smart", autoload_with=self._engine) 
        self.dm_cat_att_map =                Table("dm_cat_att_map", self._metadata, schema="smart", autoload_with=self._engine) 
        self.saved_maps =                    Table("saved_maps", self._metadata, schema="smart", autoload_with=self._engine) 

        self.language =                      Table("language", self._metadata, schema="smart", autoload_with=self._engine) 
        self.i18n_label=                     Table("i18n_label", self._metadata, schema="smart", autoload_with=self._engine)
        
    def set_default_language(
                            self,
                            language_uuid:  Annotated[UUID, "Language ID"],
                            ):
        # Set the language_uuid for this connection
        #if self._default_language_uuid != language_uuid:
        self._dbSession.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})
        self._default_language_uuid = language_uuid
        
        
    

    