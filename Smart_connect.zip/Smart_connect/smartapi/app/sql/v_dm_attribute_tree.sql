-- View: reporting.v_dm_attribute_tree

-- DROP VIEW reporting.v_dm_attribute_tree;

CREATE OR REPLACE VIEW reporting.v_dm_attribute_tree
 AS
 SELECT *
 	FROM smart.dm_attribute_tree
	LEFT JOIN smart.i18n_label on smart.dm_attribute_tree.uuid = smart.i18n_label.element_uuid;
    
ALTER TABLE reporting.v_dm_attribute_tree
    OWNER TO postgres;

GRANT ALL ON TABLE reporting.v_dm_attribute_tree TO postgres;

-- select * from reporting.v_dm_attribute_tree where language_uuid = '2af26704-7dd9-4a77-bbd4-c1953800d4f8'