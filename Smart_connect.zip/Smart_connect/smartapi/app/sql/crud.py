from fastapi import Depends, FastAPI, HTTPException, APIRouter
from fastapi.responses import JSONResponse
#from api import app, oauth2_scheme
from typing import Annotated, List

#from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer

#from pydantic import BaseModel
from pydantic import TypeAdapter

#import SMARTConnectDatabase as smdb
from pandas import DataFrame
from uuid import UUID
import requests
import json
import datetime
import pandas as pd
import geopandas as gpd
from internal.helper import format_observations, format_patrol
#from .employee import Employee
#from ..internal.classes import Patrol

from sqlalchemy.orm import Session,column_property,registry
from sqlalchemy.sql import text
from sqlalchemy import select,func,Table,String,Column,and_,or_,lambda_stmt,distinct
from sqlalchemy.types import Boolean, Date, DateTime, Float, Integer, Text, Time, Interval, Uuid

from sql import models,schemas
from sql import database
#from sql.database import engine, smart_metadata
from uuid import UUID
#from config import get_db
from geoalchemy2 import functions as geofunc
from datetime import timedelta
import shapely
import math




def find_patrols(# token: Annotated[str, Depends(oauth2_scheme)], 
            db: Session,
            ca_uuid: Annotated[UUID, "CA"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),

            team_uuid: Annotated[UUID|None, "Team"] = None,
            station_uuid: Annotated[UUID|None, "Station"] = None,
            mandate_uuid: Annotated[UUID|None, "Mandate"] = None, #UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol
            employee_team_uuid: Annotated[UUID|None, "Employee Team"] = None,
                
            transport_uuid: Annotated[UUID|None, "Transport Type"] = None, #UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
            employee_uuid: Annotated[UUID|None, "Employee"] = None, 
            patrolleader_uuid: Annotated[UUID|None, "Patrol Leader"] = None, 
            
            timestamp: Annotated[datetime.datetime|None, "Timestamp"] = None, 
            
            start_date: Annotated[datetime.date|None, "Start"] = None,
            end_date: Annotated[datetime.date|None, "End"]  = None,


            # Geographical data
            polygon: Annotated[str|None, "Polygon"] = None,
            area_geometry_uuid: Annotated[UUID|None, "Area Geometry"] = None,

            #tracks:  Annotated[bool|None, "Include Track Data"] = False,
            #observations:  Annotated[bool|None, "Include Observation Data"] = False,

            limit:      Annotated[int|None, "Max Patrols returned"] = None,    # -1 = no limit

            ):
    """
    Searches the database for matching patrols. 
    Returns list of patrol-ids and patrol-uuids
    """

    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                .join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid )
    )
    q = select(
                            database.patrol.c.uuid.label("uuid"),
                            func.min(database.patrol.c.id).label("id"),
                            func.count(database.patrol_leg.c.uuid).label('patrol_legs'),
                            func.min(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("patrol_start"),
                            func.max(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("patrol_end"),
                            (database.patrol_leg_members.c.employee_uuid).label("patrol_leader_uuid"),
                            func.min(database.employee.c.givenname + ' ' + database.employee.c.familyname).label("patrol_leader_name"),
                            func.sum(database.track.c.distance).label("distance"),
                            func.sum(database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            func.sum((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            #geofunc.ST_AsText(geofunc.ST_Force2D(database.track.c.geometry)).label("track"),
                            geofunc.ST_AsText(geofunc.ST_Force3D(database.track.c.geometry)).label("track"),
                            
                            geofunc.ST_Force2D(database.track.c.geometry).label("geometry")
    ).select_from(j).group_by(database.patrol.c.uuid, database.patrol_leg_members.c.employee_uuid,database.track.c.geometry)

    q = q.where(database.patrol.c.ca_uuid == ca_uuid)
    q = q.where(database.patrol_leg_members.c.is_leader == True)
      
    if timestamp:
        # Find all patrols that have been started before and ended after the timestamp
        lower_limit = timestamp - timedelta(minutes=5)
        upper_limit = timestamp + timedelta(minutes=5)
        q = (q
                .where(and_(
                        (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time) <= timestamp),
                        ((database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time) >= timestamp))                 
        )

    if start_date is not None and end_date is not None:
        q = q.where(database.patrol.c.start_date >= start_date).where(database.patrol.c.start_date <= end_date) 


    if team_uuid:
        q = q.where(database.patrol.c.team_uuid == team_uuid)

    if employee_team_uuid:
        pass
        #stmt = stmt.where(models.Patrol.team_uuid == team_uuid)

    if station_uuid:
        q = q.where(database.patrol.c.station_uuid == station_uuid)

    if mandate_uuid:
        q = q.where(database.patrol_leg.c.mandate_uuid == mandate_uuid)

    if transport_uuid:
        q = q.where(database.patrol_leg.c.transport_uuid == transport_uuid)

    if employee_uuid:
        q = q.add_columns(database.patrol_leg_members.c.employee_uuid)
        q = q.group_by(database.patrol_leg_members.c.employee_uuid)
        q = q.where(database.patrol_leg_members.c.employee_uuid.in_(employee_uuid))

    if patrolleader_uuid:
        q = q.where(database.patrol_leg_members.c.employee_uuid == patrolleader_uuid)

    if area_geometry_uuid:
        q2 = select(database.area_geometries.c.geom).where(database.area_geometries.c.uuid == area_geometry_uuid)
        try:
            r2 = db.execute(q2).fetchone()
        except Exception as e:
            print(e)
            return e
        print(r2)
        polygon = r2[0]


    if polygon:
        """select *
	from smart.track as t join smart.area_geometries as ag
	on st_coveredby(st_force2d(geometry::geometry), ag.geom::geometry)
where 
	ag.ca_uuid = 'a2516167-3da8-440e-b56b-6f68c2f11d53'
	and ag.area_type = 'CA' and ag.keyid = 'puros'
	"""
        # Convert the string
        #area = shapely.from_wkt(polygon)
        #q = q.where(geofunc.ST_Contains(geofunc.ST_AsEncodedPolyline(area), database.track.c.geometry))
        q = q.where(geofunc.ST_Contains(polygon, geofunc.ST_Force2D(database.track.c.geometry)))

    
    if limit:
        q = q.limit(limit=limit)
        
    print(q)

    try:
        rows = db.execute(q).all()
    except Exception as e:
        print(e)
        return e
    
    # Convert rows into dict to output as JSON
    #print(len(rows))
    #json_data = [_r._asdict() for _r in rows]

    #return json_data,rows
    return rows



def find_patrols2(# token: Annotated[str, Depends(oauth2_scheme)], 
            db: Session,
            ca_uuid: Annotated[UUID, "CA"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),

            team_uuid: Annotated[UUID|None, "Team"] = None,
            station_uuid: Annotated[UUID|None, "Station"] = None,
            mandate_uuid: Annotated[UUID|None, "Mandate"] = None, #UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol
            employee_team_uuid: Annotated[UUID|None, "Employee Team"] = None,
                
            transport_uuid: Annotated[UUID|None, "Transport Type"] = None, #UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
            employee_uuid: Annotated[List[UUID]|None, "Employee"] = None, 
            
            patrolleader_uuid: Annotated[UUID|None, "Patrol Leader"] = None, 
            patrol_uuid: Annotated[UUID|None, "Patrol UUID"] = None, 
            
            patrol_id:  Annotated[str|None, "Patrol ID"] = None,
            
            timestamp: Annotated[datetime.datetime|None, "Timestamp"] = None, 
            
            start_date: Annotated[datetime.date|None, "Start"] = None,
            end_date: Annotated[datetime.date|None, "End"]  = None,


            # Geographical data
            polygon: Annotated[str|None, "Polygon"] = None,
            area_geometry_uuid: Annotated[UUID|None, "Area Geometry"] = None,

            #tracks:  Annotated[bool|None, "Include Track Data"] = False,
            #observations:  Annotated[bool|None, "Include Observation Data"] = False,

            limit:      Annotated[int|None, "Max Patrols returned"] = None,    # -1 = no limit

            ):
    """
    Searches the database for matching patrols. 
    Returns list of patrol-ids and patrol-uuids
    """

    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                .join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid )
    )
    q = select(
                            database.patrol.c.uuid.label("uuid"),
                            database.patrol.c.id.label("id"),
                            database.patrol_leg.c.uuid.label('patrol_leg_uuid'),
                            database.patrol_leg.c.id.label('patrol_leg_id'),
                            database.patrol_leg_day.c.patrol_day.label('patrol_leg_day_day'),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("patrol_leg_day_start"),
                            (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("patrol_leg_day_end"),
                            (database.patrol_leg_members.c.employee_uuid).label("patrol_leader_uuid"),
                            (database.employee.c.givenname + ' ' + database.employee.c.familyname).label("patrol_leader_name"),
                            (database.track.c.distance).label("distance"),
                            (database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            ((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            #geofunc.ST_AsText(geofunc.ST_Force2D(database.track.c.geometry)).label("track"),
                            geofunc.ST_AsText(geofunc.ST_Force3D(database.track.c.geometry)).label("track"),
                            
                            geofunc.ST_Force2D(database.track.c.geometry).label("geometry")
    ).select_from(j) #.group_by(# database.patrol.c.uuid, 
                              #database.patrol_leg_members.c.employee_uuid,
                              #database.track.c.geometry
                              #)

    q = q.where(database.patrol.c.ca_uuid == ca_uuid)
    q = q.where(database.patrol_leg_members.c.is_leader == True)
      
    if timestamp:
        # Find all patrols that have been started before and ended after the timestamp
        lower_limit = timestamp - timedelta(minutes=5)
        upper_limit = timestamp + timedelta(minutes=5)
        q = (q
                .where(and_(
                        (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time) <= timestamp),
                        ((database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time) >= timestamp))                 
        )

    if start_date is not None and end_date is not None:
        q = q.where(database.patrol.c.start_date >= start_date).where(database.patrol.c.start_date <= end_date) 


    if team_uuid:
        q = q.where(database.patrol.c.team_uuid == team_uuid)

    if employee_team_uuid:
        pass
        #stmt = stmt.where(models.Patrol.team_uuid == team_uuid)

    if station_uuid:
        q = q.where(database.patrol.c.station_uuid == station_uuid)

    if mandate_uuid:
        q = q.where(database.patrol_leg.c.mandate_uuid == mandate_uuid)

    if transport_uuid:
        q = q.where(database.patrol_leg.c.transport_uuid == transport_uuid)

    if employee_uuid:
        q = q.add_columns(database.patrol_leg_members.c.employee_uuid)
        #q = q.group_by(database.patrol_leg_members.c.employee_uuid)
        q = q.where(database.patrol_leg_members.c.employee_uuid.in_(employee_uuid))

    if patrolleader_uuid:
        q = q.where(database.patrol_leg_members.c.employee_uuid == patrolleader_uuid)

    if patrol_id:
        q = q.where(database.patrol.c.id == patrol_id)

    if patrol_uuid:
        q = q.where(database.patrol.c.uuid == patrol_uuid)


    if area_geometry_uuid:
        q2 = select(database.area_geometries.c.geom).where(database.area_geometries.c.uuid == area_geometry_uuid)
        try:
            r2 = db.execute(q2).fetchone()
        except Exception as e:
            print(e)
            return e
        print(r2)
        polygon = r2[0]


    if polygon:
        """select *
	from smart.track as t join smart.area_geometries as ag
	on st_coveredby(st_force2d(geometry::geometry), ag.geom::geometry)
where 
	ag.ca_uuid = 'a2516167-3da8-440e-b56b-6f68c2f11d53'
	and ag.area_type = 'CA' and ag.keyid = 'puros'
	"""
        # Convert the string
        #area = shapely.from_wkt(polygon)
        #q = q.where(geofunc.ST_Contains(geofunc.ST_AsEncodedPolyline(area), database.track.c.geometry))
        q = q.where(geofunc.ST_Contains(polygon, geofunc.ST_Force2D(database.track.c.geometry)))

    
    if limit:
        q = q.limit(limit=limit)
        
    print(q)

    try:
        rows = db.execute(q).all()
    except Exception as e:
        print(e)
        return e
    
    # Convert rows into dict to output as JSON
    #print(len(rows))
    #json_data = [_r._asdict() for _r in rows]

    #return json_data,rows
    return rows



def find_waypoints(# token: Annotated[str, Depends(oauth2_scheme)], 
            db: Session,
            timestamp: Annotated[datetime.datetime, "Timestamp"], 
            
            ca_uuid: Annotated[UUID, "CA"] = UUID("a2516167-3da8-440e-b56b-6f68c2f11d53"),

            team_uuid: Annotated[UUID|None, "Team"] = None,
            station_uuid: Annotated[UUID|None, "Station"] = None,
            mandate_uuid: Annotated[UUID|None, "Mandate"] = None, #UUID("f09da083-9f63-49dc-9aec-25f9feaaf0db"),   # Patrol
            employee_team_uuid: Annotated[UUID|None, "Employee Team"] = None,
                
            transport_uuid: Annotated[UUID|None, "Transport Type"] = None, #UUID("76cb89cd-f53b-4884-a697-21fe1a66c7df"), # Foot
            employee_uuid: Annotated[UUID|None, "Employee"] = None, 
            patrolleader_uuid: Annotated[UUID|None, "Patrol Leader"] = None, 
            
            
            start_date: Annotated[datetime.date|None, "Start"] = None,
            end_date: Annotated[datetime.date|None, "End"]  = None,


            # Geographical data
            polygon: Annotated[str|None, "Polygon"] = None,
            area_geometry_uuid: Annotated[UUID|None, "Area Geometry"] = None,

            #tracks:  Annotated[bool|None, "Include Track Data"] = False,
            #observations:  Annotated[bool|None, "Include Observation Data"] = False,

            limit:      Annotated[int|None, "Max Patrols returned"] = None,    # -1 = no limit

            ):
    """
    Searches the database for matching patrols. 
    Returns list of patrol-ids and patrol-uuids
    """

    """
    SELECT track_points.uuid,
    track_points.patrol_leg_day_uuid,
    track_points.distance,
    st_x((track_points.dp).geom) AS x,
    st_y((track_points.dp).geom) AS y,
    st_z((track_points.dp).geom) AS z,
    track_points.geom,
        CASE
            WHEN st_z((track_points.dp).geom) IS NOT NULL AND st_z((track_points.dp).geom) <> 'NaN'::double precision THEN to_timestamp(st_z((track_points.dp).geom) / 1000::double precision)
            ELSE NULL::timestamp with time zone
        END AS datetime
   FROM ( SELECT track.uuid,
            track.patrol_leg_day_uuid,
            track.distance,
            st_dumppoints(track.geometry::geometry) AS dp,
            track.geometry::geometry AS geom
           FROM smart.track 
		 	join smart.patrol_leg_day on smart.track.patrol_leg_day_uuid = smart.patrol_leg_day.uuid
			where track.geometry is not null
				and smart.patrol_leg_day.patrol_day = '2021-11-07'
		) track_points
			
	where st_z((track_points.dp).geom) IS NOT NULL AND st_z((track_points.dp).geom) <> 'NaN'::double precision and to_timestamp(st_z((track_points.dp).geom) / 1000::double precision) = '2021-11-07 17:30:17+00'
    """

    """
    Select all waypoints from given timestamp:

    select *, 
	ST_Dimension(smart.track.geometry),
	ST_AsText(ST_LocateBetweenElevations(smart.track.geometry, 1636306216999, 1636306217010)),
	ST_LocateBetweenElevations(smart.track.geometry, 1636306216999, 1636306217010)

from smart.track where 
--smart.track.uuid = '211f8089-535f-4d77-bdc8-18eab93598c8' and 
not ST_IsEmpty(smart.track.geometry) 
and ST_Dimension(smart.track.geometry) = 1
and ST_NDims(smart.track.geometry) = 3
and ST_LocateBetweenElevations(smart.track.geometry, 1636306216999, 1636306217010) <> '\x010500008000000000'::bytea"""

    lower_limit: float = datetime.datetime.timestamp(timestamp - timedelta(minutes=5)) * 1000
    upper_limit: float = datetime.datetime.timestamp(timestamp + timedelta(minutes=5)) * 1000

    query = select(database.track.c.uuid,
                                            database.track.c.patrol_leg_day_uuid,
                                            geofunc.ST_AsText(geofunc.ST_LocateBetweenElevations(database.track.c.geometry, lower_limit, upper_limit)).label("text_geometry"),
	                                        geofunc.ST_LocateBetweenElevations(database.track.c.geometry, lower_limit, upper_limit).label("geometry")
                                            )
    query = query.where(geofunc.ST_IsEmpty(database.track.c.geometry) != True)
    query = query.where(geofunc.ST_NDims(database.track.c.geometry) == 3)
    #and ST_Dimension(smart.track.geometry) = 1
    query = query.where(geofunc.ST_AsText(geofunc.ST_LocateBetweenElevations(database.track.c.geometry, lower_limit, upper_limit)) != 'MULTILINESTRING Z EMPTY')
    print(query)
    try:
        #df = pd.read_sql_query(str(query), db)
        #return df
        rows = db.execute(query).scalars().fetchall()
        return rows
        return pd.DataFrame.from_records(rows)
        
    except Exception as e:
        print(e)
        return e
    
    

    subquery = select(database.track.c.uuid,
                                                    database.track.c.patrol_leg_day_uuid,
                                                    database.patrol_leg_day.c.patrol_day,
                                                    database.track.c.distance,
                                                    geofunc.ST_DumpPoints(geofunc.ST_Force3D(database.track.c.geometry)).label("dp"),
                                                    geofunc.ST_Force3D(database.track.c.geometry).label("geom")
                                                    ).select_from(
                                database.track.join(database.patrol_leg_day, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                    ).cte()
    #subquery = subquery.where(database.track.c.geometry != None).where(database.patrol_leg_day.c.patrol_day == timestamp.today())

    # Mainquery
    lower_limit = timestamp - timedelta(minutes=5)
    upper_limit = timestamp + timedelta(minutes=5)
        
    mainquery = select(subquery.c.uuid, 
                                        subquery.c.patrol_leg_day_uuid,
                                        #subquery.c.distance, 
                                        #geofunc.ST_X(subquery.c.dp).label("X"),
                                        #geofunc.ST_Y(subquery.c.dp).label("Y"),
                                        geofunc.ST_Z(geofunc.ST_Force3D(subquery.c.dp)).label("Z"),
                                        )
    mainquery = mainquery.where(subquery.c.geom != None).where(subquery.c.patrol_day == timestamp.date() )
    mainquery = mainquery.where(func.to_timestamp(geofunc.ST_Z(geofunc.ST_Force3D(subquery.c.dp)) / 1000) >= lower_limit)
    mainquery = mainquery.where(func.to_timestamp(geofunc.ST_Z(geofunc.ST_Force3D(subquery.c.dp)) / 1000) <= upper_limit)
    print(mainquery)
    try:
        rows = db.execute(mainquery).all()
    except Exception as e:
        print(e)
        return e
    
    # Convert rows into dict to output as JSON
    print(len(rows))
    json_data = [_r._asdict() for _r in rows]

    return json_data


    j = (database.patrol
                .join(database.patrol_leg, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid)
                .join(database.patrol_leg_day, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.track, database.track.c.patrol_leg_day_uuid == database.patrol_leg_day.c.uuid)
                .join(database.patrol_leg_members, database.patrol_leg_members.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                .join(database.employee, database.employee.c.uuid == database.patrol_leg_members.c.employee_uuid )
    )
    q = select(
                            database.patrol.c.uuid.label("uuid"),
                            func.min(database.patrol.c.id).label("id"),
                            func.min(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time).label("patrol_start"),
                            func.max(database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time).label("patrol_end"),
                            (database.patrol_leg_members.c.employee_uuid).label("patrol_leader_uuid"),
                            func.min(database.employee.c.givenname + ' ' + database.employee.c.familyname).label("patrol_leader_name"),
                            func.sum(database.track.c.distance).label("distance"),
                            func.sum(database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time).label("duration(s)"),
                            func.sum((database.patrol_leg_day.c.end_time - database.patrol_leg_day.c.start_time)/(60*60)).label("duration(h)"),

                            geofunc.ST_AsText(geofunc.ST_Force2D(database.track.c.geometry)).label("track")
    ).select_from(j).group_by(database.patrol.c.uuid, database.patrol_leg_members.c.employee_uuid,database.track.c.geometry)

    q = q.where(database.patrol.c.ca_uuid == ca_uuid)
    q = q.where(database.patrol_leg_members.c.is_leader == True)
      
    if timestamp:
        # Find all patrols that have been started before and ended after the timestamp
        q = (q
                .where(and_(
                        (database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.start_time) <= timestamp),
                        ((database.patrol_leg_day.c.patrol_day + database.patrol_leg_day.c.end_time) >= timestamp)) 
                .where(
                    and_(
                       (func.to_timestamp(func.STdatabase.track.c.z/1000)) >= lower_limit,
                       (func.to_timestamp(database.track.c.z/1000)) <= upper_limit,
                    ) 
                )
        )

    if start_date is not None and end_date is not None:
        q = q.where(database.patrol.c.start_date >= start_date).where(database.patrol.c.start_date <= end_date) 


    if team_uuid:
        q = q.where(database.patrol.c.team_uuid == team_uuid)

    if employee_team_uuid:
        pass
        #stmt = stmt.where(models.Patrol.team_uuid == team_uuid)

    if station_uuid:
        q = q.where(database.patrol.c.station_uuid == station_uuid)

    if mandate_uuid:
        q = q.where(database.patrol_leg.c.mandate_uuid == mandate_uuid)

    if transport_uuid:
        q = q.where(database.patrol_leg.c.transport_uuid == transport_uuid)

    if employee_uuid:
        q = q.add_columns(database.patrol_leg_members.c.employee_uuid)
        q = q.group_by(database.patrol_leg_members.c.employee_uuid)
        q = q.where(database.patrol_leg_members.c.employee_uuid.in_(employee_uuid))

    if patrolleader_uuid:
        q = q.where(database.patrol_leg_members.c.employee_uuid == patrolleader_uuid)

    if area_geometry_uuid:
        q2 = select(database.area_geometries.c.geom).where(database.area_geometries.c.uuid == area_geometry_uuid)
        try:
            r2 = db.execute(q2).fetchone()
        except Exception as e:
            print(e)
            return e
        print(r2)
        polygon = r2[0]


    if polygon:
        """select *
	from smart.track as t join smart.area_geometries as ag
	on st_coveredby(st_force2d(geometry::geometry), ag.geom::geometry)
where 
	ag.ca_uuid = 'a2516167-3da8-440e-b56b-6f68c2f11d53'
	and ag.area_type = 'CA' and ag.keyid = 'puros'
	"""
        # Convert the string
        #area = shapely.from_wkt(polygon)
        #q = q.where(geofunc.ST_Contains(geofunc.ST_AsEncodedPolyline(area), database.track.c.geometry))
        q = q.where(geofunc.ST_Contains(polygon, geofunc.ST_Force2D(database.track.c.geometry)))

    
    if limit:
        q = q.limit(limit=limit)
        
    print(q)

    try:
        rows = db.execute(q).all()
    except Exception as e:
        print(e)
        return e
    
    # Convert rows into dict to output as JSON
    print(len(rows))
    json_data = [_r._asdict() for _r in rows]

    return json_data


def observations_query(db:              Session, 
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"], 
                        patrol_uuid:    Annotated[UUID|None, "patrol_uuid"] = None,
                        patrol_id:      Annotated[str|None, "patrol_id"] = None,
                        #category_uuid:  Annotated[UUID|None, "wp_observation UUID"] = None, #UUID("17218360-6c42-4f19-9637-1d7c8fc20802"),
                        category_uuid:  Annotated[ List[UUID], "Category UUIDs"] = [], 
                        language_uuid:  Annotated[UUID, "Conservation Area ID"] = UUID('2af26704-7dd9-4a77-bbd4-c1953800d4f8'),
                        tree_filter:    Annotated[ List[UUID] | None, "List of tree UUIDs, that should not be displayed"] = None,
                        list_filter:    Annotated[ List[UUID] | None, "List of list UUIDs, that should not be displayed"] = None,
                        start_date:     Annotated[datetime.datetime|None, "Start Date"] = None, #datetime.datetime(2023,1,1,0,0,0),
                        end_date:       Annotated[datetime.datetime|None, "End Date"] = None, #datetime.datetime(2023,1,2,0,0,0),
                        randomize_x:      Annotated[float, "Randomize X by Factor"] = 0, #datetime.datetime(2023,1,2,0,0,0),
                        randomize_y:      Annotated[float, "Randomize Y by Factor"] = 0, #datetime.datetime(2023,1,2,0,0,0),
                        limit:          Annotated[int|None, "limit"] = None
                        ):
    """
    Loads all observations of a certain category in a given timeframe
    """
    # Set the language
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    j = (      database.wp_observation
                    .join(database.wp_observation_group, database.wp_observation_group.c.uuid == database.wp_observation.c.wp_group_uuid)
                    .join(database.waypoint, database.waypoint.c.uuid == database.wp_observation_group.c.wp_uuid)
                    .join(database.patrol_waypoint, database.waypoint.c.uuid == database.patrol_waypoint.c.wp_uuid)
                    .join(database.patrol_leg_day, database.patrol_waypoint.c.leg_day_uuid == database.patrol_leg_day.c.uuid)
                    .join(database.patrol_leg, database.patrol_leg_day.c.patrol_leg_uuid == database.patrol_leg.c.uuid)
                    .join(database.patrol, database.patrol_leg.c.patrol_uuid == database.patrol.c.uuid) 
                    .join(database.wp_observation_attributes, database.wp_observation_attributes.c.observation_uuid == database.wp_observation.c.uuid)
         )

    query = select(
                func.cast(database.wp_observation.c.uuid, String).label('uuid'),
                func.cast(database.wp_observation.c.category_uuid, String).label('category_uuid'),
                func.reporting.get_translations(database.wp_observation.c.category_uuid, language_uuid).label("category"),
                (func.random() * randomize_x + database.waypoint.c.x).label('X'),
                (func.random() * randomize_y + database.waypoint.c.y).label('Y'),
                #database.waypoint.c.x.label('X'),
                #database.waypoint.c.y.label('Y'),
                #geofunc.ST_AsText(geofunc.ST_Point(database.waypoint.c.x, database.waypoint.c.y)).label('geometry'),
                func.cast(database.waypoint.c.datetime, String).label('datetime'),
                func.cast(database.patrol.c.uuid, String).label('patrol_uuid'),
                database.patrol.c.id.label('patrol_id'),
                func.cast(database.wp_observation_attributes.c.attribute_uuid, String).label('attribute_uuid'),
                func.reporting.get_translations(database.wp_observation_attributes.c.attribute_uuid, language_uuid).label("attribute"),
                #database.wp_observation_attributes.c.number_value.label('number_value'),
                #database.wp_observation_attributes.c.string_value.label('string_value'),
                #database.wp_observation_attributes.c.list_element_uuid.label('list_element_uuid'),
                #database.wp_observation_attributes.c.tree_node_uuid.label('tree_node_uuid'),
                #func.reporting.get_translations(database.wp_observation_attributes.c.list_element_uuid, language_uuid).label("list_element"),
                #func.reporting.get_translations(database.wp_observation_attributes.c.tree_node_uuid, language_uuid).label("tree_element"),
                func.coalesce(func.cast(database.wp_observation_attributes.c.number_value, String), 
                              database.wp_observation_attributes.c.string_value,
                              func.reporting.get_translations(database.wp_observation_attributes.c.list_element_uuid, language_uuid).label("list_element"),
                              func.reporting.get_translations(database.wp_observation_attributes.c.tree_node_uuid, language_uuid).label("list_element"),
                              ).label('value'),
                
    ).select_from(j)

    if ca_uuid:
        query = query.where(database.patrol.c.ca_uuid == ca_uuid)        

    if patrol_uuid is not None:
        query = query.where(database.patrol.c.uuid == patrol_uuid)        
    if patrol_id is not None:
        query = query.where(database.patrol.c.id == patrol_id)     

    if category_uuid:
        print(category_uuid)
        query = query.where(database.wp_observation.c.category_uuid.in_(category_uuid))        
    
    if start_date is not None:
        query = query.where(database.waypoint.c.datetime >= start_date).where(database.waypoint.c.datetime <= end_date)

    if tree_filter:
        #query = query.where(database.wp_observation_attributes.c.tree_node_uuid.notin_(tree_filter))
        query = query.where(database.wp_observation_attributes.c.tree_node_uuid.notin_(tree_filter))
    
    if list_filter:
        query = query.where(database.wp_observation_attributes.c.list_element_uuid.notin_(list_filter))
    
    if limit is not None:
        query = query.limit(limit=limit)

    query = query.order_by(database.wp_observation.c.uuid, database.wp_observation.c.category_uuid)

    print(query)
    try:    
        rows = db.execute(query).fetchall()
        return rows
        
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading patrol_mandates")


    



def get_track(track_uuid, db:              Session):
    """
    WITH line_strings AS ( 
    SELECT
        uuid as id,
        ST_GeometryN(geometry::geometry, generate_series(1, ST_NumGeometries(geometry::geometry))) AS line
    FROM smart.track where uuid = '57cecb9b-0542-4da3-bd52-6cd9a21c9f4f'
    ),
    points_with_time AS (
        SELECT
            ls.id,
            ST_PointN(ls.line, generate_series(1, ST_NPoints(ls.line))) AS point,
            ST_Z(ST_PointN(ls.line, generate_series(1, ST_NPoints(ls.line)))) AS timestamp		
        FROM line_strings ls
    )
    SELECT
        a.id,
        a.timestamp AS start_timestamp,
        b.timestamp AS end_timestamp,
        a.point as a_point,
        b.point as b_point,
        ST_Distance(a.point, b.point) AS distance,
        b.timestamp - a.timestamp AS time_difference,
        ST_Distance(a.point, b.point) / (b.timestamp - a.timestamp) AS speed,
        ST_Azimuth(a.point, b.point) AS direction
    FROM
        points_with_time a
    JOIN
        points_with_time b ON a.id = b.id AND a.timestamp < b.timestamp
    ORDER BY
        a.id, a.timestamp;
    """

def dm_attribute_list_query(   
                        db:             Session,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID, "Language ID"],
                        attribute_uuid: Annotated[UUID, "Attribute UUID"],
                        is_active:      Annotated[bool|None, "active only"] = True,
                        
                    ):
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    q = select(
                                        database.dm_attribute_list.c.uuid, 
                                        database.dm_attribute_list.c.attribute_uuid,
                                        database.dm_attribute_list.c.keyid,
                                        database.dm_attribute_list.c.list_order,
                                        database.dm_attribute_list.c.is_active,
                                        database.dm_attribute_list.c.icon_uuid,
                                        func.reporting.get_translations(database.dm_attribute_list.c.uuid, language_uuid).label("name"))
    
    #q = q.where(database.dm_attribute_list.c.ca_uuid == ca_uuid)

    if attribute_uuid:
        q = q.where(database.dm_attribute_list.c.attribute_uuid == attribute_uuid)
    if is_active:
        q = q.where(database.dm_attribute_list.c.is_active == is_active)

    try:
        rows = db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
    return rows


def dm_attribute_tree_query(   
                        db:             Session,
                        ca_uuid:        Annotated[UUID, "Conservation Area ID"],
                        language_uuid:  Annotated[UUID, "Language ID"],
                        attribute_uuid: Annotated[UUID, "Attribute UUID"],
                        is_active:      Annotated[bool|None, "active only"] = True,
                        
                    ):
    db.execute(text("SET var.lang_uuid=:language_uuid;"), params={"language_uuid": str(language_uuid)})

    q = select(
                                        database.dm_attribute_tree.c.uuid, 
                                        database.dm_attribute_tree.c.parent_uuid,
                                        database.dm_attribute_tree.c.attribute_uuid,
                                        database.dm_attribute_tree.c.keyid,
                                        database.dm_attribute_tree.c.node_order,
                                        database.dm_attribute_tree.c.is_active,
                                        database.dm_attribute_tree.c.icon_uuid,
                                        func.reporting.get_translations(database.dm_attribute_tree.c.uuid, language_uuid).label("name"))
    
    #q = q.where(database.dm_attribute_tree.c.ca_uuid == ca_uuid)

    if attribute_uuid:
        q = q.where(database.dm_attribute_tree.c.attribute_uuid == attribute_uuid)
    if is_active:
        q = q.where(database.dm_attribute_tree.c.is_active == is_active)

    try:
        rows = db.execute(q).fetchall()
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Error loading list of dm_attribute")
    
    return rows