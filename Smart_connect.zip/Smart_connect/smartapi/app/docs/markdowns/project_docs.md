# SMART Data Access API

Provides direct access to SMART data stored in the database of a SMART Connect server.