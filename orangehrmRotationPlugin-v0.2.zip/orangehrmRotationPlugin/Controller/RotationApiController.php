<?php
namespace OrangeHRM\Rotation\Controller;

use OrangeHRM\Core\Authorization\Annotation\IsGranted;
use OrangeHRM\Core\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use OrangeHRM\Rotation\Service\RotationService;

/**
 * @Route("/api/rotation")
 */
class RotationApiController extends Controller
{
    private RotationService $service;

    public function __construct(RotationService $service)
    {
        $this->service = $service;
    }

    /**
     * @Route("/generate", methods={"POST"})
     * @IsGranted("rot_rotation_generate")
     */
    public function generate(Request $request): JsonResponse
    {
        $payload = json_decode($request->getContent(), true) ?? [];
        $result = $this->service->generateRotation($payload);
        return new JsonResponse($result);
    }

    /**
     * @Route("/publish/{id}", methods={"POST"})
     * @IsGranted("rot_rotation_publish")
     */
    public function publish(int $id): JsonResponse
    {
        $result = $this->service->publishRotation($id);
        return new JsonResponse($result);
    }

    /**
     * @Route("/preview/{id}", methods={"GET"})
     * @IsGranted("rot_rotation_view")
     */
    public function preview(int $id): JsonResponse
    {
        $result = $this->service->getRotation($id);
        return new JsonResponse($result);
    }
}
