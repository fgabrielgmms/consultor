<?php
namespace OrangeHRM\Rotation\Service;

use OrangeHRM\Rotation\Dao\RotationDao;

class RotationService
{
    private RotationDao $dao;
    private DataProviderService $dataProvider;
    private ConstraintEngine $engine;

    public function __construct(RotationDao $dao)
    {
        $this->dao = $dao;
        $this->dataProvider = new DataProviderService();
        $this->engine = new ConstraintEngine();
    }

    /**
     * $options: ['startDate'=>'Y-m-d','endDate'=>'Y-m-d']
     */
    public function generateRotation(array $options): array
    {
        $start = $options['startDate'] ?? date('Y-m-01');
        $end = $options['endDate'] ?? date('Y-m-t', strtotime($start . ' +3 months'));

        $employees = $this->dataProvider->getActiveEmployees();
        $posts = $this->dataProvider->getPosts();

        $assignmentsByPost = [];
        $this->engine->reset();

        // Greedy prototype: iterate posts and try to fill with feasible employees
        foreach ($posts as $post) {
            $postId = $post['id'];
            $assignmentsByPost[$postId] = ['postId'=>$postId, 'post'=>$post, 'assignments'=>[]];

            foreach ($employees as $emp) {
                // Skip if already placed enough people
                if (count($assignmentsByPost[$postId]['assignments']) >= ($post['minStaff'] ?? 4)) {
                    break;
                }
                // Try both shifts to mix
                foreach (['20_9','5_2'] as $shift) {
                    $candidate = [
                        'employeeId'=>$emp['id'],'postId'=>$postId,'from'=>$start,'to'=>$end,
                        'shiftType'=>$shift,'isCoordinator'=>0,'employee'=>$emp,'post'=>$post
                    ];
                    if ($this->engine->validateCandidate($candidate)) {
                        $assignmentsByPost[$postId]['assignments'][] = $candidate;
                        break; // proceed to next employee
                    }
                }
            }
            // Validate group-level constraints
            $this->engine->validateGroup($assignmentsByPost[$postId]);
        }

        return [
            'status' => empty($this->engine->getViolations()) ? 'ok' : 'conflict',
            'startDate' => $start,
            'endDate' => $end,
            'posts' => array_values($assignmentsByPost),
            'violations' => $this->engine->getViolations(),
            'warnings' => $this->engine->getWarnings()
        ];
    }

    public function publishRotation(int $id): array
    {
        // TODO: persist publish status, create assignments
        return ['status' => 'published', 'id' => $id];
    }

    public function getRotation(int $id): array
    {
        return $this->dataProvider->getRotationWithAssignments($id);
    }
}
