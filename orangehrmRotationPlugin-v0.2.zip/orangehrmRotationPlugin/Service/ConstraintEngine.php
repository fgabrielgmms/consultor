<?php
namespace OrangeHRM\Rotation\Service;

class ConstraintEngine
{
    private array $hardViolations = [];
    private array $warnings = [];

    public function reset(): void
    {
        $this->hardViolations = [];
        $this->warnings = [];
    }

    public function getViolations(): array { return $this->hardViolations; }
    public function getWarnings(): array { return $this->warnings; }

    /**
     * Validate hard constraints for a single assignment candidate.
     * $candidate = [
     *   'employeeId'=>..,'postId'=>..,'from'=>'Y-m-d','to'=>'Y-m-d',
     *   'shiftType'=>'20_9'|'5_2','isCoordinator'=>0|1,
     *   'employee'=>[ ... see DataProviderService::getActiveEmployees() ... ],
     *   'post'=>['type'=>..,'requiresPras'=>..]
     * ]
     */
    public function validateCandidate(array $candidate): bool
    {
        $ok = true;
        $emp = $candidate['employee'] ?? [];
        $post = $candidate['post'] ?? [];

        // no repeat post within 12 months
        if (!empty($emp['lastPosts'])) {
            $lastDate = $emp['lastPosts'][$candidate['postId']] ?? null;
            if ($lastDate && strtotime($candidate['from']) < strtotime($lastDate . ' +12 months')) {
                $this->hardViolations[] = "Employee {$emp['id']} repeated post within 12 months";
                $ok = false;
            }
        }

        // PRAS required
        if (!empty($post['requiresPras']) && empty($emp['isPras'])) {
            $this->hardViolations[] = "Post {$candidate['postId']} requires PRAS";
            $ok = false;
        }

        // Gender requirement (at least 1 woman per group) - group-level check done later; here we tag
        if (($emp['gender'] ?? '') !== 'F') {
            $this->warnings[] = "Gender balance check pending for post {$candidate['postId']}";
        }

        // Aquatic defasaje: ensure 2-day gap before starting
        if (($post['type'] ?? '') === 'aquatic' && !empty($emp['lastEndDate'])) {
            if (strtotime($candidate['from']) < strtotime($emp['lastEndDate'] . ' +2 days')) {
                $this->hardViolations[] = "Employee {$emp['id']} needs 2-day gap before aquatic post";
                $ok = false;
            }
        }

        // No overlap with approved vacations / leaves
        foreach ($emp['vacations'] ?? [] as $v) {
            if (!($candidate['to'] < $v['from'] || $candidate['from'] > $v['to'])) {
                $this->hardViolations[] = "Employee {$emp['id']} has vacation overlap";
                $ok = false; break;
            }
        }
        foreach ($emp['leaves'] ?? [] as $l) {
            if (!($candidate['to'] < $l['from'] || $candidate['from'] > $l['to'])) {
                $this->hardViolations[] = "Employee {$emp['id']} has leave overlap";
                $ok = false; break;
            }
        }

        return $ok;
    }

    /**
     * Group-level validation: ensure min staff, PRAS presence, gender balance, shift mix (20/9 + 5/2).
     * $group = ['postId'=>..,'assignments'=>[candidate,...]]
     */
    public function validateGroup(array $group): bool
    {
        $ok = true;
        $assignments = $group['assignments'] ?? [];
        $minStaff = $group['post']['minStaff'] ?? 4;

        if (count($assignments) < $minStaff) {
            $this->hardViolations[] = "Post {$group['postId']} below min staff ($minStaff)";
            $ok = false;
        }
        // At least one woman
        if (!array_filter($assignments, fn($c) => ($c['employee']['gender'] ?? '') === 'F')) {
            $this->hardViolations[] = "Post {$group['postId']} requires at least one woman";
            $ok = false;
        }
        // PRAS presence if required
        if (!empty($group['post']['requiresPras'])) {
            if (!array_filter($assignments, fn($c) => !empty($c['employee']['isPras']))) {
                $this->hardViolations[] = "Post {$group['postId']} requires at least one PRAS";
                $ok = false;
            }
        }
        // Shift mix
        $shifts = array_count_values(array_map(fn($c) => $c['shiftType'], $assignments));
        if (empty($shifts['20_9']) || empty($shifts['5_2'])) {
            $this->warnings[] = "Post {$group['postId']} missing ideal 20/9 + 5/2 mix";
        }

        return $ok;
    }
}
