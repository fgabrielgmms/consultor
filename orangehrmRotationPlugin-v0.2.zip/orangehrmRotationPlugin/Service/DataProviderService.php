<?php
namespace OrangeHRM\Rotation\Service;

class DataProviderService
{
    /**
     * Fetch active employees with required attributes.
     * Expected result per employee:
     * [
     *   'id' => 123,
     *   'firstName' => 'Ana',
     *   'lastName' => 'Perez',
     *   'gender' => 'F'|'M',
     *   'isPras' => true|false,
     *   'skills' => ['aquatic','engine','education'],
     *   'lastPosts' => [postId => '2024-07-01', ...], // map of postId to last endDate
     *   'vacations' => [['from' => '2025-09-01','to' => '2025-09-30']],
     *   'leaves' => [['from' => '2025-08-16','to' => '2025-08-19','type'=>'Sick']],
     *   'attendance' => [] // optional
     * ]
     */
    public function getActiveEmployees(array $options = []): array
    {
        // TODO: Integrate with OrangeHRM PIM/Leave/Time services/DAOs.
        // For now, return an empty array as placeholder.
        return [];
    }

    /**
     * Fetch posts (puestos de control) with constraints.
     * Result per post: ['id'=>1,'name'=>'PC1','type'=>'terrestrial','minStaff'=>4,'requiresPras'=>true]
     */
    public function getPosts(): array
    {
        // TODO: Use Doctrine repository for ohrm_rot_post.
        return [];
    }

    /**
     * Fetch rotations by id with assignments.
     */
    public function getRotationWithAssignments(int $id): array
    {
        // TODO: Query ohrm_rot_rotation and ohrm_rot_assignment
        return ['id'=>$id,'items'=>[]];
    }
}
