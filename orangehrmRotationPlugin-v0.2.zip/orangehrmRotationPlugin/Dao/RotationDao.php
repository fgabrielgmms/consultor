<?php
namespace OrangeHRM\Rotation\Dao;

use OrangeHRM\Core\Dao\BaseDao;
use OrangeHRM\Rotation\Entity\Rotation;

class RotationDao extends BaseDao
{
    /**
     * @return Rotation|null
     */
    public function getRotationById(int $id)
    {
        return $this->getRepository(Rotation::class)->find($id);
    }
}
