<?php
namespace OrangeHRM\Rotation\Menu;

use OrangeHRM\Core\Menu\MenuConfigurator;
use OrangeHRM\Core\Menu\MenuItem;

class RotationMenu implements MenuConfigurator
{
    public function configure(array $menuItems): array
    {
        $menuItems[] = new MenuItem(
            'rotations',
            'Rotations',
            '/time/viewRotations',
            ['rot_rotation_view']
        );
        return $menuItems;
    }
}
