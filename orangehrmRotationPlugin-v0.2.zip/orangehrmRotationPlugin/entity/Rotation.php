<?php
namespace OrangeHRM\Rotation\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="ohrm_rot_rotation")
 */
class Rotation
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /** @ORM\Column(type="date") */
    private \DateTimeInterface $startDate;

    /** @ORM\Column(type="date") */
    private \DateTimeInterface $endDate;

    /** @ORM\Column(type="string", length=50) */
    private string $status = 'draft';

    public function getId(): int { return $this->id; }
}
