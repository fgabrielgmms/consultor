<?php
namespace OrangeHRM\Rotation\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="ohrm_rot_assignment")
 */
class Assignment
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /** @ORM\Column(type="integer") */
    private int $rotationId;

    /** @ORM\Column(type="integer") */
    private int $employeeId;

    /** @ORM\Column(type="integer") */
    private int $postId;

    /** @ORM\Column(type="date") */
    private \DateTimeInterface $fromDate;

    /** @ORM\Column(type="date") */
    private \DateTimeInterface $toDate;
}
