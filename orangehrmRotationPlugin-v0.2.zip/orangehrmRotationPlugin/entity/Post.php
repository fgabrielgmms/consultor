<?php
namespace OrangeHRM\Rotation\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="ohrm_rot_post")
 */
class Post
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private int $id;

    /** @ORM\Column(type="string", length=100) */
    private string $name;

    /** @ORM\Column(type="string", length=50) */
    private string $type; // 'terrestrial' | 'aquatic' | 'block31' | 'block43'
}
