# orangehrmRotationPlugin

Starter plugin for automated staff rotation (PNY).

## What this provides
- REST endpoints to generate, preview, and publish rotations.
- Doctrine entities for Posts, Rotation, Assignments, and Constraints.
- Service layer with a constraint-based scheduler (greedy + backtracking).
- Menu entry under Time > Rotations.
- Example migration placeholders.
